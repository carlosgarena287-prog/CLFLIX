# CLNPLAY+

Atualizacao do projeto existente.

- Mantem a playlist brasileira publica do iptv-org ja usada pelo projeto (`https://iptv-org.github.io/iptv/countries/br.m3u`).
- Deduplicacao de canais por nome normalizado e URL.
- Controles de zoom, modo PREENCHER e restauracao ORIGINAL no player.
- Mantem a playlist VOD e a integracao TMDB existentes.
- Ao sair de um VOD, retorna a tela inicial.
- `.github/workflows/main.yml` preservado byte a byte.

Nota: nao foram importadas as listas de terceiros do repositorio Ramys; a pagina do projeto declara que os links foram coletados da internet e nao comprova autorizacao das retransmissoes.

O ZIP nao foi compilado nesta execucao. Execute o workflow Actions para validar o APK.
