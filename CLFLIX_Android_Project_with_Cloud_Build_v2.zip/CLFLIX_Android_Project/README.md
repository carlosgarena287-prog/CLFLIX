# CLFLIX Android

Projeto Android simples para gerar um APK de depuração pelo GitHub Actions.

## O que esta versão melhora
- Identidade visual CLFLIX com cores escuras e detalhes vermelhos.
- Ícone próprio do aplicativo.
- Cabeçalho com marca CLFLIX e botões Início, Voltar e Recarregar.
- O conteúdo web e a navegação HTTP/HTTPS permanecem dentro do aplicativo, em vez de abrir o navegador externo.
- Aviso de carregamento e mensagens básicas de erro.
- Safe Browsing ativado quando disponível; acesso a arquivos locais desativado.

## Importante
O catálogo e o player continuam sendo carregados a partir de `https://vidbox.wtf/providers`. Esta versão melhora a experiência visual e mantém navegação web dentro do app; ela não transforma o catálogo em dados nativos nem garante que todos os players de terceiros funcionem em tela cheia. A integração direta exigiria uma API ou outro método de integração disponibilizado/autorizado pelo serviço.

## Compilar
O workflow de GitHub Actions compila `app:assembleDebug` e publica o APK como artefato `CLFLIX-debug-apk`.
