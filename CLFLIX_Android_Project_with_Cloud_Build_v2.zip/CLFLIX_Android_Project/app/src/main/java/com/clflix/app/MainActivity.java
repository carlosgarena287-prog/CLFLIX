package com.clflix.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceError;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private static final String START_URL = "https://vidbox.wtf/providers";
    private static final int BG = Color.rgb(7, 8, 11);
    private static final int PANEL = Color.rgb(17, 19, 24);
    private static final int RED = Color.rgb(239, 25, 49);
    private WebView webView;
    private TextView status;
    private Button backButton;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        buildLayout();
        configureWebView();
        if (savedInstanceState == null) webView.loadUrl(START_URL);
        else {
            android.webkit.WebBackForwardList ignored = null;
            if (webView.restoreState(savedInstanceState) == null) webView.loadUrl(START_URL);
        }
    }

    private void buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(15), dp(10), dp(10), dp(10));
        header.setBackgroundColor(PANEL);

        TextView mark = new TextView(this);
        mark.setText("▶");
        mark.setTextColor(RED);
        mark.setTextSize(27);
        mark.setTypeface(Typeface.DEFAULT_BOLD);
        mark.setGravity(Gravity.CENTER);
        header.addView(mark, new LinearLayout.LayoutParams(dp(34), dp(40)));

        TextView logo = new TextView(this);
        logo.setText("CLFLIX");
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(23);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setLetterSpacing(0.02f);
        android.text.SpannableString word = new android.text.SpannableString("CLFLIX");
        word.setSpan(new android.text.style.ForegroundColorSpan(RED), 2, 6, 0);
        logo.setText(word);
        header.addView(logo, new LinearLayout.LayoutParams(0, -2, 1));

        backButton = makeButton("‹", "Voltar", false);
        backButton.setOnClickListener(v -> {
            if (webView != null && webView.canGoBack()) webView.goBack();
            else Toast.makeText(this, "Você já está na página inicial", Toast.LENGTH_SHORT).show();
        });
        header.addView(backButton, buttonParams());

        Button home = makeButton("⌂", "Início", false);
        home.setOnClickListener(v -> {
            if (webView != null) webView.loadUrl(START_URL);
        });
        header.addView(home, buttonParams());

        Button reload = makeButton("↻", "Recarregar", true);
        reload.setOnClickListener(v -> { if (webView != null) webView.reload(); });
        header.addView(reload, buttonParams());
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout content = new FrameLayout(this);
        webView = new WebView(this);
        webView.setBackgroundColor(BG);
        content.addView(webView, new FrameLayout.LayoutParams(-1, -1));

        status = new TextView(this);
        status.setText("Preparando seu catálogo…");
        status.setTextColor(Color.WHITE);
        status.setTextSize(13);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(18), dp(10), dp(18), dp(10));
        status.setBackground(roundDrawable(PANEL, dp(18), RED));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        sp.setMargins(dp(16), dp(8), dp(16), dp(12));
        content.addView(status, sp);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView footer = new TextView(this);
        footer.setText("CLFLIX  •  FILMES  •  SÉRIES  •  ANIMES");
        footer.setTextColor(Color.rgb(130, 132, 142));
        footer.setTextSize(10);
        footer.setLetterSpacing(0.08f);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(dp(8), dp(8), dp(8), dp(8));
        footer.setBackgroundColor(PANEL);
        root.addView(footer, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private Button makeButton(String text, String description, boolean accent) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(23);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(0, 0, 0, 0);
        b.setTextColor(accent ? Color.WHITE : Color.LTGRAY);
        b.setContentDescription(description);
        b.setBackground(roundDrawable(accent ? RED : Color.rgb(34, 36, 43), dp(12), accent ? RED : Color.rgb(50, 52, 60)));
        return b;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(42), dp(42));
        p.setMargins(dp(3), 0, 0, 0);
        return p;
    }

    private GradientDrawable roundDrawable(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(dp(1), stroke);
        return d;
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        if (android.os.Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                if (status != null) {
                    if (progress >= 100) status.setVisibility(View.GONE);
                    else {
                        status.setVisibility(View.VISIBLE);
                        status.setText("Carregando CLFLIX… " + progress + "%");
                    }
                }
            }
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                super.onShowCustomView(view, callback);
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                // Keep web navigation inside CLFLIX instead of launching the external browser.
                if ("https".equals(scheme) || "http".equals(scheme)) return false;
                // Block non-web schemes so a page cannot unexpectedly launch another app.
                return true;
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (status != null) { status.setText("Carregando CLFLIX…"); status.setVisibility(View.VISIBLE); }
                if (backButton != null) backButton.setEnabled(view.canGoBack());
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (status != null) status.setVisibility(View.GONE);
                if (backButton != null) backButton.setEnabled(view.canGoBack());
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && status != null) {
                    status.setText("Sem conexão. Toque em ↻ para tentar novamente.");
                    status.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }
    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
