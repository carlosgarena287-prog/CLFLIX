# CLNPLAY+ — base de modernização Kotlin/Compose

- A tela de entrada foi criada em Kotlin com Jetpack Compose.
- A Activity Java original foi preservada como `MainActivity.java` e continua responsável pelas funções existentes: playlists, TV ao vivo, catálogo, busca e reprodução.
- A nova tela abre a Activity original pelo botão **ENTRAR NO CLNPLAY+**.
- Dependências AndroidX Media3 foram adicionadas ao Gradle para a próxima etapa de migração do player.
- `TMDB_BEARER_TOKEN` continua sendo lido da variável de ambiente do GitHub Actions.
- `.github/workflows/main.yml` foi preservado sem alterações.

**Importante:** esta é uma migração incremental e compatível, não a substituição completa do player antigo por Media3. O player atual foi mantido para não comprometer a reprodução. A integração efetiva do Media3 deve ser feita e validada em etapa separada.
