package com.clflix.app;

import android.app.Activity;

/** Compatibility entry point retained for the repository build workflow. */
public class MainActivity extends Activity { }
