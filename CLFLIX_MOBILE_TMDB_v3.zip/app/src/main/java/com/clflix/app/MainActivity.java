package com.clflix.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import android.text.TextUtils;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
  private final int BG=Color.rgb(9,9,12), PANEL=Color.rgb(25,25,31), RED=Color.rgb(238,48,72);
  private LinearLayout root; private final ExecutorService pool=Executors.newFixedThreadPool(4);
  private static final String TOKEN=BuildConfig.TMDB_BEARER_TOKEN;
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);home();}
  private void home(){
    ScrollView sv=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(16),dp(16),dp(16),dp(30));root.setBackgroundColor(BG);sv.addView(root);
    LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);TextView logo=txt("CLFLIX",27,RED,true);bar.addView(logo,new LinearLayout.LayoutParams(0,-2,1));TextView tag=txt("FILMES  •  SÉRIES",10,Color.LTGRAY,true);bar.addView(tag);root.addView(bar);
    EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(Color.WHITE);search.setHintTextColor(Color.GRAY);search.setHint("Buscar filmes e séries...");search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);search.setPadding(dp(14),0,dp(14),0);search.setBackground(bg(PANEL,13));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(50));sp.topMargin=dp(18);root.addView(search,sp);
    search.setOnEditorActionListener((v,a,e)->{String q=search.getText().toString().trim();if(!q.isEmpty())loadSearch(q);return true;});
    TextView hero=txt("DESCUBRA SEU PRÓXIMO\nFILME FAVORITO",24,Color.WHITE,true);hero.setPadding(dp(16),dp(24),dp(16),dp(24));hero.setBackground(bg(Color.rgb(67,13,25),16));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(18);root.addView(hero,hp);
    if(TextUtils.isEmpty(TOKEN)){TextView warn=txt("A API do TMDB ainda não foi configurada. Adicione TMDB_BEARER_TOKEN nos Secrets do GitHub Actions e gere o APK novamente.",13,Color.YELLOW,false);root.addView(warn);}
    section("FILMES POPULARES","movie","popular");section("SÉRIES POPULARES","tv","popular");section("FILMES MAIS BEM AVALIADOS","movie","top_rated");
    TextView credit=txt("Este produto usa a API do TMDB, mas não é endossado ou certificado pelo TMDB.",10,Color.GRAY,false);credit.setPadding(0,dp(26),0,0);root.addView(credit);
    setContentView(sv);
  }
  private void section(String title,String type,String category){LinearLayout block=new LinearLayout(this);block.setOrientation(1);TextView h=txt(title,17,Color.WHITE,true);h.setPadding(0,dp(22),0,dp(10));block.addView(h);HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);row.setOrientation(0);hs.addView(row);block.addView(hs);root.addView(block);fetch(type,category,null,row);}
  private void loadSearch(String q){root.removeViews(3,Math.max(0,root.getChildCount()-3));TextView h=txt("RESULTADOS: "+q.toUpperCase(),18,Color.WHITE,true);h.setPadding(0,dp(20),0,dp(10));root.addView(h);LinearLayout row=new LinearLayout(this);row.setOrientation(1);root.addView(row);fetch("multi","search",q,row);}
  private void fetch(String type,String category,String query,LinearLayout target){if(TextUtils.isEmpty(TOKEN)){target.addView(txt("Configure a credencial TMDB no GitHub Actions.",12,Color.GRAY,false));return;}pool.execute(()->{try{String path=query==null?"/3/"+type+"/"+category+"?language=pt-BR&page=1":"/3/search/multi?query="+URLEncoder.encode(query,"UTF-8")+"&language=pt-BR&page=1";HttpURLConnection c=(HttpURLConnection)new URL("https://api.themoviedb.org"+path).openConnection();c.setRequestProperty("Authorization","Bearer "+TOKEN);c.setRequestProperty("accept","application/json");c.setConnectTimeout(15000);c.setReadTimeout(15000);int code=c.getResponseCode();InputStream in=code<400?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int count;while((count=in.read(buffer))!=-1)out.write(buffer,0,count);in.close();if(code>=400)throw new Exception("HTTP "+code);JSONArray arr=new JSONObject(out.toString("UTF-8")).optJSONArray("results");runOnUiThread(()->{if(arr==null||arr.length()==0){target.addView(txt("Nenhum título encontrado.",12,Color.GRAY,false));return;}for(int i=0;i<Math.min(arr.length(),20);i++)addItem(target,arr.optJSONObject(i),"multi".equals(type));});}catch(Exception ex){runOnUiThread(()->target.addView(txt("Não foi possível carregar. Verifique a conexão e o token TMDB.",12,Color.LTGRAY,false)));}});}
  private void addItem(LinearLayout row,JSONObject item,boolean vertical){String name=item.optString("title",item.optString("name","Título"));String date=item.optString("release_date",item.optString("first_air_date",""));String poster=item.optString("poster_path","");String overview=item.optString("overview","Sem sinopse disponível.");LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(5),dp(5),dp(5),dp(5));card.setBackground(bg(PANEL,12));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(vertical?-1:dp(132),vertical?-2:dp(250));cp.setMargins(0,0,dp(10),dp(10));row.addView(card,cp);ImageView image=new ImageView(this);image.setBackground(bg(Color.rgb(40,40,46),8));image.setScaleType(ImageView.ScaleType.CENTER_CROP);card.addView(image,new LinearLayout.LayoutParams(vertical?dp(100):dp(122),dp(175)));if(!poster.isEmpty())pool.execute(()->{try{URL u=new URL("https://image.tmdb.org/t/p/w342"+poster);Bitmap bm=BitmapFactory.decodeStream(u.openStream());runOnUiThread(()->image.setImageBitmap(bm));}catch(Exception ignored){}});TextView t=txt(name,13,Color.WHITE,true);t.setMaxLines(2);t.setEllipsize(TextUtils.TruncateAt.END);t.setPadding(0,dp(7),0,0);card.addView(t);card.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle(name+(date.isEmpty()?"":" • "+date.substring(0,4))).setMessage(overview).setPositiveButton("Fechar",null).show());}
  private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;} private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
  @Override protected void onDestroy(){super.onDestroy();pool.shutdownNow();}
}
