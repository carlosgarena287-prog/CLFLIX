CLFLIX Mobile

Projeto Android Java com Gradle 8.9, Android Gradle Plugin 8.7.3 e compileSdk 35.

Para compilar pelo GitHub Actions:
1. Coloque os arquivos do projeto na raiz do repositório, mantendo a pasta app e .github.
2. Mantenha o workflow em .github/workflows/main.yml.
3. Execute Actions > CLFLIX Mobile APK > Run workflow.
4. Se falhar na etapa Build debug APK, copie o texto entre CLFLIX_DIAGNOSTICO_INICIO e CLFLIX_DIAGNOSTICO_FIM.
5. Se compilar, baixe o artefato CLFLIX-Mobile-APK.

O ZIP contém os arquivos-fonte. A compilação Android deve ser confirmada no GitHub Actions; não é declarada como testada localmente.
