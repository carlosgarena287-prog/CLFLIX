# CLNPLAY+ 3.0 — reconstrução

Projeto Android com interface Jetpack Compose e reprodução integrada Media3/ExoPlayer.

- TV ao vivo por playlist M3U
- Filmes e séries por playlist M3U
- Pesquisa local, categorias exibidas pelo `group-title`
- Sem TMDB, sem download de capas e sem cache de imagens
- Endereços de playlists editáveis no menu LISTAS

O app não hospeda conteúdo. Configure apenas playlists e transmissões que você tenha autorização para acessar.

Build: GitHub Actions (`.github/workflows/main.yml`).


## Lista M3U integrada

A lista fornecida foi analisada e foram incluídos no app somente os 22 streams cujos hosts são identificáveis como domínios de emissoras, instituições públicas ou distribuidores oficiais. Entradas de canais pagos em hosts de terceiros, com tokens de acesso ou sem origem autorizável clara não foram incorporadas. As demais categorias e canais permanecem pesquisáveis quando presentes na playlist remota configurada.

O leitor M3U aceita tanto URLs na linha seguinte quanto URLs na mesma linha `#EXTINF`. Canais sem país informado são preservados; o filtro remove somente registros com país explicitamente informado como estrangeiro.
