# CLNPLAY+ 3.0 — reconstrução

Projeto Android com interface Jetpack Compose e reprodução integrada Media3/ExoPlayer.

- TV ao vivo por playlist M3U
- Filmes e séries por playlist M3U
- Pesquisa local, categorias exibidas pelo `group-title`
- Sem TMDB, sem download de capas e sem cache de imagens
- Endereços de playlists editáveis no menu LISTAS

O app não hospeda conteúdo. Configure apenas playlists e transmissões que você tenha autorização para acessar.

Build: GitHub Actions (`.github/workflows/main.yml`).
