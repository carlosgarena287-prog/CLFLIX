package com.clflix.app

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer

private val Bg = Color(0xFF08090D)
private val Panel = Color(0xFF151821)
private val Accent = Color(0xFFE50935)
private val Muted = Color(0xFF9AA1B2)

class ComposeHomeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8,9,13)
        window.navigationBarColor = android.graphics.Color.rgb(8,9,13)
        setContent { MaterialTheme(colorScheme = darkColorScheme(
            primary=Accent, background=Bg, surface=Panel, onPrimary=Color.White,
            onBackground=Color.White, onSurface=Color.White
        )) { ClnApp() } }
    }
}

data class MediaEntry(val title:String, val url:String, val group:String, val logo:String="", val kind:String="TV")
private const val TV_LIST = "https://iptv-org.github.io/iptv/index.m3u"
private const val MOVIE_LIST = "https://raw.githubusercontent.com/Ramys/Iptv-Brasil-2026/master/Filmes-Series.m3u8"

@Composable
private fun ClnApp() {
    val context= LocalContext.current
    val scope= rememberCoroutineScope()
    var tab by remember { mutableStateOf("INÍCIO") }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<MediaEntry?>(null) }
    var tv by remember { mutableStateOf<List<MediaEntry>>(emptyList()) }
    var movies by remember { mutableStateOf<List<MediaEntry>>(emptyList()) }
    var series by remember { mutableStateOf<List<MediaEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var tvUrl by remember { mutableStateOf(TV_LIST) }
    var vodUrl by remember { mutableStateOf(MOVIE_LIST) }
    var showSettings by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }

    fun refresh() {
        loading=true; error=""
        scope.launch {
            try {
                val pair=withContext(Dispatchers.IO) {
                    val a=loadM3u(tvUrl, "TV")
                    val b=loadM3u(vodUrl, "VOD")
                    Pair(a,b)
                }
                tv=pair.first
                movies=pair.second.filter { classify(it)=="FILMES" }
                series=pair.second.filter { classify(it)=="SÉRIES" }
                loaded=true
                if(tv.isEmpty() && movies.isEmpty() && series.isEmpty()) error="As listas responderam, mas nenhum conteúdo válido foi encontrado."
            } catch (e:Exception) { error=e.message ?: "Não foi possível carregar as playlists." }
            loading=false
        }
    }

    val currentList= when(tab) {
        "TV AO VIVO" -> tv
        "FILMES" -> movies
        "SÉRIES" -> series
        else -> (tv.take(12)+movies.take(12)+series.take(12))
    }
    val filtered=currentList.filter { it.title.contains(query, true) || it.group.contains(query,true) }

    if(selected!=null) {
        PlayerScreen(entry=selected!!, onBack={ selected=null })
        return
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=18.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("CLNPLAY", fontSize=25.sp, fontWeight=FontWeight.Black, color=Color.White, letterSpacing=1.sp)
                Text("PLUS  •  SEU ENTRETENIMENTO", fontSize=9.sp, color=Accent, fontWeight=FontWeight.Bold, letterSpacing=2.sp)
            }
            TextButton(onClick={showSettings=true}) { Text("LISTAS", color=Color.White) }
            TextButton(onClick={refresh}) { Text("↻", color=Accent, fontSize=22.sp) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal=12.dp), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            listOf("INÍCIO","TV AO VIVO","FILMES","SÉRIES").forEach { name ->
                val active=tab==name
                Box(Modifier.weight(1f).background(if(active) Accent else Panel, RoundedCornerShape(10.dp))
                    .clickable { tab=name; query="" }.padding(vertical=12.dp), contentAlignment=Alignment.Center) {
                    Text(name, fontSize=10.sp, fontWeight=FontWeight.Bold, color=Color.White)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        if(tab=="INÍCIO") {
            Column(Modifier.fillMaxWidth().padding(horizontal=18.dp).background(
                androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF29202B),Color(0xFF111722))),
                RoundedCornerShape(18.dp)).padding(20.dp)) {
                Text("ENTRETENIMENTO SEM COMPLICAÇÃO", color=Muted, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=1.sp)
                Text("Tudo em um só lugar.", color=Color.White, fontSize=25.sp, fontWeight=FontWeight.ExtraBold)
                Text("TV ao vivo, filmes e séries em um único aplicativo.", color=Muted, fontSize=12.sp)
                Spacer(Modifier.height(14.dp))
                Button(onClick={tab="TV AO VIVO"; if(!loaded) refresh()}, colors=ButtonDefaults.buttonColors(containerColor=Accent)) { Text("EXPLORAR AGORA") }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=12.dp).background(Panel, RoundedCornerShape(12.dp)).padding(horizontal=14.dp, vertical=11.dp), verticalAlignment=Alignment.CenterVertically) {
            Text("⌕", color=Muted, fontSize=20.sp)
            Spacer(Modifier.width(8.dp))
            BasicTextField(value=query, onValueChange={query=it}, singleLine=true,
                modifier=Modifier.weight(1f), textStyle=androidx.compose.ui.text.TextStyle(color=Color.White,fontSize=14.sp),
                decorationBox={ inner -> if(query.isEmpty()) Text("Buscar canais, filmes ou séries...",color=Muted,fontSize=13.sp); inner() })
        }
        if(!loaded && !loading) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment=Alignment.Center) {
                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                    Text("Seu catálogo está esperando.", color=Color.White, fontSize=18.sp, fontWeight=FontWeight.Bold)
                    Text("Carregue as playlists para começar.", color=Muted, fontSize=12.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick={refresh()}, colors=ButtonDefaults.buttonColors(containerColor=Accent)) { Text("CARREGAR CONTEÚDO") }
                }
            }
        } else if(loading) {
            Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center) {
                Column(horizontalAlignment=Alignment.CenterHorizontally) { CircularProgressIndicator(color=Accent); Spacer(Modifier.height(12.dp)); Text("Carregando suas listas…",color=Muted) }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal=18.dp, vertical=4.dp), verticalAlignment=Alignment.CenterVertically) {
                Text(if(tab=="INÍCIO") "DESTAQUES DO CATÁLOGO" else tab, color=Color.White, fontWeight=FontWeight.Bold, fontSize=14.sp)
                Spacer(Modifier.weight(1f))
                Text("${filtered.size} itens", color=Muted, fontSize=11.sp)
            }
            LazyColumn(Modifier.weight(1f), contentPadding=PaddingValues(start=14.dp,end=14.dp,bottom=24.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                items(filtered) { entry ->
                    Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(12.dp)).clickable { selected=entry }.padding(13.dp), verticalAlignment=Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(Color(0xFF242A37),RoundedCornerShape(9.dp)),contentAlignment=Alignment.Center) {
                            Text(if(entry.kind=="TV") "▶" else "▣",color=Accent,fontSize=18.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(entry.title,color=Color.White,fontSize=13.sp,fontWeight=FontWeight.SemiBold,maxLines=2,overflow=TextOverflow.Ellipsis)
                            Text(entry.group.ifBlank { if(entry.kind=="TV") "TV AO VIVO" else entry.kind },color=Muted,fontSize=10.sp,maxLines=1)
                        }
                        Text("ASSISTIR  ›",color=Accent,fontSize=9.sp,fontWeight=FontWeight.Bold)
                    }
                }
            }
        }
        if(error.isNotBlank()) Text(error,color=Color(0xFFFF788B),fontSize=11.sp,modifier=Modifier.padding(12.dp))
        Row(Modifier.fillMaxWidth().background(Color(0xFF10131A)).padding(vertical=9.dp),horizontalArrangement=Arrangement.SpaceEvenly) {
            Text("CLNPLAY+  •  VERSÃO NOVA",color=Muted,fontSize=9.sp)
            Text("PLAYER INTEGRADO",color=Muted,fontSize=9.sp)
        }
    }

    if(showSettings) AlertDialog(
        onDismissRequest={showSettings=false},
        containerColor=Panel,
        title={Text("Fontes de conteúdo",color=Color.White)},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Text("Playlist M3U da TV",color=Muted,fontSize=11.sp)
                OutlinedTextField(tvUrl,{tvUrl=it},singleLine=true)
                Text("Playlist M3U de filmes e séries",color=Muted,fontSize=11.sp)
                OutlinedTextField(vodUrl,{vodUrl=it},singleLine=true)
                Text("As imagens externas não são baixadas nem armazenadas. O catálogo usa os dados da playlist.",color=Muted,fontSize=10.sp)
            }
        },
        confirmButton={TextButton(onClick={showSettings=false;refresh()}){Text("SALVAR E CARREGAR",color=Accent)}},
        dismissButton={TextButton(onClick={showSettings=false}){Text("FECHAR",color=Muted)}}
    )
}

private fun classify(e:MediaEntry):String {
    val s=(e.group+" "+e.title+" "+e.url).lowercase()
    return if(Regex("temporada|season|epis[oó]dio|episode|s[0-9]{1,2}e[0-9]{1,2}|series|séries").containsMatchIn(s)) "SÉRIES" else "FILMES"
}

private fun loadM3u(address:String, kind:String):List<MediaEntry> {
    require(address.startsWith("https://") || address.startsWith("http://")) { "Informe um endereço HTTP ou HTTPS válido." }
    val conn=(URL(address).openConnection() as HttpURLConnection).apply {
        connectTimeout=18000; readTimeout=35000; instanceFollowRedirects=true
        setRequestProperty("User-Agent","CLNPLAY-Android/3.0")
        setRequestProperty("Accept","*/*")
    }
    try {
        if(conn.responseCode !in 200..299) throw Exception("A playlist respondeu HTTP ${conn.responseCode}: $address")
        val result=ArrayList<MediaEntry>()
        conn.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
            var title:String?=null; var group=""; var logo=""
            var line:String?
            while(reader.readLine().also { line=it }!=null) {
                val value=line!!.trim()
                if(value.startsWith("#EXTINF:",true)) {
                    val comma=value.lastIndexOf(',')
                    title=if(comma>=0) value.substring(comma+1).trim() else "Sem título"
                    group=attr(value,"group-title")
                    logo=attr(value,"tvg-logo")
                } else if(value.isNotEmpty() && !value.startsWith("#") && title!=null) {
                    if((value.startsWith("http://")||value.startsWith("https://")) && value.length<8192 && result.size<15000) {
                        val clean=title!!.take(180)
                        val actualKind=if(kind=="TV") "TV" else classify(MediaEntry(clean,value,group,logo,"VOD"))
                        result.add(MediaEntry(clean,value,group,logo,actualKind))
                    }
                    title=null; group=""; logo=""
                }
            }
        }
        return result.distinctBy { normalize(it.title)+"|"+it.url.substringBefore('?') }
    } finally { conn.disconnect() }
}

private fun attr(line:String,key:String):String {
    val match=Regex("""$key="([^"]*)"""",RegexOption.IGNORE_CASE).find(line)
    return match?.groupValues?.getOrNull(1).orEmpty()
}
private fun normalize(s:String)=Normalizer.normalize(s,Normalizer.Form.NFD).replace(Regex("\\p{M}+"),"").lowercase()

@Composable
private fun PlayerScreen(entry:MediaEntry,onBack:()->Unit) {
    val context=LocalContext.current
    val owner= LocalLifecycleOwner.current
    val exoPlayer= remember(entry.url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(entry.url))
            playWhenReady=true
            prepare()
        }
    }
    DisposableEffect(owner,exoPlayer) {
        val observer=LifecycleEventObserver { _,event ->
            if(event==Lifecycle.Event.ON_PAUSE) exoPlayer.pause()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer); exoPlayer.release() }
    }
    BackHandlerCompat(onBack)
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
            Text("‹  VOLTAR",color=Accent,fontWeight=FontWeight.Bold,modifier=Modifier.clickable { onBack() })
            Spacer(Modifier.width(14.dp))
            Text(entry.title,color=Color.White,fontSize=14.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
        }
        AndroidView(factory={ ctx ->
            PlayerView(ctx).apply {
                this.player=exoPlayer
                useController=true
                controllerShowTimeoutMs=3000
                layoutParams=ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)
            }
        }, update={ it.player=exoPlayer }, modifier=Modifier.fillMaxWidth().weight(1f))
        Text(entry.group.ifBlank { entry.kind },color=Muted,fontSize=11.sp,modifier=Modifier.padding(16.dp))
    }
}

@Composable
private fun BackHandlerCompat(onBack:()->Unit) {
    androidx.activity.compose.BackHandler(onBack=onBack)
}
