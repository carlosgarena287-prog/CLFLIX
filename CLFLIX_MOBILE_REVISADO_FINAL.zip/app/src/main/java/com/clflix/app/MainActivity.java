package com.clflix.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.provider.Settings;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9, 9, 12);
    private final int PANEL = Color.rgb(24, 24, 30);
    private final int RED = Color.rgb(238,  forty(),  sixty());
    private LinearLayout root;

    private int forty() { return 48; }
    private int sixty() { return 72; }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        showSplash();
    }

    private void showSplash() {
        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(BG);
        TextView logo = new TextView(this);
        logo.setText("CLFLIX");
        logo.setTextColor(RED);
        logo.setTextSize(38);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        splash.addView(logo);
        TextView dots = new TextView(this);
        dots.setText("●  ●  ●");
        dots.setTextColor(Color.LTGRAY);
        dots.setTextSize(12);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-2, -2);
        dp.topMargin = 20;
        splash.addView(dots, dp);
        TextView caption = new TextView(this);
        caption.setText("PREPARANDO SUA EXPERIÊNCIA");
        caption.setTextColor(Color.GRAY);
        caption.setTextSize(10);
        caption.setLetterSpacing(0.16f);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
        cp.topMargin = 16;
        splash.addView(caption, cp);
        setContentView(splash);

        Animation fade = new AlphaAnimation(0.35f, 1f);
        fade.setDuration(650);
        fade.setRepeatMode(Animation.REVERSE);
        fade.setRepeatCount(Animation.INFINITE);
        logo.startAnimation(fade);
        Animation bounce = new TranslateAnimation(0, 0, 0, -dp(7));
        bounce.setDuration(420);
        bounce.setRepeatMode(Animation.REVERSE);
        bounce.setRepeatCount(Animation.INFINITE);
        dots.startAnimation(bounce);
        splash.postDelayed(this::showHome, 1900);
    }

    private void showHome() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(28));
        root.setBackgroundColor(BG);
        scroll.addView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("CLFLIX", 26, RED, true);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView settings = text("⚙", 25, Color.WHITE, true);
        settings.setPadding(dp(12), dp(6), dp(4), dp(6));
        settings.setOnClickListener(v -> showSettings());
        top.addView(settings);
        root.addView(top);

        TextView tagline = text("SEU PRÓXIMO FILME COMEÇA AQUI", 10, Color.GRAY, true);
        tagline.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams tlp = params(-2, -2, 0, 4, 0, 18);
        root.addView(tagline, tlp);

        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.GRAY);
        search.setHint("Pesquisar filmes e séries");
        search.setTextSize(15);
        search.setPadding(dp(16), 0, dp(12), 0);
        search.setCompoundDrawablePadding(dp(8));
        search.setBackground(round(PANEL, 14));
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(54)));
        search.setOnEditorActionListener((v, actionId, event) -> {
            String q = search.getText().toString().trim();
            if (!q.isEmpty()) Toast.makeText(this, "A pesquisa online será ativada após configurar a chave oficial do catálogo.", Toast.LENGTH_LONG).show();
            return true;
        });

        TextView heroTitle = text("ENTRETENIMENTO\nDO SEU JEITO", 27, Color.WHITE, true);
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18), dp(20), dp(18), dp(20));
        hero.setBackground(round(Color.rgb(48, 13, 20), 18));
        TextView heroKicker = text("BEM-VINDO AO", 10, Color.rgb(255, 150, 160), true);
        hero.addView(heroKicker);
        hero.addView(heroTitle, params(-1, -2, 0, 8, 0, 8));
        TextView heroSub = text("Sua central de filmes e séries, com uma experiência simples e elegante.", 13, Color.LTGRAY, false);
        hero.addView(heroSub);
        root.addView(hero, params(-1, -2, 0, 18, 0, 22));

        addSection("EXPLORE", "A pesquisa online e o catálogo real serão conectados com uma fonte de metadados autorizada.");
        addAction("Filmes", "Explore títulos e descubra informações", () -> showInfo("Filmes", "O catálogo online será conectado após configurar uma chave TMDB."));
        addAction("Séries", "Temporadas, episódios e detalhes", () -> showInfo("Séries", "A seção de séries está preparada para receber o catálogo online."));
        addAction("Minha lista", "Seus favoritos ficam neste aparelho", () -> showInfo("Minha lista", "A sincronização de favoritos será adicionada junto com o sistema de contas."));
        addAction("Histórico", "Continue de onde parou", () -> showInfo("Histórico", "O histórico será integrado quando houver reprodução autorizada."));

        TextView privacy = text("PRIVACIDADE E PROTEÇÃO", 11, Color.GRAY, true);
        root.addView(privacy, params(-1, -2, 0, 24, 0, 8));
        Button dns = button("CONFIGURAR DNS ADGUARD FAMILY");
        dns.setOnClickListener(v -> openPrivateDns());
        root.addView(dns, new LinearLayout.LayoutParams(-1, dp(48)));
        TextView dnsNote = text("O Android solicitará que você configure o DNS privado. Endereço: family.adguard-dns.com", 11, Color.GRAY, false);
        root.addView(dnsNote, params(-1, -2, 0, 8, 0, 0));

        TextView footer = text("CLFLIX MOBILE • VERSÃO INICIAL", 10, Color.DKGRAY, true);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, params(-1, -2, 0, 28, 0, 0));
        setContentView(scroll);
        root.setAlpha(0f);
        root.animate().alpha(1f).setDuration(350).start();
    }

    private void addSection(String title, String description) {
        root.addView(text(title, 12, RED, true), params(-1, -2, 0, 0, 0, 6));
        root.addView(text(description, 13, Color.LTGRAY, false), params(-1, -2, 0, 0, 0, 12));
    }

    private void addAction(String title, String subtitle, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(round(PANEL, 14));
        TextView t = text(title, 17, Color.WHITE, true);
        TextView s = text(subtitle, 12, Color.GRAY, false);
        card.addView(t);
        card.addView(s, params(-1, -2, 0, 4, 0, 0));
        card.setOnClickListener(v -> action.run());
        root.addView(card, params(-1, -2, 0, 0, 0, 10));
    }

    private void showSettings() {
        showInfo("Configurações", "Use o botão de DNS AdGuard Family na tela inicial. O aplicativo não altera o DNS do Android sem sua confirmação.");
    }

    private void openPrivateDns() {
        try {
            startActivity(new Intent(Settings.ACTION_PRIVATE_DNS_SETTINGS));
        } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); }
            catch (Exception ignored) { Toast.makeText(this, "Abra Configurações > Rede e Internet > DNS privado.", Toast.LENGTH_LONG).show(); }
        }
    }

    private void showInfo(String title, String message) {
        new android.app.AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(round(RED, 12));
        return b;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private LinearLayout.LayoutParams params(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
