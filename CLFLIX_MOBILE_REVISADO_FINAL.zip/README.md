# CLFLIX Mobile

Projeto Android nativo em Java, com interface inicial CLFLIX.

## Requisitos
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Android SDK Platform 35
- Android Build Tools 35.0.0

## GitHub Actions
O workflow fica em `.github/workflows/main.yml`.

Ele aceita duas formas de envio:
1. Enviar `CLFLIX_MOBILE_PRONTO_GITHUB.zip` para a raiz do repositório; ou
2. Extrair o ZIP e enviar o conteúdo diretamente para a raiz.

O workflow instala os componentes Android, valida a estrutura, executa `clean assembleDebug`, publica o APK e preserva o log da compilação mesmo quando ela falha.

O APK de depuração, quando a compilação passa, aparece no artefato `CLFLIX-Mobile-APK`.

## Observação
O catálogo online e a reprodução de conteúdo ainda não estão implementados nesta versão inicial. A tela informa isso explicitamente; não apresenta dados fictícios como catálogo real.
