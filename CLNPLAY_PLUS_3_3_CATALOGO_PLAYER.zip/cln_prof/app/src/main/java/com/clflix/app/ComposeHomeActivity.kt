package com.clflix.app

import android.content.Context
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer

private val Bg = Color(0xFF08090D)
private val Panel = Color(0xFF151821)
private val Accent = Color(0xFFE50935)
private val Muted = Color(0xFF9AA1B2)

class ComposeHomeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8,9,13)
        window.navigationBarColor = android.graphics.Color.rgb(8,9,13)
        setContent { MaterialTheme(colorScheme = darkColorScheme(
            primary=Accent, background=Bg, surface=Panel, onPrimary=Color.White,
            onBackground=Color.White, onSurface=Color.White
        )) { ClnApp() } }
    }
}

data class MediaEntry(
    val title:String, val url:String, val group:String, val logo:String="", val kind:String="TV",
    val country:String="", val tvgId:String="", val source:String="",
    val norm:String="", val adult:Boolean=false
)

private const val TV_LIST = "https://iptv-org.github.io/iptv/countries/br.m3u"
private const val GLOBAL_TV_LIST = "https://iptv-org.github.io/iptv/index.m3u"
private const val MOVIE_LIST = "https://raw.githubusercontent.com/Ramys/Iptv-Brasil-2026/master/Filmes-Series.m3u8"
private const val USER_ASSET = "lista_usuario.m3u"
private const val PAGE_SIZE = 50

/** Estado independente de cada secao (TV, Filmes, Series): itens, carregamento, pesquisa e paginacao. */
private class SectionState {
    var items by mutableStateOf<List<MediaEntry>>(emptyList())
    var loaded by mutableStateOf(false)
    var loading by mutableStateOf(false)
    var error by mutableStateOf("")
    var query by mutableStateOf("")
    var limit by mutableIntStateOf(PAGE_SIZE)
    var category by mutableStateOf("")
}

private class CatalogResult(val items: List<MediaEntry>, val warning: String)

@Composable
private fun rememberDebounced(value: String, delayMs: Long = 350L): String {
    var out by remember { mutableStateOf(value) }
    LaunchedEffect(value) { delay(delayMs); out = value }
    return out
}

@Composable
private fun ClnApp() {
    val context= LocalContext.current
    val scope= rememberCoroutineScope()
    val prefs= remember { context.getSharedPreferences("clnplay_settings", Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf("INÍCIO") }
    var selected by remember { mutableStateOf<MediaEntry?>(null) }
    val tvS= remember { SectionState() }
    val moviesS= remember { SectionState() }
    val seriesS= remember { SectionState() }
    var homeQuery by remember { mutableStateOf("") }
    var tvUrl by remember { mutableStateOf(prefs.getString("tvUrl", TV_LIST) ?: TV_LIST) }
    var extraUrl by remember { mutableStateOf(prefs.getString("extraUrl", "") ?: "") }
    var vodUrl by remember { mutableStateOf(prefs.getString("vodUrl", MOVIE_LIST) ?: MOVIE_LIST) }
    var showSettings by remember { mutableStateOf(false) }
    var adultBlock by remember { mutableStateOf(prefs.getBoolean("adultBlock", true)) }
    var brazilOnly by remember { mutableStateOf(prefs.getBoolean("brazilOnly", true)) }

    // Pesquisa independente por secao, com atraso de 350 ms.
    val dqTv= rememberDebounced(tvS.query)
    val dqMovies= rememberDebounced(moviesS.query)
    val dqSeries= rememberDebounced(seriesS.query)
    val dqHome= rememberDebounced(homeQuery)
    // A paginacao volta para 50 somente quando o filtro daquela secao muda.
    LaunchedEffect(dqTv, tvS.category, adultBlock, brazilOnly) { tvS.limit=PAGE_SIZE }
    LaunchedEffect(dqMovies, adultBlock) { moviesS.limit=PAGE_SIZE }
    LaunchedEffect(dqSeries, adultBlock) { seriesS.limit=PAGE_SIZE }

    fun loadTv(force: Boolean = false) {
        if (tvS.loading) return
        if (!force && tvS.loaded) return
        tvS.loading = true
        tvS.error = ""
        val mainUrl = tvUrl
        val extra = extraUrl
        val onlyBr = brazilOnly
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { loadTvCatalog(context, mainUrl, extra, onlyBr) }
                tvS.items = result.items
                tvS.loaded = true
                tvS.error = if (result.items.isEmpty()) "A playlist de TV não trouxe canais válidos. ${result.warning}".trim() else result.warning
            } catch (e: Exception) {
                tvS.error = e.message ?: "Não foi possível carregar a TV ao vivo."
            } finally {
                tvS.loading = false
            }
        }
    }

    // Filmes e séries vêm da mesma playlist: baixa uma vez e preenche as duas seções,
    // cada uma com seu próprio estado, pesquisa e paginação.
    fun loadVod(force: Boolean = false) {
        if (moviesS.loading || seriesS.loading) return
        if (!force && moviesS.loaded && seriesS.loaded) return
        moviesS.loading = true; seriesS.loading = true
        moviesS.error = ""; seriesS.error = ""
        val address = vodUrl
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { loadM3u(address, "VOD", "Filmes e séries") }
                moviesS.items = result.filter { it.kind == "FILMES" }
                seriesS.items = result.filter { it.kind == "SÉRIES" }
                moviesS.loaded = true; seriesS.loaded = true
                if (moviesS.items.isEmpty()) moviesS.error = "Nenhum filme encontrado na playlist."
                if (seriesS.items.isEmpty()) seriesS.error = "Nenhuma série encontrada na playlist."
            } catch (e: Exception) {
                val msg = e.message ?: "Não foi possível carregar filmes e séries."
                moviesS.error = msg; seriesS.error = msg
            } finally {
                moviesS.loading = false; seriesS.loading = false
            }
        }
    }

    fun openSection(section: String) {
        tab = section
        when (section) {
            "TV AO VIVO" -> loadTv()
            "FILMES", "SÉRIES" -> loadVod()
        }
    }

    val tvFiltered = remember(tvS.items, dqTv, tvS.category, adultBlock) { filterEntries(tvS.items, dqTv, tvS.category, adultBlock) }
    val moviesFiltered = remember(moviesS.items, dqMovies, adultBlock) { filterEntries(moviesS.items, dqMovies, "", adultBlock) }
    val seriesFiltered = remember(seriesS.items, dqSeries, adultBlock) { filterEntries(seriesS.items, dqSeries, "", adultBlock) }
    val tvCategories = remember(tvS.items) {
        tvS.items.flatMap { it.group.split(';') }.map { it.trim() }.filter { it.isNotEmpty() }
            .groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(12).map { it.key }
    }
    val homeItems = remember(tvS.items, moviesS.items, seriesS.items, dqHome, adultBlock) {
        if (dqHome.isBlank()) {
            filterEntries(tvS.items, "", "", adultBlock).take(12) +
                filterEntries(moviesS.items, "", "", adultBlock).take(12) +
                filterEntries(seriesS.items, "", "", adultBlock).take(12)
        } else {
            filterEntries(tvS.items, dqHome, "", adultBlock).take(PAGE_SIZE) +
                filterEntries(moviesS.items, dqHome, "", adultBlock).take(PAGE_SIZE) +
                filterEntries(seriesS.items, dqHome, "", adultBlock).take(PAGE_SIZE)
        }
    }

    if(selected!=null) {
        PlayerScreen(entry=selected!!, onBack={ selected=null })
        return
    }

    val activeQuery = when (tab) {
        "TV AO VIVO" -> tvS.query
        "FILMES" -> moviesS.query
        "SÉRIES" -> seriesS.query
        else -> homeQuery
    }
    fun setActiveQuery(value: String) {
        when (tab) {
            "TV AO VIVO" -> tvS.query = value
            "FILMES" -> moviesS.query = value
            "SÉRIES" -> seriesS.query = value
            else -> homeQuery = value
        }
    }
    val activeError = when (tab) {
        "TV AO VIVO" -> tvS.error
        "FILMES" -> moviesS.error
        "SÉRIES" -> seriesS.error
        else -> ""
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=18.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("CLNPLAY", fontSize=25.sp, fontWeight=FontWeight.Black, color=Color.White, letterSpacing=1.sp)
                Text("PLUS  •  SEU ENTRETENIMENTO", fontSize=9.sp, color=Accent, fontWeight=FontWeight.Bold, letterSpacing=2.sp)
            }
            TextButton(onClick={showSettings=true}) { Text("LISTAS", color=Color.White) }
            TextButton(onClick={
                when (tab) {
                    "TV AO VIVO" -> loadTv(true)
                    "FILMES", "SÉRIES" -> loadVod(true)
                    else -> openSection("TV AO VIVO")
                }
            }) { Text("↻", color=Accent, fontSize=22.sp) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal=12.dp), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            listOf("INÍCIO","TV AO VIVO","FILMES","SÉRIES").forEach { name ->
                val active=tab==name
                Box(Modifier.weight(1f).background(if(active) Accent else Panel, RoundedCornerShape(10.dp))
                    .clickable { if(name=="INÍCIO") tab=name else openSection(name) }.padding(vertical=12.dp), contentAlignment=Alignment.Center) {
                    Text(name, fontSize=10.sp, fontWeight=FontWeight.Bold, color=Color.White)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        if(tab=="INÍCIO") {
            Column(Modifier.fillMaxWidth().padding(horizontal=18.dp).background(
                Brush.linearGradient(listOf(Color(0xFF29202B),Color(0xFF111722))),
                RoundedCornerShape(18.dp)).padding(20.dp)) {
                Text("ENTRETENIMENTO SEM COMPLICAÇÃO", color=Muted, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=1.sp)
                Text("Tudo em um só lugar.", color=Color.White, fontSize=25.sp, fontWeight=FontWeight.ExtraBold)
                Text("TV ao vivo, filmes e séries em um único aplicativo.", color=Muted, fontSize=12.sp)
                Spacer(Modifier.height(14.dp))
                Button(onClick={openSection("TV AO VIVO")}, colors=ButtonDefaults.buttonColors(containerColor=Accent)) { Text("EXPLORAR AGORA") }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=12.dp).background(Panel, RoundedCornerShape(12.dp)).padding(horizontal=14.dp, vertical=11.dp), verticalAlignment=Alignment.CenterVertically) {
            Text("⌕", color=Muted, fontSize=20.sp)
            Spacer(Modifier.width(8.dp))
            BasicTextField(value=activeQuery, onValueChange={ setActiveQuery(it) }, singleLine=true,
                modifier=Modifier.weight(1f), textStyle=androidx.compose.ui.text.TextStyle(color=Color.White,fontSize=14.sp),
                decorationBox={ inner -> if(activeQuery.isEmpty()) Text(
                    when (tab) {
                        "TV AO VIVO" -> "Buscar canais..."
                        "FILMES" -> "Buscar filmes..."
                        "SÉRIES" -> "Buscar séries..."
                        else -> "Buscar canais, filmes ou séries..."
                    }, color=Muted, fontSize=13.sp); inner() })
        }
        when (tab) {
            "TV AO VIVO" -> SectionBody(
                state=tvS, filtered=tvFiltered, categories=tvCategories,
                loadingText="Carregando canais ao vivo…", onLoad={ loadTv() }, onOpen={ selected=it })
            "FILMES" -> SectionBody(
                state=moviesS, filtered=moviesFiltered, categories=emptyList(),
                loadingText="Carregando filmes…", onLoad={ loadVod() }, onOpen={ selected=it })
            "SÉRIES" -> SectionBody(
                state=seriesS, filtered=seriesFiltered, categories=emptyList(),
                loadingText="Carregando séries…", onLoad={ loadVod() }, onOpen={ selected=it })
            else -> {
                Row(Modifier.fillMaxWidth().padding(horizontal=18.dp, vertical=4.dp), verticalAlignment=Alignment.CenterVertically) {
                    Text(if(dqHome.isBlank()) "DESTAQUES DO CATÁLOGO" else "RESULTADOS DA BUSCA", color=Color.White, fontWeight=FontWeight.Bold, fontSize=14.sp)
                    Spacer(Modifier.weight(1f))
                    Text("${homeItems.size} itens", color=Muted, fontSize=11.sp)
                }
                if(homeItems.isEmpty()) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment=Alignment.Center) {
                        Text("Abra TV AO VIVO, FILMES ou SÉRIES para carregar o catálogo.", color=Muted, fontSize=12.sp, modifier=Modifier.padding(24.dp))
                    }
                } else {
                    LazyColumn(Modifier.weight(1f), contentPadding=PaddingValues(start=14.dp,end=14.dp,bottom=24.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        items(homeItems) { entry -> EntryRow(entry) { selected=it } }
                    }
                }
            }
        }
        if(activeError.isNotBlank()) Text(activeError,color=Color(0xFFFF788B),fontSize=11.sp,modifier=Modifier.padding(12.dp))
        Row(Modifier.fillMaxWidth().background(Color(0xFF10131A)).padding(vertical=9.dp),horizontalArrangement=Arrangement.SpaceEvenly) {
            Text("CLNPLAY+  •  VERSÃO NOVA",color=Muted,fontSize=9.sp)
            Text("PLAYER INTEGRADO",color=Muted,fontSize=9.sp)
        }
    }

    if(showSettings) AlertDialog(
        onDismissRequest={showSettings=false},
        containerColor=Panel,
        title={Text("Fontes de conteúdo",color=Color.White)},
        text={
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Text("Playlist M3U da TV",color=Muted,fontSize=11.sp)
                OutlinedTextField(tvUrl,{tvUrl=it},singleLine=true)
                Text("Playlist M3U extra da TV (opcional)",color=Muted,fontSize=11.sp)
                OutlinedTextField(extraUrl,{extraUrl=it},singleLine=true)
                Text("Playlist M3U de filmes e séries",color=Muted,fontSize=11.sp)
                OutlinedTextField(vodUrl,{vodUrl=it},singleLine=true)
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Checkbox(checked=brazilOnly,onCheckedChange={
                        brazilOnly=it
                        prefs.edit().putBoolean("brazilOnly", it).apply()
                        tvS.loaded=false; tvS.items=emptyList()
                    })
                    Text("Ocultar canais explicitamente estrangeiros",color=Color.White,fontSize=12.sp)
                }
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Checkbox(checked=adultBlock,onCheckedChange={
                        adultBlock=it
                        prefs.edit().putBoolean("adultBlock", it).apply()
                    })
                    Text("Bloquear conteúdo adulto (recomendado)",color=Color.White,fontSize=12.sp)
                }
                Text("Sem baixar capas. Cada seção mostra 50 itens por vez; use CARREGAR MAIS para avançar. A pesquisa procura em todo o catálogo.",color=Muted,fontSize=10.sp)
            }
        },
        confirmButton={TextButton(onClick={
            showSettings=false
            prefs.edit().putString("tvUrl", tvUrl).putString("extraUrl", extraUrl).putString("vodUrl", vodUrl).apply()
            tvS.loaded=false; tvS.items=emptyList()
            moviesS.loaded=false; moviesS.items=emptyList()
            seriesS.loaded=false; seriesS.items=emptyList()
            if(tab=="TV AO VIVO") loadTv(true)
            else if(tab=="FILMES" || tab=="SÉRIES") loadVod(true)
        }){Text("SALVAR",color=Accent)}},
        dismissButton={TextButton(onClick={showSettings=false}){Text("FECHAR",color=Muted)}}
    )
}

@Composable
private fun ColumnScope.SectionBody(
    state: SectionState,
    filtered: List<MediaEntry>,
    categories: List<String>,
    loadingText: String,
    onLoad: () -> Unit,
    onOpen: (MediaEntry) -> Unit
) {
    if (state.loading) {
        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment=Alignment.Center) {
            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                CircularProgressIndicator(color=Accent)
                Spacer(Modifier.height(12.dp))
                Text(loadingText, color=Muted)
            }
        }
    } else if (!state.loaded) {
        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment=Alignment.Center) {
            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                Text("Seu catálogo está esperando.", color=Color.White, fontSize=18.sp, fontWeight=FontWeight.Bold)
                Text("Carregue as playlists para começar.", color=Muted, fontSize=12.sp)
                Spacer(Modifier.height(14.dp))
                Button(onClick=onLoad, colors=ButtonDefaults.buttonColors(containerColor=Accent)) { Text("CARREGAR CONTEÚDO") }
            }
        }
    } else {
        if (categories.isNotEmpty()) {
            LazyRow(Modifier.fillMaxWidth(), contentPadding=PaddingValues(horizontal=16.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                item { CategoryChip("Todas", state.category.isEmpty()) { state.category = "" } }
                items(categories) { name -> CategoryChip(name, state.category == name) { state.category = name } }
            }
            Spacer(Modifier.height(8.dp))
        }
        val visible = filtered.take(state.limit)
        Row(Modifier.fillMaxWidth().padding(horizontal=18.dp, vertical=4.dp), verticalAlignment=Alignment.CenterVertically) {
            Text(if (state.category.isEmpty()) "CATÁLOGO" else state.category.uppercase(), color=Color.White, fontWeight=FontWeight.Bold, fontSize=14.sp)
            Spacer(Modifier.weight(1f))
            Text("${visible.size} de ${filtered.size} itens", color=Muted, fontSize=11.sp)
        }
        if (filtered.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment=Alignment.Center) {
                Text("Nenhum item encontrado.", color=Muted, fontSize=13.sp)
            }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding=PaddingValues(start=14.dp,end=14.dp,bottom=24.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                items(visible) { entry -> EntryRow(entry, onOpen) }
                if (visible.size < filtered.size) {
                    item { LoadMoreButton(filtered.size - visible.size) { state.limit += PAGE_SIZE } }
                }
            }
        }
    }
}

@Composable
private fun CategoryChip(label: String, active: Boolean, onClick: () -> Unit) {
    Box(Modifier.background(if (active) Accent else Panel, RoundedCornerShape(20.dp))
        .clickable(onClick = onClick).padding(horizontal=14.dp, vertical=8.dp)) {
        Text(label, color=Color.White, fontSize=11.sp, fontWeight=FontWeight.Bold, maxLines=1)
    }
}

@Composable
private fun EntryRow(entry: MediaEntry, onOpen: (MediaEntry) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(12.dp)).clickable { onOpen(entry) }.padding(13.dp), verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(Color(0xFF242A37),RoundedCornerShape(9.dp)),contentAlignment=Alignment.Center) {
            Text(if(entry.kind=="TV") "▶" else "▣",color=Accent,fontSize=18.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(entry.title,color=Color.White,fontSize=13.sp,fontWeight=FontWeight.SemiBold,maxLines=2,overflow=TextOverflow.Ellipsis)
            Text(entry.group.replace(";", "  •  ").ifBlank { if(entry.kind=="TV") "TV AO VIVO" else entry.kind },color=Muted,fontSize=10.sp,maxLines=1)
        }
        Text("ASSISTIR  ›",color=Accent,fontSize=9.sp,fontWeight=FontWeight.Bold)
    }
}

@Composable
private fun LoadMoreButton(remaining: Int, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().padding(vertical=6.dp)
        .background(Brush.horizontalGradient(listOf(Accent, Color(0xFFFF5A7A))), RoundedCornerShape(16.dp))
        .clickable(onClick = onClick).padding(vertical=14.dp), contentAlignment=Alignment.Center) {
        Column(horizontalAlignment=Alignment.CenterHorizontally) {
            Text("CARREGAR MAIS", color=Color.White, fontWeight=FontWeight.Black, fontSize=14.sp, letterSpacing=1.sp)
            Text("+${minOf(PAGE_SIZE, remaining)}  •  restam $remaining", color=Color(0xFFFFD6DE), fontSize=10.sp)
        }
    }
}

/** Pesquisa no catalogo completo da secao (nao depende do que ja esta visivel na tela). */
private fun filterEntries(list: List<MediaEntry>, query: String, category: String, blockAdult: Boolean): List<MediaEntry> {
    val terms = normalize(query.trim()).split(' ').filter { it.isNotEmpty() }
    return list.filter { e ->
        (!blockAdult || !e.adult) &&
            (category.isEmpty() || e.group.split(';').any { it.trim() == category }) &&
            terms.all { e.norm.contains(it) }
    }
}

private fun loadTvCatalog(context: Context, tvUrl: String, extraUrl: String, brazilOnly: Boolean): CatalogResult {
    val all = ArrayList<MediaEntry>()
    val warnings = ArrayList<String>()
    fun attempt(label: String, block: () -> List<MediaEntry>) {
        try { all.addAll(block()) } catch (e: Exception) { warnings.add("$label: ${e.message ?: "falha ao carregar"}") }
    }
    attempt("Lista da TV") { loadM3u(tvUrl, "TV", "Lista da TV") }
    if (!brazilOnly) attempt("Lista mundial") { loadM3u(GLOBAL_TV_LIST, "TV", "Lista mundial") }
    attempt("Lista do usuário") { loadAsset(context, USER_ASSET, "TV", "Lista do usuário") }
    if (extraUrl.isNotBlank()) attempt("Lista extra") { loadM3u(extraUrl.trim(), "TV", "Lista extra") }
    // Remove somente o que tem evidência explícita de ser estrangeiro. Sem informação de país, o canal fica.
    val kept = if (brazilOnly) all.filterNot { isForeign(it) } else all
    val unique = kept.distinctBy { dedupeKey(it) }.sortedBy { it.norm }
    return CatalogResult(unique, warnings.joinToString("  •  "))
}

private fun classify(e:MediaEntry):String {
    val title=normalize(e.title)
    val group=normalize(e.group)
    val url=e.url.lowercase()
    if(Regex("temporada|season|episodio|episode|s[0-9]{1,2}\\s?e[0-9]{1,3}|\\bt[0-9]{1,2}\\s?e[0-9]{1,3}\\b|capitulo").containsMatchIn(title)) return "SÉRIES"
    val groupSeries=Regex("(^|[^a-z])(serie|series)([^a-z]|$)").containsMatchIn(group)
    val groupMovie=Regex("filme|movie|cinema").containsMatchIn(group)
    if(groupSeries && !groupMovie) return "SÉRIES"
    if(groupMovie && !groupSeries) return "FILMES"
    if(Regex("/series?/").containsMatchIn(url)) return "SÉRIES"
    return "FILMES"
}

private fun loadAsset(context: Context, name: String, kind: String, source: String): List<MediaEntry> {
    context.assets.open(name).bufferedReader(Charsets.UTF_8).use { return parseM3u(it, kind, source) }
}

private fun loadM3u(address:String, kind:String, source:String):List<MediaEntry> {
    require(address.startsWith("https://") || address.startsWith("http://")) { "Informe um endereço HTTP ou HTTPS válido." }
    val conn=(URL(address).openConnection() as HttpURLConnection).apply {
        connectTimeout=18000; readTimeout=35000; instanceFollowRedirects=true
        setRequestProperty("User-Agent","CLNPLAY-Android/3.0")
        setRequestProperty("Accept","*/*")
    }
    try {
        if(conn.responseCode !in 200..299) throw Exception("A playlist respondeu HTTP ${conn.responseCode}: $address")
        return conn.inputStream.bufferedReader(Charsets.UTF_8).use { parseM3u(it, kind, source) }
    } finally { conn.disconnect() }
}

private fun parseM3u(reader: BufferedReader, kind:String, source:String):List<MediaEntry> {
    val result=ArrayList<MediaEntry>()
    var title:String?=null; var group=""; var logo=""; var country=""; var tvgId=""
    var line:String?
    while(reader.readLine().also { line=it }!=null) {
        val value=line!!.trim()
        if(value.startsWith("#EXTINF:",true)) {
            val comma=value.lastIndexOf(',')
            title=if(comma>=0) value.substring(comma+1).trim() else "Sem título"
            group=attr(value,"group-title")
            logo=attr(value,"tvg-logo")
            country=attr(value,"tvg-country")
            tvgId=attr(value,"tvg-id")
        } else if(value.isNotEmpty() && !value.startsWith("#") && title!=null) {
            if((value.startsWith("http://")||value.startsWith("https://")) && value.length<8192 && result.size<15000) {
                result.add(buildEntry(title!!.take(180), value, group, logo, kind, country, tvgId, source))
            }
            title=null; group=""; logo=""; country=""; tvgId=""
        }
    }
    return result.distinctBy { dedupeKey(it) }
}

private fun buildEntry(title:String, url:String, group:String, logo:String, kind:String, country:String, tvgId:String, source:String):MediaEntry {
    val g=if(kind=="TV") canonicalGroup(group) else group
    val base=MediaEntry(title,url,g,logo,kind,country,tvgId,source)
    val actualKind=if(kind=="TV") "TV" else classify(base)
    return base.copy(kind=actualKind, norm=normalize("$title $g"), adult=isAdultEntry(title,g,url))
}

/** Padroniza as categorias em inglês mais comuns para o português; o restante fica como veio. */
private fun canonicalGroup(raw:String):String {
    if(raw.isBlank()) return ""
    return raw.split(';').map { it.trim() }.filter { it.isNotEmpty() }.joinToString(";") { part ->
        when(normalize(part)) {
            "news" -> "Notícias"
            "sports", "sport" -> "Esportes"
            "kids" -> "Infantil"
            "religious" -> "Religiosos"
            "documentary" -> "Documentários"
            "music" -> "Variedade e Músicas"
            "movies", "series" -> "Filmes e Séries"
            else -> part
        }
    }
}

private fun attr(line:String,key:String):String {
    val match=Regex("""$key="([^"]*)"""",RegexOption.IGNORE_CASE).find(line)
    return match?.groupValues?.getOrNull(1).orEmpty()
}
private fun normalize(s:String)=Normalizer.normalize(s,Normalizer.Form.NFD).replace(Regex("\\p{M}+"),"").lowercase()

private fun dedupeKey(e:MediaEntry):String {
    val clean=normalize(e.title.replace(Regex("""\s*[\(\[][^\)\]]*[\)\]]"""), "")).trim()
    return clean+"|"+e.url.substringBefore('?')
}

private fun isBrazilCode(t:String)=t=="br" || t=="bra" || t=="brazil" || t=="brasil"

/**
 * Só considera estrangeiro quando há evidência explícita: país informado diferente de Brasil
 * (tvg-country) ou sufixo de país diferente de .br no tvg-id. Sem informação, o canal é mantido.
 */
private fun isForeign(e:MediaEntry):Boolean {
    val tokens=normalize(e.country).split(';',',',' ','/').map { it.trim() }.filter { it.isNotEmpty() }
    if(tokens.any { isBrazilCode(it) }) return false
    val group=normalize(e.group)
    if(group.contains("brazil") || group.contains("brasil")) return false
    val idCountry=Regex("""\.([a-z]{2})(@|$)""").find(e.tvgId.lowercase())?.groupValues?.getOrNull(1)
    if(idCountry=="br") return false
    if(tokens.any { it.length==2 }) return true
    if(idCountry!=null) return true
    return false
}

private val adultStrong=Regex("""(^|[^a-z0-9])(xxx|porn|porno|pornografia|hentai|erotic|erotico|erotica|playboy|18\+|\+18|18plus|sexy)([^a-z0-9]|$)""")
private val adultGroup=Regex("""(^|[^a-z0-9])(adult|adults|adulto|adultos|sex|sexo|porn|xxx|erotic|erotico|hentai|18\+|\+18)([^a-z0-9]|$)""")
private val adultUrl=Regex("""(^|[/._-])(xxx|porn|adult)([/._-]|$)""")

/** Termos fortes no título; termos mais amplos só na categoria (evita bloquear "Adult Swim" ou "Sex Education"). */
private fun isAdultEntry(title:String, group:String, url:String):Boolean {
    val t=normalize(title)
    val g=normalize(group)
    return adultStrong.containsMatchIn(t) || adultGroup.containsMatchIn(g) || adultStrong.containsMatchIn(g) ||
        adultUrl.containsMatchIn(url.substringBefore('?').lowercase())
}

private fun fmtTime(ms:Long):String {
    val s=ms/1000
    val h=s/3600; val m=(s%3600)/60; val sec=s%60
    return if(h>0) "%d:%02d:%02d".format(h,m,sec) else "%02d:%02d".format(m,sec)
}

@Composable
private fun PlayerScreen(entry:MediaEntry,onBack:()->Unit) {
    val context=LocalContext.current
    val activity=context as? ComponentActivity
    val owner= LocalLifecycleOwner.current
    var fullscreen by remember { mutableStateOf(true) }
    var controlsVisible by remember { mutableStateOf(true) }
    var touchTick by remember { mutableIntStateOf(0) }
    var resizeIdx by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var isLive by remember { mutableStateOf(true) }
    val resizeModes=remember { listOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_ZOOM, AspectRatioFrameLayout.RESIZE_MODE_FILL) }
    val resizeLabels=remember { listOf("AJUSTAR","PREENCHER","ESTICAR") }

    DisposableEffect(activity) {
        val decor=activity?.window?.decorView
        activity?.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        onDispose {
            activity?.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            @Suppress("DEPRECATION")
            decor?.systemUiVisibility=android.view.View.SYSTEM_UI_FLAG_VISIBLE
        }
    }
    // Tela cheia: esconde/mostra as barras do sistema.
    LaunchedEffect(fullscreen) {
        val decor=activity?.window?.decorView
        @Suppress("DEPRECATION")
        decor?.systemUiVisibility = if(fullscreen) (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
            or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION) else android.view.View.SYSTEM_UI_FLAG_VISIBLE
    }
    val exoPlayer= remember(entry.url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(entry.url))
            playWhenReady=true
            prepare()
        }
    }
    DisposableEffect(owner,exoPlayer) {
        val observer=LifecycleEventObserver { _,event ->
            if(event==Lifecycle.Event.ON_PAUSE) exoPlayer.pause()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer); exoPlayer.release() }
    }
    BackHandlerCompat(onBack)

    // Controles somem sozinhos após 3 segundos; qualquer toque reinicia a contagem.
    LaunchedEffect(controlsVisible, touchTick) {
        if(controlsVisible) { delay(3000); controlsVisible=false }
    }
    // Atualiza posição/estado enquanto os controles estão visíveis.
    LaunchedEffect(exoPlayer, controlsVisible) {
        while(controlsVisible) {
            position=exoPlayer.currentPosition.coerceAtLeast(0L)
            val d=exoPlayer.duration
            duration=if(d==C.TIME_UNSET || d<0L) 0L else d
            playing=exoPlayer.playWhenReady
            isLive=exoPlayer.isCurrentMediaItemLive || d==C.TIME_UNSET || d<=0L
            delay(500)
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory={ ctx ->
            PlayerView(ctx).apply {
                this.player=exoPlayer
                useController=false
                keepScreenOn=true
                resizeMode=AspectRatioFrameLayout.RESIZE_MODE_FIT
                layoutParams=ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)
            }
        }, update={ it.player=exoPlayer; it.resizeMode=resizeModes[resizeIdx] }, modifier=Modifier.fillMaxSize())

        // Camada que recebe o toque na tela: mostra/esconde os controles.
        Box(Modifier.fillMaxSize().pointerInput(Unit) {
            detectTapGestures(onTap={ controlsVisible=!controlsVisible; touchTick++ })
        })

        AnimatedVisibility(visible=controlsVisible, enter=fadeIn(), exit=fadeOut()) {
            Box(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().align(Alignment.TopCenter)
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                    .padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
                    Text("‹  VOLTAR",color=Accent,fontWeight=FontWeight.Bold,modifier=Modifier.clickable { onBack() })
                    Spacer(Modifier.width(14.dp))
                    Text(entry.title,color=Color.White,fontSize=14.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
                }
                Box(Modifier.align(Alignment.Center).size(68.dp).background(Color(0x99000000), RoundedCornerShape(34.dp))
                    .clickable {
                        exoPlayer.playWhenReady=!exoPlayer.playWhenReady
                        playing=exoPlayer.playWhenReady
                        touchTick++
                    }, contentAlignment=Alignment.Center) {
                    Text(if(playing) "❚❚" else "▶", color=Color.White, fontSize=22.sp, fontWeight=FontWeight.Bold)
                }
                Column(Modifier.fillMaxWidth().align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                    .padding(horizontal=16.dp, vertical=12.dp)) {
                    if(!isLive && duration>0L) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Text(fmtTime(position), color=Color.White, fontSize=11.sp)
                            Slider(
                                value=position.toFloat().coerceIn(0f, duration.toFloat()),
                                onValueChange={ v ->
                                    position=v.toLong()
                                    exoPlayer.seekTo(v.toLong())
                                    touchTick++
                                },
                                valueRange=0f..duration.toFloat(),
                                colors=SliderDefaults.colors(thumbColor=Accent, activeTrackColor=Accent),
                                modifier=Modifier.weight(1f).padding(horizontal=8.dp)
                            )
                            Text(fmtTime(duration), color=Color.White, fontSize=11.sp)
                        }
                    } else {
                        Text("● AO VIVO", color=Accent, fontSize=11.sp, fontWeight=FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        PlayerChip("EXPANDIR: ${resizeLabels[resizeIdx]}") { resizeIdx=(resizeIdx+1)%resizeModes.size; touchTick++ }
                        PlayerChip(if(fullscreen) "SAIR DA TELA CHEIA" else "TELA CHEIA") { fullscreen=!fullscreen; touchTick++ }
                        Spacer(Modifier.weight(1f))
                        Text(entry.group.replace(";", "  •  ").ifBlank { entry.kind },color=Muted,fontSize=11.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerChip(label:String, onClick:()->Unit) {
    Box(Modifier.background(Color(0x99000000), RoundedCornerShape(20.dp))
        .clickable(onClick=onClick).padding(horizontal=14.dp, vertical=8.dp)) {
        Text(label, color=Color.White, fontSize=11.sp, fontWeight=FontWeight.Bold)
    }
}

@Composable
private fun BackHandlerCompat(onBack:()->Unit) {
    androidx.activity.compose.BackHandler(onBack=onBack)
}
