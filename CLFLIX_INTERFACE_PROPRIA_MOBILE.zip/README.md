# CLFLIX Mobile

Esta versão inclui uma tela inicial própria do CLFLIX, com identidade visual escura/vermelha e botões para abrir o catálogo. O catálogo e a reprodução ainda são fornecidos pelo site remoto `https://www.pobreflixtv.sale/`.

Ao carregar o site, o app tenta ocultar elementos promocionais identificáveis do Discord, o item de menu “Aplicativo” e textos de marca “PobreFlix”. Essa limpeza depende da estrutura HTML do site e pode precisar de ajustes se o site mudar.

A interface inicial é nativa em HTML local dentro do WebView; não é ainda um catálogo independente com busca, categorias e detalhes próprios. Para isso, é necessário um feed/API autorizado com catálogo, imagens, metadados e URLs de reprodução.

A verificação do Cloudflare não é contornada nem ocultada. Se o serviço exigir verificação, ela será exibida.

## GitHub Actions
O workflow está em `.github/workflows/main.yml`. Envie o conteúdo desta pasta para a raiz do repositório e execute **Build CLFLIX APK** na aba Actions.
