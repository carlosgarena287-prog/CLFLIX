# CLFLIX — projeto Android inicial

Projeto-fonte Android (Java + WebView), não é um APK compilado.

## Recursos
- Interface simples com marca CLFLIX e botão Recarregar.
- Abre https://vidbox.cc/providers dentro da WebView.
- Mantém no app somente navegação HTTPS para vidbox.cc e subdomínios.
- Links HTTP/HTTPS de outros domínios abrem no navegador externo.
- Bloqueia esquemas como file:, javascript: e intent: dentro do app.
- Não hospeda nem armazena vídeos no notebook.

## Limitações
O site pode bloquear WebViews, exigir cookies ou abrir reprodutores externos. Não há garantia de que todos os vídeos funcionem dentro do app. JavaScript está habilitado porque muitos sites precisam dele; use somente serviços em que confia. Utilize o serviço de forma autorizada e respeite os termos do provedor.

## Compilar
Abra a pasta em uma versão atual do Android Studio, com JDK 17 e Android SDK Platform 35, sincronize o Gradle e selecione Build > Build APK(s).

Este projeto-fonte não foi compilado nem testado em aparelho. Em telefone, a compilação depende do ambiente disponível; AndroidIDE foi arquivado/descontinuado e pode não suportar versões recentes do Android Gradle Plugin.


## Compilar sem PC usando GitHub Actions
1. Crie um repositório no GitHub pelo navegador do celular.
2. Envie o conteúdo desta pasta para o repositório (incluindo a pasta oculta `.github/workflows`).
3. Abra a aba **Actions** do repositório e selecione **Build CLFLIX APK**.
4. Quando a execução terminar com sucesso, abra a execução e baixe o artefato **CLFLIX-debug-apk**.
5. Extraia o ZIP baixado para obter `app-debug.apk`.

A compilação em nuvem precisa de uma conta GitHub e pode exigir confirmar a ativação de Actions. O workflow foi preparado, mas ainda não foi executado; não há garantia até o primeiro build. O APK debug é para testes, não é uma versão assinada para publicação.
