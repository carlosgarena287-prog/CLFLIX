package com.clflix.app

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.ViewGroup
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer

private val Bg = Color(0xFF08090D)
private val Panel = Color(0xFF151821)
private val Accent = Color(0xFFE50935)
private val Muted = Color(0xFF9AA1B2)

class ComposeHomeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8,9,13)
        window.navigationBarColor = android.graphics.Color.rgb(8,9,13)
        setContent { MaterialTheme(colorScheme = darkColorScheme(
            primary=Accent, background=Bg, surface=Panel, onPrimary=Color.White,
            onBackground=Color.White, onSurface=Color.White
        )) { ClnApp() } }
    }
}

data class MediaEntry(val title:String, val url:String, val group:String, val logo:String="", val kind:String="TV", val country:String="")
private const val TV_LIST = "https://iptv-org.github.io/iptv/index.m3u"
private const val MOVIE_LIST = "https://raw.githubusercontent.com/Ramys/Iptv-Brasil-2026/master/Filmes-Series.m3u8"

@Composable
private fun ClnApp() {
    val context= LocalContext.current
    val scope= rememberCoroutineScope()
    var tab by remember { mutableStateOf("INÍCIO") }
    var tvQuery by remember { mutableStateOf("") }
    var movieQuery by remember { mutableStateOf("") }
    var seriesQuery by remember { mutableStateOf("") }
    val query = when(tab) { "FILMES" -> movieQuery; "SÉRIES" -> seriesQuery; else -> tvQuery }
    var selected by remember { mutableStateOf<MediaEntry?>(null) }
    var tv by remember { mutableStateOf<List<MediaEntry>>(emptyList()) }
    var movies by remember { mutableStateOf<List<MediaEntry>>(emptyList()) }
    var series by remember { mutableStateOf<List<MediaEntry>>(emptyList()) }
    var loadingSection by remember { mutableStateOf("") }
    var tvLoaded by remember { mutableStateOf(false) }
    var vodLoaded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var tvUrl by remember { mutableStateOf(TV_LIST) }
    var vodUrl by remember { mutableStateOf(MOVIE_LIST) }
    var showSettings by remember { mutableStateOf(false) }
    var showAdult by remember { mutableStateOf(false) }
    var brazilOnly by remember { mutableStateOf(true) }
    var tvVisibleLimit by remember { mutableIntStateOf(1) }
    var movieVisibleLimit by remember { mutableIntStateOf(100) }
    var seriesVisibleLimit by remember { mutableIntStateOf(100) }
    var debouncedQuery by remember { mutableStateOf("") }
    val visibleLimit = when(tab) { "FILMES" -> movieVisibleLimit; "SÉRIES" -> seriesVisibleLimit; "INÍCIO" -> 36; else -> tvVisibleLimit }
    LaunchedEffect(tab, query) { delay(350); debouncedQuery=query }
    LaunchedEffect(debouncedQuery, showAdult, brazilOnly) {
        if (tab == "TV AO VIVO") tvVisibleLimit = 1
        if (tab == "FILMES") movieVisibleLimit = 100
        if (tab == "SÉRIES") seriesVisibleLimit = 100
    }

    fun loadSection(section: String, force: Boolean = false) {
        val isTv = section == "TV AO VIVO"
        if (loadingSection.isNotEmpty()) return
        if (!force && ((isTv && tvLoaded) || (!isTv && vodLoaded))) return
        loadingSection = section
        error = ""
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    if (isTv) {
                        val bundled = loadBundledM3u(context, "TV")
                        val remote = try { loadM3u(tvUrl, "TV") } catch (sourceError: Exception) {
                            if (bundled.isEmpty()) throw sourceError else emptyList()
                        }
                        val allChannels = (bundled + remote).distinctBy { normalize(it.title) + "|" + it.url.substringBefore('?') }
                        if (brazilOnly) allChannels.filterNot { isExplicitlyForeign(it) } else allChannels
                    } else loadM3u(vodUrl, "VOD")
                }
                if (isTv) {
                    tv = result
                    tvLoaded = true
                    if (result.isEmpty()) error = "A playlist de TV não trouxe canais válidos."
                } else {
                    movies = result.filter { classify(it) == "FILMES" }
                    series = result.filter { classify(it) == "SÉRIES" }
                    vodLoaded = true
                    if (result.isEmpty()) error = "A playlist de filmes e séries não trouxe itens válidos."
                }
            } catch (e: Exception) {
                error = e.message ?: "Não foi possível carregar $section."
            } finally {
                loadingSection = ""
            }
        }
    }

    fun openSection(section: String) {
        tab = section
        error = ""
        if (section == "TV AO VIVO") loadSection(section)
        if (section == "FILMES" || section == "SÉRIES") loadSection("VOD")
    }

    val currentList= when(tab) {
        "TV AO VIVO" -> tv.filter { showAdult || !isAdult(it) }
        "FILMES" -> movies.filter { showAdult || !isAdult(it) }
        "SÉRIES" -> series.filter { showAdult || !isAdult(it) }
        else -> (tv.filter { showAdult || !isAdult(it) }.take(12)+
                 movies.filter { showAdult || !isAdult(it) }.take(12)+
                 series.filter { showAdult || !isAdult(it) }.take(12))
    }
    val filtered=currentList.filter { it.title.contains(debouncedQuery, true) || it.group.contains(debouncedQuery,true) }
    val visibleItems=filtered.take(visibleLimit)

    if(selected!=null) {
        PlayerScreen(entry=selected!!, onBack={ selected=null })
        return
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=18.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("CLNPLAY", fontSize=25.sp, fontWeight=FontWeight.Black, color=Color.White, letterSpacing=1.sp)
                Text("PLUS  •  SEU ENTRETENIMENTO", fontSize=9.sp, color=Accent, fontWeight=FontWeight.Bold, letterSpacing=2.sp)
            }
            TextButton(onClick={showSettings=true}) { Text("LISTAS", color=Color.White) }
            TextButton(onClick={if(tab=="TV AO VIVO") loadSection("TV AO VIVO", true) else if(tab=="FILMES" || tab=="SÉRIES") loadSection("VOD", true) else openSection("TV AO VIVO")}) { Text("↻", color=Accent, fontSize=22.sp) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal=12.dp), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            listOf("INÍCIO","TV AO VIVO","FILMES","SÉRIES").forEach { name ->
                val active=tab==name
                Box(Modifier.weight(1f).background(if(active) Accent else Panel, RoundedCornerShape(10.dp))
                    .clickable { if(name=="INÍCIO") { tab=name; query="" } else openSection(name) }.padding(vertical=12.dp), contentAlignment=Alignment.Center) {
                    Text(name, fontSize=10.sp, fontWeight=FontWeight.Bold, color=Color.White)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        if(tab=="INÍCIO") {
            Column(Modifier.fillMaxWidth().padding(horizontal=18.dp).background(
                androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF29202B),Color(0xFF111722))),
                RoundedCornerShape(18.dp)).padding(20.dp)) {
                Text("ENTRETENIMENTO SEM COMPLICAÇÃO", color=Muted, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=1.sp)
                Text("Tudo em um só lugar.", color=Color.White, fontSize=25.sp, fontWeight=FontWeight.ExtraBold)
                Text("TV ao vivo, filmes e séries em um único aplicativo.", color=Muted, fontSize=12.sp)
                Spacer(Modifier.height(14.dp))
                Button(onClick={openSection("TV AO VIVO")}, colors=ButtonDefaults.buttonColors(containerColor=Accent)) { Text("EXPLORAR AGORA") }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=12.dp).background(Panel, RoundedCornerShape(12.dp)).padding(horizontal=14.dp, vertical=11.dp), verticalAlignment=Alignment.CenterVertically) {
            Text("⌕", color=Muted, fontSize=20.sp)
            Spacer(Modifier.width(8.dp))
            BasicTextField(value=query, onValueChange={ value ->
                when(tab) { "FILMES" -> movieQuery=value; "SÉRIES" -> seriesQuery=value; else -> tvQuery=value }
            }, singleLine=true,
                modifier=Modifier.weight(1f), textStyle=androidx.compose.ui.text.TextStyle(color=Color.White,fontSize=14.sp),
                decorationBox={ inner -> if(query.isEmpty()) Text("Buscar canais, filmes ou séries...",color=Muted,fontSize=13.sp); inner() })
        }
        if ((tab=="TV AO VIVO" && !tvLoaded && loadingSection.isEmpty()) || ((tab=="FILMES" || tab=="SÉRIES") && !vodLoaded && loadingSection.isEmpty())) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment=Alignment.Center) {
                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                    Text("Seu catálogo está esperando.", color=Color.White, fontSize=18.sp, fontWeight=FontWeight.Bold)
                    Text("Carregue as playlists para começar.", color=Muted, fontSize=12.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick={loadSection(if(tab=="TV AO VIVO") "TV AO VIVO" else "VOD")}, colors=ButtonDefaults.buttonColors(containerColor=Accent)) { Text("CARREGAR CONTEÚDO") }
                }
            }
        } else if(loadingSection==tab || (loadingSection=="VOD" && (tab=="FILMES" || tab=="SÉRIES"))) {
            Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center) {
                Column(horizontalAlignment=Alignment.CenterHorizontally) { CircularProgressIndicator(color=Accent); Spacer(Modifier.height(12.dp)); Text(if(loadingSection=="TV AO VIVO") "Carregando canais ao vivo…" else "Carregando filmes e séries…",color=Muted) }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal=18.dp, vertical=4.dp), verticalAlignment=Alignment.CenterVertically) {
                Text(if(tab=="INÍCIO") "DESTAQUES DO CATÁLOGO" else tab, color=Color.White, fontWeight=FontWeight.Bold, fontSize=14.sp)
                Spacer(Modifier.weight(1f))
                Text("${visibleItems.size} de ${filtered.size} itens", color=Muted, fontSize=11.sp)
            }
            LazyColumn(Modifier.weight(1f), contentPadding=PaddingValues(start=14.dp,end=14.dp,bottom=24.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                items(visibleItems) { entry ->
                    Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(12.dp)).clickable { selected=entry }.padding(13.dp), verticalAlignment=Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(Color(0xFF242A37),RoundedCornerShape(9.dp)),contentAlignment=Alignment.Center) {
                            Text(if(entry.kind=="TV") "▶" else "▣",color=Accent,fontSize=18.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(entry.title,color=Color.White,fontSize=13.sp,fontWeight=FontWeight.SemiBold,maxLines=2,overflow=TextOverflow.Ellipsis)
                            Text(entry.group.ifBlank { if(entry.kind=="TV") "TV AO VIVO" else entry.kind },color=Muted,fontSize=10.sp,maxLines=1)
                        }
                        Text("ASSISTIR  ›",color=Accent,fontSize=9.sp,fontWeight=FontWeight.Bold)
                    }
                }
                if(visibleItems.size < filtered.size) {
                    item {
                        Button(onClick={
                            when(tab) {
                                "TV AO VIVO" -> tvVisibleLimit += 1
                                "FILMES" -> movieVisibleLimit += 100
                                "SÉRIES" -> seriesVisibleLimit += 100
                                else -> Unit
                            }
                        }, modifier=Modifier.fillMaxWidth(),
                            colors=ButtonDefaults.buttonColors(containerColor=Accent)) {
                            Text(if(tab == "TV AO VIVO") "CARREGAR PRÓXIMO CANAL" else "CARREGAR MAIS  •  PRÓXIMOS 100")
                        }
                    }
                }
            }
        }
        if(error.isNotBlank()) Text(error,color=Color(0xFFFF788B),fontSize=11.sp,modifier=Modifier.padding(12.dp))
        Row(Modifier.fillMaxWidth().background(Color(0xFF10131A)).padding(vertical=9.dp),horizontalArrangement=Arrangement.SpaceEvenly) {
            Text("CLNPLAY+  •  VERSÃO NOVA",color=Muted,fontSize=9.sp)
            Text("PLAYER INTEGRADO",color=Muted,fontSize=9.sp)
        }
    }

    if(showSettings) AlertDialog(
        onDismissRequest={showSettings=false},
        containerColor=Panel,
        title={Text("Fontes de conteúdo",color=Color.White)},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Text("Playlist M3U da TV",color=Muted,fontSize=11.sp)
                OutlinedTextField(tvUrl,{tvUrl=it},singleLine=true)
                Text("Playlist M3U de filmes e séries",color=Muted,fontSize=11.sp)
                OutlinedTextField(vodUrl,{vodUrl=it},singleLine=true)
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Checkbox(checked=brazilOnly,onCheckedChange={brazilOnly=it; tvLoaded=false; tv=emptyList()})
                    Text("Ocultar apenas canais identificados como estrangeiros",color=Color.White,fontSize=12.sp)
                }
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Checkbox(checked=showAdult,onCheckedChange={showAdult=it})
                    Text("Permitir conteúdo adulto",color=Color.White,fontSize=12.sp)
                }
                Text("Sem baixar capas. TV carrega um canal por vez; filmes e séries carregam 100 itens por vez.",color=Muted,fontSize=10.sp)
            }
        },
        confirmButton={TextButton(onClick={
            showSettings=false
            tvLoaded=false; vodLoaded=false; tv=emptyList(); movies=emptyList(); series=emptyList()
            if(tab=="TV AO VIVO") loadSection("TV AO VIVO", true)
            else if(tab=="FILMES" || tab=="SÉRIES") loadSection("VOD", true)
        }){Text("SALVAR",color=Accent)}},
        dismissButton={TextButton(onClick={showSettings=false}){Text("FECHAR",color=Muted)}}
    )
}

private fun classify(e:MediaEntry):String {
    val s=(e.group+" "+e.title+" "+e.url).lowercase()
    return if(Regex("temporada|season|epis[oó]dio|episode|s[0-9]{1,2}e[0-9]{1,2}|series|séries").containsMatchIn(s)) "SÉRIES" else "FILMES"
}

private fun loadM3u(address:String, kind:String):List<MediaEntry> {
    require(address.startsWith("https://") || address.startsWith("http://")) { "Informe um endereço HTTP ou HTTPS válido." }
    val conn=(URL(address).openConnection() as HttpURLConnection).apply {
        connectTimeout=18000; readTimeout=35000; instanceFollowRedirects=true
        setRequestProperty("User-Agent","CLNPLAY-Android/3.0")
        setRequestProperty("Accept","*/*")
    }
    try {
        if(conn.responseCode !in 200..299) throw Exception("A playlist respondeu HTTP ${conn.responseCode}: $address")
        val content = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        return parseM3uContent(content, kind)
    } finally { conn.disconnect() }
}

private fun loadBundledM3u(context:android.content.Context, kind:String):List<MediaEntry> {
    return context.assets.open("clnplay_public_channels.m3u").bufferedReader(Charsets.UTF_8).use {
        parseM3uContent(it.readText(), kind)
    }
}

private fun parseM3uContent(content:String, kind:String):List<MediaEntry> {
    val result=ArrayList<MediaEntry>()
    var title:String?=null; var group=""; var logo=""; var country=""
    content.lineSequence().forEach { raw ->
        val value=raw.trim()
        if(value.startsWith("#EXTINF:",true)) {
            // The first comma outside quoted attributes separates metadata from the channel name.
            val comma=value.indexOf(',')
            val info=if(comma>=0) value.substring(comma+1).trim() else "Sem título"
            val inlineUrl=Regex("https?://\\S+",RegexOption.IGNORE_CASE).findAll(info).lastOrNull()?.value
            title=if(inlineUrl!=null) info.substringBefore(inlineUrl).trim().ifBlank { "Sem título" } else info
            group=attr(value,"group-title")
            logo=attr(value,"tvg-logo")
            country=attr(value,"tvg-country")
            if(inlineUrl!=null) {
                addM3uEntry(result,title!!,inlineUrl.trimEnd(','),group,logo,country,kind)
                title=null; group=""; logo=""; country=""
            }
        } else if(value.isNotEmpty() && !value.startsWith("#") && title!=null) {
            if(value.startsWith("http://")||value.startsWith("https://")) addM3uEntry(result,title!!,value,group,logo,country,kind)
            title=null; group=""; logo=""; country=""
        }
    }
    return result.distinctBy { normalize(it.title)+"|"+it.url.substringBefore('?') }
}

private fun addM3uEntry(result:MutableList<MediaEntry>, title:String, url:String, group:String, logo:String, country:String, kind:String) {
    if ((url.startsWith("http://") || url.startsWith("https://")) && url.length < 8192 && result.size < 15000) {
        val clean = title.take(180)
        val actualKind = if (kind == "TV") "TV" else classify(MediaEntry(clean, url, group, logo, "VOD"))
        result.add(MediaEntry(clean, url, group, logo, actualKind, country))
    }
}

private fun attr(line:String,key:String):String {
    val match=Regex("""$key="([^"]*)"""",RegexOption.IGNORE_CASE).find(line)
    return match?.groupValues?.getOrNull(1).orEmpty()
}
private fun normalize(s:String)=Normalizer.normalize(s,Normalizer.Form.NFD).replace(Regex("\\p{M}+"),"").lowercase()

private fun isExplicitlyForeign(e:MediaEntry):Boolean {
    val country = normalize(e.country).trim()
    if (country.isBlank()) return false // país desconhecido não é motivo para excluir
    val knownBrazil = setOf("br", "bra", "brazil", "brasil")
    val countryCodes = country.split(Regex("[,;|]\\s*")).filter { it.isNotBlank() }
    // Um canal só é removido quando há país informado e nenhum dos códigos é brasileiro.
    return countryCodes.isNotEmpty() && countryCodes.none { it in knownBrazil }
}

private fun isAdult(e:MediaEntry):Boolean {
    val text=normalize(e.title+" "+e.group+" "+e.url)
    val terms=listOf("adult","xxx","porn","porno","erotic","erotico","18+","18plus",
        "sexy","hentai","adulto","adults")
    return terms.any { text.contains(it) } || Regex("(^|[^a-z0-9])sex([^a-z0-9]|$)").containsMatchIn(text)
}

@Composable
private fun PlayerScreen(entry:MediaEntry,onBack:()->Unit) {
    val context=LocalContext.current
    val activity=context as? ComponentActivity
    val owner= LocalLifecycleOwner.current
    var expanded by remember(entry.url) { mutableStateOf(false) }
    DisposableEffect(activity) {
        val decor=activity?.window?.decorView
        activity?.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        @Suppress("DEPRECATION")
        decor?.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
            or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        onDispose {
            activity?.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            @Suppress("DEPRECATION")
            decor?.systemUiVisibility=android.view.View.SYSTEM_UI_FLAG_VISIBLE
        }
    }
    val exoPlayer= remember(entry.url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(entry.url))
            playWhenReady=true
            prepare()
        }
    }
    DisposableEffect(owner,exoPlayer) {
        val observer=LifecycleEventObserver { _,event ->
            if(event==Lifecycle.Event.ON_PAUSE) exoPlayer.pause()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer); exoPlayer.release() }
    }
    BackHandlerCompat(onBack)
    Column(Modifier.fillMaxSize().background(Bg)) {
        if (!expanded) {
            Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                Text("‹  VOLTAR",color=Accent,fontWeight=FontWeight.Bold,modifier=Modifier.clickable { onBack() })
                Spacer(Modifier.width(14.dp))
                Text(entry.title,color=Color.White,fontSize=14.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
            }
        }
        AndroidView(factory={ ctx ->
            val container = FrameLayout(ctx)
            val playerView = PlayerView(ctx).apply {
                player=exoPlayer
                useController=true
                controllerShowTimeoutMs=3000
                keepScreenOn=true
                resizeMode=androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                layoutParams=FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)
            }
            val expandButton = TextView(ctx).apply {
                text = "⛶"
                textSize = 27f
                setTextColor(android.graphics.Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(12, 4, 12, 4)
                setBackgroundColor(0x99000000.toInt())
                isClickable = true
                isFocusable = true
            }
            val buttonParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END
            ).apply { topMargin = 12; marginEnd = 12 }
            container.addView(playerView)
            container.addView(expandButton, buttonParams)
            val handler = Handler(Looper.getMainLooper())
            val hideButton = Runnable { expandButton.visibility = View.GONE }
            fun showButton() {
                expandButton.visibility = View.VISIBLE
                handler.removeCallbacks(hideButton)
                handler.postDelayed(hideButton, 3000)
            }
            expandButton.setOnClickListener { expanded = !expanded; showButton() }
            playerView.setOnTouchListener { _, event ->
                if (event.action == android.view.MotionEvent.ACTION_DOWN) showButton()
                false
            }
            showButton()
            container
        }, update={ container ->
            (container.getChildAt(0) as? PlayerView)?.player=exoPlayer
        }, modifier=if (expanded) Modifier.fillMaxSize() else Modifier.fillMaxWidth().weight(1f))
        if (!expanded) {
            Text(entry.group.ifBlank { entry.kind },color=Muted,fontSize=11.sp,modifier=Modifier.padding(16.dp))
        }
    }
}

@Composable
private fun BackHandlerCompat(onBack:()->Unit) {
    androidx.activity.compose.BackHandler(onBack=onBack)
}
