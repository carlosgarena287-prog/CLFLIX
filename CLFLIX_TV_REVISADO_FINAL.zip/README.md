# CLFLIX TV — Android TV / Google TV

Aplicativo Android nativo em Java, desenhado para telas grandes e navegação por controle remoto. Não é uma página web embutida.

## O que já está nesta versão
- Entrada própria para Android TV / Google TV (`LEANBACK_LAUNCHER`) e launcher padrão.
- Layout horizontal, tela cheia e interface escura com identidade CLFLIX.
- Menu superior, destaque principal e prateleiras horizontais.
- Cards focáveis pelo D-pad, com realce ao receber foco.
- Tela de detalhes demonstrativa para os cards.
- Ícone e banner próprios para o launcher da TV.
- Sem dependências externas de bibliotecas.

## Limites honestos desta versão
Os títulos e cards são conteúdo demonstrativo original, não um catálogo real. Não há reprodução de filmes/séries ainda. Para um catálogo independente, é necessário integrar uma fonte autorizada de metadados/imagens e URLs de reprodução. O aplicativo não tenta contornar Cloudflare, autenticação ou proteções do site de terceiros.

## Gerar o APK pelo GitHub Actions
1. Crie um repositório no GitHub (ou use o repositório do CLFLIX TV).
2. Extraia este ZIP no celular/computador.
3. Envie **o conteúdo desta pasta diretamente para a raiz do repositório**. A raiz precisa conter `settings.gradle`, `build.gradle`, `app/` e `.github/`.
4. Faça commit na branch `main`.
5. Abra a aba **Actions** e execute **Build CLFLIX TV APK** (ou aguarde o build automático após o push).
6. Abra a execução concluída e baixe o artefato **CLFLIX-TV-debug-apk**.
7. Transfira `app-debug.apk` para a TV Box e instale. Em alguns aparelhos será necessário permitir instalação pelo gerenciador de arquivos usado.

## Requisitos do build
- JDK 17
- Android SDK Platform 35 / Build Tools 35.0.0
- Gradle 8.9 (configurado no workflow)

Pacote: `com.clflix.tv`  
Versão: `1.0-tv` (versionCode 1)
