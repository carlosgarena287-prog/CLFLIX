package com.clflix.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(7, 8, 13);
    private static final int PANEL = Color.rgb(17, 19, 28);
    private static final int RED = Color.rgb(239, 35, 62);
    private static final int WHITE = Color.rgb(247, 247, 250);
    private static final int MUTED = Color.rgb(155, 160, 174);
    private LinearLayout content;
    private LinearLayout navBar;
    private String activeSection = "INÍCIO";
    private final String[] titles = {"O ÚLTIMO\nHORIZONTE", "CÓDIGO\nSOMBRA", "ALÉM DO\nTEMPO", "OPERAÇÃO\nNOTURNA", "MUNDO\nSECRETO", "LINHA DE\nFRENTE"};
    private final String[] subtitles = {"AVENTURA • 2026", "SUSPENSE • 2026", "FICÇÃO • 2025", "AÇÃO • 2025", "FANTASIA • 2025", "DRAMA • 2024"};
    private final int[][] palettes = {{0xff5b203b,0xff171b31},{0xff163b50,0xff111522},{0xff46305f,0xff171421},{0xff71331f,0xff1c1820},{0xff245348,0xff111a22},{0xff59452b,0xff191923}};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        buildHome();
    }

    private void buildHome() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(54), dp(26), dp(54), dp(34));
        scroll.addView(content);
        setContentView(scroll);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = label("CL", 34, RED, true);
        TextView logo2 = label("FLIX", 34, WHITE, true);
        logo.setLetterSpacing(.08f); logo2.setLetterSpacing(.08f);
        header.addView(logo); header.addView(logo2);
        TextView tagline = label("  •  CINEMA NA SUA TV", 11, MUTED, true);
        tagline.setLetterSpacing(.12f);
        header.addView(tagline, new LinearLayout.LayoutParams(0, -2, 1));
        TextView profile = label("●  PERFIL", 12, WHITE, true);
        profile.setPadding(dp(17), dp(10), dp(17), dp(10));
        profile.setBackground(round(PANEL, dp(20)));
        header.addView(profile);
        content.addView(header);

        navBar = new LinearLayout(this);
        navBar.setGravity(Gravity.CENTER_VERTICAL);
        navBar.setPadding(0, dp(20), 0, dp(22));
        content.addView(navBar);
        addNav("INÍCIO"); addNav("FILMES"); addNav("SÉRIES"); addNav("MINHA LISTA");

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.HORIZONTAL);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(dp(38), dp(28), dp(30), dp(28));
        hero.setBackground(gradient(new int[]{0xff3b1428,0xff1b1728,0xff111722}, dp(22)));
        LinearLayout heroText = new LinearLayout(this);
        heroText.setOrientation(LinearLayout.VERTICAL);
        heroText.setGravity(Gravity.CENTER_VERTICAL);
        TextView eyebrow = label("CLFLIX  /  DESTAQUE DA CASA", 12, 0xffff9aaa, true);
        eyebrow.setLetterSpacing(.13f);
        heroText.addView(eyebrow);
        TextView heroTitle = label("UMA NOVA\nFORMA DE VER.", 39, WHITE, true);
        heroTitle.setLineSpacing(dp(1), 1f);
        LinearLayout.LayoutParams htp = new LinearLayout.LayoutParams(-1, -2); htp.topMargin = dp(12);
        heroText.addView(heroTitle, htp);
        TextView copy = label("Sua próxima história começa aqui.\nExplore uma experiência feita para a tela grande.", 15, 0xffd0ced7, false);
        copy.setLineSpacing(dp(5), 1f);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.topMargin = dp(12);
        heroText.addView(copy, cp);
        TextView explore = label("  ▶   EXPLORAR AGORA  ", 13, WHITE, true);
        explore.setGravity(Gravity.CENTER); explore.setPadding(dp(16), dp(13), dp(16), dp(13));
        explore.setBackground(gradient(new int[]{RED,0xffc41637}, dp(9)));
        explore.setFocusable(true); explore.setOnClickListener(v -> scrollToRows());
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-2, -2); ep.topMargin = dp(20);
        heroText.addView(explore, ep);
        hero.addView(heroText, new LinearLayout.LayoutParams(0, -1, 1));

        LinearLayout art = new LinearLayout(this);
        art.setGravity(Gravity.CENTER); art.setOrientation(LinearLayout.VERTICAL);
        art.setBackground(gradient(new int[]{0xff7a2444,0xff291b39,0xff101522}, dp(18)));
        TextView monogram = label("C", 112, 0x44ffffff, true); monogram.setGravity(Gravity.CENTER); art.addView(monogram);
        TextView artCaption = label("CLFLIX", 12, 0xfff4dce4, true); artCaption.setLetterSpacing(.28f); art.addView(artCaption);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(dp(240), dp(204)); ap.leftMargin = dp(25);
        hero.addView(art, ap);
        content.addView(hero, new LinearLayout.LayoutParams(-1, dp(320)));

        addShelf("CONTINUE DESCOBRINDO", "Seleção especial para você", 0);
        addShelf("FILMES EM DESTAQUE", "Histórias para assistir hoje", 1);
        addShelf("SÉRIES PARA MARATONAR", "Sua próxima série favorita", 2);
        TextView note = label("CATÁLOGO DEMONSTRATIVO  •  CONTEÚDOS REAIS SERÃO ADICIONADOS COM UMA FONTE AUTORIZADA", 10, 0xff737887, true);
        note.setGravity(Gravity.CENTER); note.setLetterSpacing(.04f);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2); np.topMargin = dp(30);
        content.addView(note, np);
        explore.requestFocus();
    }

    private void addNav(String name) {
        boolean selected = name.equals(activeSection);
        TextView item = label(name, 12, selected ? WHITE : MUTED, true);
        item.setGravity(Gravity.CENTER); item.setPadding(dp(17), dp(11), dp(17), dp(11));
        item.setFocusable(true); item.setBackground(round(selected ? RED : PANEL, dp(8)));
        item.setOnClickListener(v -> { activeSection = name; Toast.makeText(this, name + " — catálogo demonstrativo", Toast.LENGTH_SHORT).show(); buildHome(); });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2); p.rightMargin = dp(9); navBar.addView(item, p);
    }

    private void addShelf(String heading, String sub, int shelf) {
        LinearLayout titleBlock = new LinearLayout(this); titleBlock.setOrientation(LinearLayout.VERTICAL);
        TextView title = label(heading, 18, WHITE, true); title.setLetterSpacing(.035f); titleBlock.addView(title);
        TextView subtitle = label(sub, 11, MUTED, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin = dp(4); titleBlock.addView(subtitle, sp);
        LinearLayout.LayoutParams tbp = new LinearLayout.LayoutParams(-1, -2); tbp.topMargin = dp(27); tbp.bottomMargin = dp(13); content.addView(titleBlock, tbp);
        HorizontalScrollView row = new HorizontalScrollView(this); row.setHorizontalScrollBarEnabled(false); row.setClipToPadding(false);
        LinearLayout cards = new LinearLayout(this); cards.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < titles.length; i++) {
            final int index = i; final String itemTitle = titles[i].replace("\n", " ");
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
            card.setFocusable(true); card.setFocusableInTouchMode(true); card.setPadding(dp(7), dp(7), dp(7), dp(8)); card.setBackground(round(PANEL, dp(13)));
            LinearLayout poster = new LinearLayout(this); poster.setGravity(Gravity.CENTER); poster.setOrientation(LinearLayout.VERTICAL);
            poster.setBackground(gradient(palettes[(i + shelf) % palettes.length], dp(10)));
            TextView number = label("0" + (i + 1), 35, 0x66ffffff, true); number.setGravity(Gravity.CENTER); poster.addView(number);
            TextView posterBrand = label("CLFLIX SELECTION", 8, 0xffe9dfe7, true); posterBrand.setLetterSpacing(.12f); posterBrand.setGravity(Gravity.CENTER); poster.addView(posterBrand);
            card.addView(poster, new LinearLayout.LayoutParams(dp(174), dp(120)));
            TextView name = label(titles[i], 12, WHITE, true); name.setLineSpacing(dp(1), 1f); name.setPadding(dp(3), dp(9), dp(3), 0); card.addView(name);
            TextView meta = label(subtitles[(i + shelf) % subtitles.length], 9, MUTED, true); meta.setPadding(dp(3), dp(5), dp(3), dp(2)); card.addView(meta);
            card.setOnClickListener(v -> showDetails(itemTitle, subtitles[(index + shelf) % subtitles.length]));
            card.setOnFocusChangeListener((v, focused) -> { v.animate().scaleX(focused ? 1.075f : 1f).scaleY(focused ? 1.075f : 1f).setDuration(145).start(); v.setBackground(round(focused ? 0xff482033 : PANEL, dp(13))); });
            LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-2, -2); cardLp.rightMargin = dp(14); cards.addView(card, cardLp);
        }
        row.addView(cards); content.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    private void showDetails(String title, String meta) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(25), dp(22), dp(25), dp(22)); box.setBackgroundColor(0xff151722);
        TextView eyebrow = label("CLFLIX  •  PRÉVIA DE CATÁLOGO", 10, 0xffff9aaa, true); box.addView(eyebrow);
        TextView heading = label(title, 25, WHITE, true); LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2); hp.topMargin = dp(10); box.addView(heading, hp);
        TextView info = label(meta + "\n\nEste cartão é demonstrativo. A ficha real e a reprodução serão conectadas quando houver uma fonte de conteúdo autorizada.", 14, 0xffc5c7d0, false);
        info.setLineSpacing(dp(4), 1f); LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.topMargin = dp(10); box.addView(info, ip);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(box).setPositiveButton("FECHAR", (d, w) -> d.dismiss()).create();
        dialog.setOnShowListener(d -> { Window window = dialog.getWindow(); if (window != null) { window.setBackgroundDrawableResource(android.R.color.transparent); window.setLayout(dp(560), -2); } dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(RED); });
        dialog.show();
    }

    private void scrollToRows() {
        if (content == null || content.getChildCount() <= 4) return;
        View shelf = content.getChildAt(4);
        if (shelf instanceof HorizontalScrollView) {
            ViewGroup row = (ViewGroup) ((HorizontalScrollView) shelf).getChildAt(0);
            if (row != null && row.getChildCount() > 0) row.getChildAt(0).requestFocus();
        }
    }
    private TextView label(String text, int size, int color, boolean bold) { TextView view = new TextView(this); view.setText(text); view.setTextSize(size); view.setTextColor(color); if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD); view.setFocusable(false); return view; }
    private GradientDrawable round(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
    private GradientDrawable gradient(int[] colors, int radius) { GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors); d.setCornerRadius(radius); return d; }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    @Override public boolean onKeyDown(int keyCode, KeyEvent event) { if (keyCode == KeyEvent.KEYCODE_BACK) { finish(); return true; } return super.onKeyDown(keyCode, event); }
}
