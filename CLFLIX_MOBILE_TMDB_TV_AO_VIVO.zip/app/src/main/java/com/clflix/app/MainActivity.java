package com.clflix.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import android.text.TextUtils;
import android.media.MediaPlayer;
import android.net.Uri;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class MainActivity extends Activity {
  private final int BG=Color.rgb(9,9,12), PANEL=Color.rgb(25,25,31), RED=Color.rgb(238,48,72);
  private LinearLayout root; private final ExecutorService pool=Executors.newFixedThreadPool(4);
  private static final String TOKEN=BuildConfig.TMDB_BEARER_TOKEN;
  private static final String PLAYLIST_URL="https://iptv-org.github.io/iptv/index.m3u";
  private final ArrayList<Channel> channels=new ArrayList<>();
  private VideoView videoView;
  private boolean channelsLoaded=false;
  static class Channel { String name,url,group,logo; Channel(String n,String u,String g,String l){name=n;url=u;group=g;logo=l;} }

  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);home();}

  private void home(){
    ScrollView sv=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(16),dp(16),dp(16),dp(30));root.setBackgroundColor(BG);sv.addView(root);
    LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);TextView logo=txt("CLFLIX",27,RED,true);bar.addView(logo,new LinearLayout.LayoutParams(0,-2,1));TextView tag=txt("FILMES  •  SÉRIES",10,Color.LTGRAY,true);bar.addView(tag);root.addView(bar);
    LinearLayout nav=new LinearLayout(this);nav.setOrientation(0);nav.setPadding(0,dp(14),0,dp(4));
    Button homeBtn=navButton("INÍCIO");nav.addView(homeBtn,new LinearLayout.LayoutParams(0,dp(42),1));
    Button liveBtn=navButton("TV AO VIVO");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(42),1);lp.leftMargin=dp(8);nav.addView(liveBtn,lp);liveBtn.setOnClickListener(v->showChannels());root.addView(nav);
    EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(Color.WHITE);search.setHintTextColor(Color.GRAY);search.setHint("Buscar filmes e séries...");search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);search.setPadding(dp(14),0,dp(14),0);search.setBackground(bg(PANEL,13));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(50));sp.topMargin=dp(14);root.addView(search,sp);
    search.setOnEditorActionListener((v,a,e)->{String q=search.getText().toString().trim();if(!q.isEmpty())loadSearch(q);return true;});
    TextView hero=txt("DESCUBRA SEU PRÓXIMO\nFILME FAVORITO",24,Color.WHITE,true);hero.setPadding(dp(16),dp(24),dp(16),dp(24));hero.setBackground(bg(Color.rgb(67,13,25),16));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(18);root.addView(hero,hp);
    if(TextUtils.isEmpty(TOKEN)){TextView warn=txt("A API do TMDB ainda não foi configurada. Adicione TMDB_BEARER_TOKEN nos Secrets do GitHub Actions e gere o APK novamente.",13,Color.YELLOW,false);root.addView(warn);}
    section("FILMES POPULARES","movie","popular");section("SÉRIES POPULARES","tv","popular");section("FILMES MAIS BEM AVALIADOS","movie","top_rated");
    TextView credit=txt("Este produto usa a API do TMDB, mas não é endossado ou certificado pelo TMDB.",10,Color.GRAY,false);credit.setPadding(0,dp(26),0,0);root.addView(credit);
    setContentView(sv);
  }

  private Button navButton(String label){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setAllCaps(false);b.setBackground(bg(PANEL,10));return b;}

  private void showChannels(){
    LinearLayout page=new LinearLayout(this);page.setOrientation(1);page.setPadding(dp(16),dp(14),dp(16),dp(18));page.setBackgroundColor(BG);
    LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);TextView title=txt("TV AO VIVO",23,RED,true);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));Button back=navButton("VOLTAR");header.addView(back);back.setOnClickListener(v->home());page.addView(header);
    TextView info=txt("Canais públicos disponíveis na playlist IPTV-org",12,Color.LTGRAY,false);info.setPadding(0,dp(8),0,dp(12));page.addView(info);
    EditText filter=new EditText(this);filter.setSingleLine(true);filter.setTextColor(Color.WHITE);filter.setHintTextColor(Color.GRAY);filter.setHint("Buscar canal...");filter.setPadding(dp(12),0,dp(12),0);filter.setBackground(bg(PANEL,10));page.addView(filter,new LinearLayout.LayoutParams(-1,dp(48)));
    ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(1);scroll.addView(list);LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,0,1);slp.topMargin=dp(10);page.addView(scroll,slp);setContentView(page);
    filter.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){renderChannels(list,s.toString());}public void afterTextChanged(android.text.Editable e){}});
    if(channelsLoaded)renderChannels(list,"");else {list.addView(txt("Carregando lista de canais...",14,Color.LTGRAY,false));loadPlaylist(list);}
  }

  private void loadPlaylist(LinearLayout list){pool.execute(()->{ArrayList<Channel> found=new ArrayList<>();HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(PLAYLIST_URL).openConnection();c.setConnectTimeout(20000);c.setReadTimeout(30000);c.setRequestProperty("User-Agent","CLFLIX Android");try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"))){String line,name=null,group="Outros",logo="";while((line=r.readLine())!=null){line=line.trim();if(line.startsWith("#EXTINF:")){int comma=line.lastIndexOf(',');name=comma>=0?line.substring(comma+1).trim():"Canal";Matcher gm=Pattern.compile("group-title=\"([^\"]*)\"").matcher(line);group=gm.find()?gm.group(1):"Outros";Matcher lm=Pattern.compile("tvg-logo=\"([^\"]*)\"").matcher(line);logo=lm.find()?lm.group(1):"";}else if(!line.isEmpty()&&!line.startsWith("#")&&name!=null){if(line.startsWith("https://")||line.startsWith("http://")){found.add(new Channel(name,line,group,logo));}name=null;}}}
      channels.clear();channels.addAll(found);channelsLoaded=true;runOnUiThread(()->renderChannels(list,""));
    }catch(Exception ex){runOnUiThread(()->{list.removeAllViews();list.addView(txt("Não foi possível carregar a playlist. Verifique sua conexão e tente novamente.",14,Color.LTGRAY,false));Button retry=navButton("TENTAR NOVAMENTE");list.addView(retry);retry.setOnClickListener(v->{channelsLoaded=false;loadPlaylist(list);});});}finally{if(c!=null)c.disconnect();}});}

  private void renderChannels(LinearLayout list,String query){list.removeAllViews();if(!channelsLoaded){list.addView(txt("Carregando canais...",13,Color.LTGRAY,false));return;}String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);int count=0;String lastGroup="";for(Channel ch:channels){if(!ch.name.toLowerCase(Locale.ROOT).contains(q)&&!ch.group.toLowerCase(Locale.ROOT).contains(q))continue;if(!ch.group.equals(lastGroup)){TextView heading=txt(ch.group.isEmpty()?"OUTROS":ch.group.toUpperCase(Locale.ROOT),14,RED,true);heading.setPadding(0,dp(16),0,dp(7));list.addView(heading);lastGroup=ch.group;}TextView item=txt("▶   "+ch.name,15,Color.WHITE,true);item.setPadding(dp(13),dp(14),dp(10),dp(14));item.setBackground(bg(PANEL,9));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(7);list.addView(item,p);item.setOnClickListener(v->playChannel(ch));count++;}if(count==0)list.addView(txt("Nenhum canal encontrado.",13,Color.GRAY,false));else {TextView total=txt(count+" canais encontrados",11,Color.GRAY,false);total.setPadding(0,dp(12),0,0);list.addView(total);}}

  private void playChannel(Channel ch){
    LinearLayout page=new LinearLayout(this);page.setOrientation(1);page.setPadding(dp(12),dp(14),dp(12),dp(14));page.setBackgroundColor(Color.BLACK);
    LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);Button back=navButton("‹ CANAIS");header.addView(back);TextView title=txt(ch.name,17,Color.WHITE,true);title.setPadding(dp(12),0,0,0);header.addView(title);page.addView(header);back.setOnClickListener(v->{if(videoView!=null){videoView.stopPlayback();videoView=null;}showChannels();});
    videoView=new VideoView(this);LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,0,1);vp.gravity=Gravity.CENTER;page.addView(videoView,vp);TextView note=txt("A disponibilidade e os direitos de cada transmissão dependem da emissora e da fonte do canal.",10,Color.GRAY,false);note.setPadding(dp(4),dp(10),dp(4),dp(4));page.addView(note);setContentView(page);
    MediaController controller=new MediaController(this);controller.setAnchorView(videoView);videoView.setMediaController(controller);videoView.setVideoURI(Uri.parse(ch.url));videoView.setOnPreparedListener(mp->{mp.setOnVideoSizeChangedListener((m,w,h)->controller.setAnchorView(videoView));videoView.start();});videoView.setOnErrorListener((mp,what,extra)->{Toast.makeText(this,"Não foi possível reproduzir este canal neste dispositivo.",Toast.LENGTH_LONG).show();return true;});
  }

  private void section(String title,String type,String category){LinearLayout block=new LinearLayout(this);block.setOrientation(1);TextView h=txt(title,17,Color.WHITE,true);h.setPadding(0,dp(22),0,dp(10));block.addView(h);HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);row.setOrientation(0);hs.addView(row);block.addView(hs);root.addView(block);fetch(type,category,null,row);}
  private void loadSearch(String q){root.removeViews(4,Math.max(0,root.getChildCount()-4));TextView h=txt("RESULTADOS: "+q.toUpperCase(),18,Color.WHITE,true);h.setPadding(0,dp(20),0,dp(10));root.addView(h);LinearLayout row=new LinearLayout(this);row.setOrientation(1);root.addView(row);fetch("multi","search",q,row);}
  private void fetch(String type,String category,String query,LinearLayout target){if(TextUtils.isEmpty(TOKEN)){target.addView(txt("Configure a credencial TMDB no GitHub Actions.",12,Color.GRAY,false));return;}pool.execute(()->{try{String path=query==null?"/3/"+type+"/"+category+"?language=pt-BR&page=1":"/3/search/multi?query="+URLEncoder.encode(query,"UTF-8")+"&language=pt-BR&page=1";HttpURLConnection c=(HttpURLConnection)new URL("https://api.themoviedb.org"+path).openConnection();c.setRequestProperty("Authorization","Bearer "+TOKEN);c.setRequestProperty("accept","application/json");c.setConnectTimeout(15000);c.setReadTimeout(15000);int code=c.getResponseCode();InputStream in=code<400?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int count;while((count=in.read(buffer))!=-1)out.write(buffer,0,count);in.close();if(code>=400)throw new Exception("HTTP "+code);JSONArray arr=new JSONObject(out.toString("UTF-8")).optJSONArray("results");runOnUiThread(()->{if(arr==null||arr.length()==0){target.addView(txt("Nenhum título encontrado.",12,Color.GRAY,false));return;}for(int i=0;i<Math.min(arr.length(),20);i++)addItem(target,arr.optJSONObject(i),"multi".equals(type));});}catch(Exception ex){runOnUiThread(()->target.addView(txt("Não foi possível carregar. Verifique a conexão e o token TMDB.",12,Color.LTGRAY,false)));}});}
  private void addItem(LinearLayout row,JSONObject item,boolean vertical){String name=item.optString("title",item.optString("name","Título"));String date=item.optString("release_date",item.optString("first_air_date",""));String poster=item.optString("poster_path","");String overview=item.optString("overview","Sem sinopse disponível.");LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(5),dp(5),dp(5),dp(5));card.setBackground(bg(PANEL,12));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(vertical?-1:dp(132),vertical?-2:dp(250));cp.setMargins(0,0,dp(10),dp(10));row.addView(card,cp);ImageView image=new ImageView(this);image.setBackground(bg(Color.rgb(40,40,46),8));image.setScaleType(ImageView.ScaleType.CENTER_CROP);card.addView(image,new LinearLayout.LayoutParams(vertical?dp(100):dp(122),dp(175)));if(!poster.isEmpty())pool.execute(()->{try{URL u=new URL("https://image.tmdb.org/t/p/w342"+poster);Bitmap bm=BitmapFactory.decodeStream(u.openStream());runOnUiThread(()->image.setImageBitmap(bm));}catch(Exception ignored){}});TextView t=txt(name,13,Color.WHITE,true);t.setMaxLines(2);t.setEllipsize(TextUtils.TruncateAt.END);t.setPadding(0,dp(7),0,0);card.addView(t);card.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle(name+(date.isEmpty()?"":" • "+date.substring(0,4))).setMessage(overview).setPositiveButton("Fechar",null).show());}
  private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;} private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
  @Override public void onBackPressed(){if(videoView!=null){videoView.stopPlayback();videoView=null;showChannels();}else home();}
  @Override protected void onDestroy(){super.onDestroy();if(videoView!=null){videoView.stopPlayback();videoView=null;}pool.shutdownNow();}
}
