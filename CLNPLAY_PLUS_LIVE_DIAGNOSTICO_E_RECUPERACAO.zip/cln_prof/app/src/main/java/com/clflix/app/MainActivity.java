package com.clflix.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.content.pm.ActivityInfo;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.AspectRatioFrameLayout;
import android.text.TextUtils;
import android.media.MediaPlayer;
import android.net.Uri;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class MainActivity extends Activity {
  private final int BG=Color.rgb(9,9,12), PANEL=Color.rgb(25,25,31), RED=Color.rgb(238,48,72);
  private LinearLayout root; private static final ExecutorService pool=Executors.newFixedThreadPool(3);
  private static final LruCache<String,Bitmap> imageCache=new LruCache<String,Bitmap>(8*1024*1024){@Override protected int sizeOf(String key,Bitmap value){return value.getByteCount();}};
  private static final int CHANNEL_PAGE_SIZE=100;
  private final Handler vodSearchHandler=new Handler(Looper.getMainLooper());
  private Runnable pendingVodSearch;
  private static final String TOKEN=BuildConfig.TMDB_BEARER_TOKEN;
  private static final String PLAYLIST_URL="https://iptv-org.github.io/iptv/countries/br.m3u";
  private final ArrayList<Channel> channels=new ArrayList<>();
  private PlayerView playerView; private ExoPlayer exoPlayer; private int playerResizeMode=AspectRatioFrameLayout.RESIZE_MODE_FIT;
  private boolean channelsLoaded=false; private boolean landscapePlayer=false; private boolean playerFromVod=false; private boolean closingPlayer=false; private float playerZoom=1.0f;
  private final Handler liveRecoveryHandler=new Handler(Looper.getMainLooper());
  private Runnable pendingLiveRecovery; private int liveRecoveryAttempts=0; private boolean activePlaybackIsLive=false; private long lastLiveStateChangeMs=0L; private static final String LIVE_TAG="CLNPLAY_LIVE";
  private final Handler playerControlsHandler=new Handler(Looper.getMainLooper()); private Runnable hidePlayerControlsTask; private View playerHeaderControls, playerBottomControls; private boolean playerControlsVisible=true;
  private volatile boolean startupChannelsReady=false, startupVodReady=false;
  private final Handler mainHandler=new Handler(Looper.getMainLooper());
  private final Handler channelSearchHandler=new Handler(Looper.getMainLooper());
  private Runnable pendingChannelSearch;
  private static final Pattern VOD_LOGO_PATTERN=Pattern.compile("tvg-logo=\"([^\"]*)\"");
  private static final Pattern VOD_GROUP_PATTERN=Pattern.compile("group-title=\"([^\"]*)\"");
  static class Channel { String name,url,group,logo; Channel(String n,String u,String g,String l){name=n;url=u;group=g;logo=l;} }

  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);showStartupSplash();}

  private void showStartupSplash(){
    LinearLayout splash=new LinearLayout(this);splash.setOrientation(1);splash.setGravity(Gravity.CENTER);splash.setPadding(dp(28),dp(28),dp(28),dp(28));splash.setBackgroundColor(BG);
    TextView logo=txt("C▶  CLNPLAY+",34,RED,true);splash.addView(logo);
    AlphaAnimation pulse=new AlphaAnimation(0.35f,1f);pulse.setDuration(900);pulse.setRepeatMode(Animation.REVERSE);pulse.setRepeatCount(Animation.INFINITE);logo.startAnimation(pulse);
    ProgressBar progress=new ProgressBar(this);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(150),dp(5));pp.topMargin=dp(30);splash.addView(progress,pp);
    TextView status=txt("Preparando filmes, séries e canais ao vivo...",13,Color.LTGRAY,false);status.setGravity(Gravity.CENTER);status.setPadding(0,dp(18),0,0);splash.addView(status);
    setContentView(splash);
    startupChannelsReady=channelsLoaded;startupVodReady=true;
    if(!startupChannelsReady){LinearLayout cache=new LinearLayout(this);loadPlaylist(cache,()->{startupChannelsReady=true;finishStartupIfReady();});}
    finishStartupIfReady();
  }

  private void finishStartupIfReady(){
    if(startupChannelsReady&&startupVodReady){mainHandler.post(()->{if(!isFinishing())home();});}
  }

  private void home(){
    ScrollView sv=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(16),dp(16),dp(16),dp(30));root.setBackgroundColor(BG);sv.addView(root);
    LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);TextView logo=txt("C▶  CLNPLAY+",27,RED,true);bar.addView(logo,new LinearLayout.LayoutParams(0,-2,1));TextView tag=txt("FILMES  •  SÉRIES  •  AO VIVO",10,Color.LTGRAY,true);bar.addView(tag);root.addView(bar);
    LinearLayout nav=new LinearLayout(this);nav.setOrientation(0);nav.setPadding(0,dp(14),0,dp(4));
    Button homeBtn=navButton("INÍCIO");nav.addView(homeBtn,new LinearLayout.LayoutParams(0,dp(42),1));homeBtn.setOnClickListener(v->home());
    Button liveBtn=navButton("TV AO VIVO");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(42),1);lp.leftMargin=dp(8);nav.addView(liveBtn,lp);liveBtn.setOnClickListener(v->showChannels());
    Button moviesBtn=navButton("FILMES");LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,dp(42),1);mp.leftMargin=dp(8);nav.addView(moviesBtn,mp);moviesBtn.setOnClickListener(v->showVod("movies"));
    Button seriesBtn=navButton("SÉRIES");LinearLayout.LayoutParams spnav=new LinearLayout.LayoutParams(0,dp(42),1);spnav.leftMargin=dp(8);nav.addView(seriesBtn,spnav);seriesBtn.setOnClickListener(v->showVod("series"));root.addView(nav);
    EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(Color.WHITE);search.setHintTextColor(Color.GRAY);search.setHint("Buscar filmes e séries...");search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);search.setPadding(dp(14),0,dp(14),0);search.setBackground(bg(PANEL,13));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(50));sp.topMargin=dp(14);root.addView(search,sp);
    search.setOnEditorActionListener((v,a,e)->{String q=search.getText().toString().trim();if(!q.isEmpty())loadSearch(q);return true;});
    if(TextUtils.isEmpty(TOKEN)){TextView warn=txt("Configure TMDB_BEARER_TOKEN no GitHub Actions para carregar as capas.",12,Color.YELLOW,false);warn.setPadding(0,dp(12),0,0);root.addView(warn);}
    if(!vodError.isEmpty()){TextView err=txt(vodError,12,Color.YELLOW,false);err.setPadding(0,dp(12),0,0);root.addView(err);}
    homeVodSection("FILMES",true);homeVodSection("SÉRIES",false);
    TextView credit=txt("Este produto usa a API do TMDB, mas não é endossado ou certificado pelo TMDB.",10,Color.GRAY,false);credit.setPadding(0,dp(26),0,0);root.addView(credit);
    setContentView(sv);
  }

  private void homeVodSection(String heading,boolean movies){
    LinearLayout section=new LinearLayout(this);section.setOrientation(1);TextView title=txt(heading,19,Color.WHITE,true);title.setPadding(0,dp(22),0,dp(10));section.addView(title);
    HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);row.setOrientation(0);hs.addView(row);section.addView(hs);
    ArrayList<VodItem> data=movies?vodMovies:vodSeries;int count=Math.min(14,data.size());
    for(int i=0;i<count;i++)addVodPosterCard(row,data.get(i),movies);
    if(data.isEmpty())section.addView(txt(vodLoading?"Carregando catálogo...":(vodError.isEmpty()?"Nenhum título disponível.":vodError),12,Color.LTGRAY,false));
    Button all=navButton(movies?"VER TODOS OS FILMES":"VER TODAS AS SÉRIES");LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(42));bp.topMargin=dp(8);section.addView(all,bp);all.setOnClickListener(v->showVod(movies?"movies":"series"));root.addView(section);
  }

  private void addVodPosterCard(LinearLayout row,VodItem item,boolean movie){
    LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(5),dp(5),dp(5),dp(7));card.setBackground(bg(PANEL,10));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(126),dp(226));cp.rightMargin=dp(10);row.addView(card,cp);
    ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);poster.setBackground(bg(Color.rgb(40,40,46),8));card.addView(poster,new LinearLayout.LayoutParams(-1,dp(174)));
    TextView name=txt(item.name,12,Color.WHITE,true);name.setMaxLines(2);name.setEllipsize(TextUtils.TruncateAt.END);name.setPadding(dp(3),dp(7),dp(3),0);card.addView(name);
    loadTmdbPoster(item,movie,poster);card.setOnClickListener(v->playVod(item));
  }

  private Button navButton(String label){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setAllCaps(false);b.setBackground(bg(PANEL,10));return b;}

  private void showChannels(){
    LinearLayout page=new LinearLayout(this);page.setOrientation(1);page.setPadding(dp(16),dp(14),dp(16),dp(18));page.setBackgroundColor(BG);
    LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);TextView title=txt("CLNPLAY+  |  TV AO VIVO",21,RED,true);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));Button back=navButton("VOLTAR");header.addView(back);back.setOnClickListener(v->home());page.addView(header);
    TextView info=txt("Canais públicos disponíveis na playlist IPTV-org",12,Color.LTGRAY,false);info.setPadding(0,dp(8),0,dp(12));page.addView(info);
    EditText filter=new EditText(this);filter.setSingleLine(true);filter.setTextColor(Color.WHITE);filter.setHintTextColor(Color.GRAY);filter.setHint("Buscar canal...");filter.setPadding(dp(12),0,dp(12),0);filter.setBackground(bg(PANEL,10));page.addView(filter,new LinearLayout.LayoutParams(-1,dp(48)));
    ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(1);scroll.addView(list);LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,0,1);slp.topMargin=dp(10);page.addView(scroll,slp);setContentView(page);
    filter.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){final String query=s.toString();if(pendingChannelSearch!=null)channelSearchHandler.removeCallbacks(pendingChannelSearch);pendingChannelSearch=()->{if(!isFinishing()&&list.isAttachedToWindow())renderChannels(list,query,0);};channelSearchHandler.postDelayed(pendingChannelSearch,280);}public void afterTextChanged(android.text.Editable e){}});
    if(channelsLoaded)renderChannels(list,"");else {list.addView(txt("Carregando lista de canais...",14,Color.LTGRAY,false));loadPlaylist(list);}
  }

  private static String readM3uAttribute(String line,String key,String fallback){
    String marker=key+"=\\\"";
    int start=line.indexOf(marker);
    if(start<0)return fallback;
    start+=marker.length();
    int end=line.indexOf('"',start);
    if(end<0||end-start>1024)return fallback;
    return line.substring(start,end);
  }

  private void loadPlaylist(LinearLayout list){loadPlaylist(list,null);}
  private void loadPlaylist(LinearLayout list,Runnable completion){
    pool.execute(()->{
      ArrayList<Channel> found=new ArrayList<>();
      String[] playlistUrls={
        "https://raw.githubusercontent.com/Ramys/Iptv-Brasil-2026/master/Canais.m3u8",
        "https://raw.githubusercontent.com/Ramys/Iptv-Brasil-2026/master/CanaisBR01.m3u8",
        "https://raw.githubusercontent.com/Ramys/Iptv-Brasil-2026/master/CanaisBR02.m3u8",
        "https://raw.githubusercontent.com/Ramys/Iptv-Brasil-2026/master/CanaisBR03.m3u8",
        "https://raw.githubusercontent.com/Ramys/Iptv-Brasil-2026/master/CanaisBR04.m3u8",
        "https://raw.githubusercontent.com/Ramys/Iptv-Brasil-2026/master/CanaisIPTV.m3u8"
      };
      int successful=0;
      for(String playlistUrl:playlistUrls){
        HttpURLConnection connection=null;
        try{
          connection=(HttpURLConnection)new URL(playlistUrl).openConnection();
          connection.setConnectTimeout(20000); connection.setReadTimeout(45000);
          connection.setInstanceFollowRedirects(true);
          connection.setRequestProperty("User-Agent","CLNPLAY+ Android");
          int status=connection.getResponseCode();
          if(status<200||status>=300)continue;
          try(BufferedReader reader=new BufferedReader(new InputStreamReader(connection.getInputStream(),"UTF-8"))){
            String line,name=null,group="Outros",logo="";
            while((line=reader.readLine())!=null){
              if(line.length()>16384){name=null;continue;}
              line=line.trim();
              if(line.startsWith("#EXTINF:")){
                int comma=line.lastIndexOf(',');
                name=comma>=0?line.substring(comma+1).trim():"Canal";
                if(name.length()>180)name=name.substring(0,180);
                group=readM3uAttribute(line,"group-title", "Outros");
                logo=readM3uAttribute(line,"tvg-logo", "");
              }else if(!line.isEmpty()&&!line.startsWith("#")&&name!=null){
                if((line.startsWith("https://")||line.startsWith("http://")) && line.length()<=4096){
                  if(!isAdultChannel(name,group))found.add(new Channel(name,line,group,logo));
                }
                name=null;
                if(found.size()>=5000)break;
              }
            }
          }
          successful++;
        }catch(Exception ignored){
          // Uma lista indisponível não impede o carregamento das demais.
        }finally{if(connection!=null)connection.disconnect();}
      }
      if(found.isEmpty()){
        runOnUiThread(()->{list.removeAllViews();list.addView(txt("Não foi possível carregar as listas de canais. Verifique sua conexão e tente novamente.",14,Color.LTGRAY,false));if(completion!=null)completion.run();Button retry=navButton("TENTAR NOVAMENTE");list.addView(retry);retry.setOnClickListener(v->{channelsLoaded=false;loadPlaylist(list);});});
        return;
      }
      // Deduplicação por nome normalizado e URL, mantendo a primeira ocorrência.
      LinkedHashMap<String,Channel> unique=new LinkedHashMap<>();
      for(Channel ch:found){
        String normalized=java.text.Normalizer.normalize(ch.name==null?"":ch.name,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+"," ").trim();
        String normalizedUrl=(ch.url==null?"":ch.url.trim()).replaceAll("[?#].*$","").toLowerCase(Locale.ROOT);
        if(normalized.isEmpty())normalized=normalizedUrl;
        if(!unique.containsKey("N:"+normalized)&&!unique.containsKey("U:"+normalizedUrl)){
          unique.put("N:"+normalized,ch); unique.put("U:"+normalizedUrl,ch);
        }
      }
      Set<Channel> emitted=Collections.newSetFromMap(new IdentityHashMap<>());
      found.clear(); for(Channel ch:unique.values())if(emitted.add(ch))found.add(ch);
      for(Channel ch:found){if(channelPriority(ch.name)<100)ch.group="PRINCIPAIS DO BRASIL";}
      Collections.sort(found,(a,b)->{int pa=channelPriority(a.name),pb=channelPriority(b.name);if(pa!=pb)return Integer.compare(pa,pb);int g=a.group.compareToIgnoreCase(b.group);if(g!=0)return g;return a.name.compareToIgnoreCase(b.name);});
      channels.clear();channels.addAll(found);channelsLoaded=true;
      runOnUiThread(()->{renderChannels(list,"");if(completion!=null)completion.run();});
    });
  }

  private boolean isAdultChannel(String name,String group){
    String value=((name==null?"":name)+" "+(group==null?"":group)).toLowerCase(Locale.ROOT);
    value=java.text.Normalizer.normalize(value,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","");
    return value.matches("(?s).*\\b(adult|Adults|xxx|porn|porno|pornografia|erotico|erotica|erotic|sex|sexo|sexy|18\\+|hot\\s*adult|playboy|hustler|venus|penthouse)\\b.*")
        || value.contains("canal adulto") || value.contains("adult channel");
  }

  private int channelPriority(String name){
    String n=name.toLowerCase(Locale.ROOT);
    if(n.matches(".*\\b(globo|tv globo|globo sp|globo rj)\\b.*"))return 0;
    if(n.contains("sbt"))return 1;
    if(n.contains("record"))return 2;
    if(n.contains("band"))return 3;
    if(n.contains("rede tv")||n.contains("redetv"))return 4;
    if(n.contains("tv brasil"))return 5;
    if(n.contains("tv cultura")||n.equals("cultura"))return 6;
    if(n.contains("rede vida"))return 7;
    if(n.contains("tv senado"))return 8;
    if(n.contains("tv câmara")||n.contains("tv camara"))return 9;
    if(n.contains("canal gov"))return 10;
    return 100;
  }

  private void renderChannels(LinearLayout list,String query){renderChannels(list,query,0);}
  private void renderChannels(LinearLayout list,String query,int offset){
    if(offset==0)list.removeAllViews();
    if(!channelsLoaded){if(offset==0)list.addView(txt("Carregando canais...",13,Color.LTGRAY,false));return;}
    String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);int matched=0,added=0;String lastGroup="";
    for(Channel ch:channels){
      if(!ch.name.toLowerCase(Locale.ROOT).contains(q)&&!ch.group.toLowerCase(Locale.ROOT).contains(q))continue;
      if(matched++<offset)continue;
      if(added>=CHANNEL_PAGE_SIZE)break;
      if(!ch.group.equals(lastGroup)){TextView heading=txt(ch.group.isEmpty()?"OUTROS":ch.group.toUpperCase(Locale.ROOT),14,RED,true);heading.setPadding(0,dp(16),0,dp(7));list.addView(heading);lastGroup=ch.group;}
      LinearLayout item=new LinearLayout(this);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(dp(10),dp(8),dp(10),dp(8));item.setBackground(bg(PANEL,10));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(66));lp.bottomMargin=dp(7);list.addView(item,lp);
      ImageView badge=new ImageView(this);badge.setScaleType(ImageView.ScaleType.FIT_CENTER);badge.setBackground(bg(Color.WHITE,7));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(48),dp(48));bp.rightMargin=dp(12);item.addView(badge,bp);
      if(!TextUtils.isEmpty(ch.logo))loadCachedImage(ch.logo,badge);else badge.setImageDrawable(bg(RED,7));
      TextView channelName=txt(ch.name,15,Color.WHITE,true);channelName.setMaxLines(2);channelName.setEllipsize(TextUtils.TruncateAt.END);item.addView(channelName,new LinearLayout.LayoutParams(0,-2,1));item.addView(txt("▶",19,RED,true));item.setOnClickListener(v->playChannel(ch));added++;
    }
    int total=0;for(Channel ch:channels)if(ch.name.toLowerCase(Locale.ROOT).contains(q)||ch.group.toLowerCase(Locale.ROOT).contains(q))total++;
    if(total==0&&offset==0)list.addView(txt("Nenhum canal encontrado.",13,Color.GRAY,false));
    else if(offset+added<total){Button more=navButton("CARREGAR MAIS CANAIS  ("+(total-offset-added)+")");LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(46));mp.topMargin=dp(8);list.addView(more,mp);int next=offset+added;more.setOnClickListener(v->{more.setEnabled(false);renderChannelsAppend(list,q,next,more);});}
    if(offset==0&&total>0){TextView count=txt(total+" canais encontrados",11,Color.GRAY,false);count.setPadding(0,dp(10),0,0);list.addView(count,0);}
  }
  private void renderChannelsAppend(LinearLayout list,String query,int offset,View oldButton){int index=list.indexOfChild(oldButton);if(index>=0)list.removeViewAt(index);renderChannels(list,query,offset);}
  private void loadCachedImage(String url,ImageView target){
    Bitmap cached=imageCache.get(url);if(cached!=null){target.setImageBitmap(cached);return;}
    target.setTag(url);pool.execute(()->{HttpURLConnection c=null;Bitmap bm=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(6000);c.setReadTimeout(6000);c.setInstanceFollowRedirects(true);c.setRequestProperty("User-Agent","CLNPLAY+ Android");try(InputStream in=c.getInputStream()){BitmapFactory.Options opt=new BitmapFactory.Options();opt.inPreferredConfig=Bitmap.Config.RGB_565;bm=BitmapFactory.decodeStream(in,null,opt);}if(bm!=null)imageCache.put(url,bm);}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}if(bm!=null) {Bitmap result=bm;runOnUiThread(()->{if(url.equals(target.getTag())&&target.getParent()!=null)target.setImageBitmap(result);});}});
  }


  private void playChannel(Channel ch){
    closingPlayer=false;releasePlayer();playerZoom=1.0f;playerResizeMode=AspectRatioFrameLayout.RESIZE_MODE_FIT;landscapePlayer=true;
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);
    playerView=new PlayerView(this);playerView.setUseController(true);playerView.setControllerAutoShow(true);playerView.setControllerShowTimeoutMs(3000);playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);playerView.setBackgroundColor(Color.BLACK);
    root.addView(playerView,new FrameLayout.LayoutParams(-1,-1));
    LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(8),dp(6),dp(8),dp(6));header.setBackgroundColor(0x99000000);
    Button back=navButton(playerFromVod?"‹ INÍCIO":"‹ CANAIS");header.addView(back);TextView title=txt(ch.name,16,Color.WHITE,true);title.setPadding(dp(10),0,0,0);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));Button rotate=navButton("⛶  GIRAR TELA");header.addView(rotate);
    FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP);root.addView(header,hp);playerHeaderControls=header;
    LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER);bar.setPadding(dp(6),dp(5),dp(6),dp(5));bar.setBackgroundColor(0x99000000);
    Button minus=navButton("−"),fit=navButton("AJUSTAR"),fill=navButton("PREENCHER"),plus=navButton("ZOOM +");
    for(Button x:new Button[]{minus,fit,fill,plus}){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(40));lp.setMargins(dp(4),0,dp(4),0);bar.addView(x,lp);}
    FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);root.addView(bar,bp);playerBottomControls=bar;
    back.setOnClickListener(v->closePlayerAndReturn());rotate.setOnClickListener(v->togglePlayerOrientation());
    minus.setOnClickListener(v->{setPlayerZoom(Math.max(1f,playerZoom-.15f));showPlayerControls();});plus.setOnClickListener(v->{setPlayerZoom(Math.min(2f,playerZoom+.15f));showPlayerControls();});
    fit.setOnClickListener(v->{playerResizeMode=AspectRatioFrameLayout.RESIZE_MODE_FIT;playerZoom=1f;applyPlayerScale();showPlayerControls();});fill.setOnClickListener(v->{playerResizeMode=AspectRatioFrameLayout.RESIZE_MODE_FILL;playerZoom=1f;applyPlayerScale();showPlayerControls();});
    playerView.setOnClickListener(v->togglePlayerControls());
    setContentView(root);playerControlsVisible=true;scheduleHidePlayerControls();
    activePlaybackIsLive=!playerFromVod;
    liveRecoveryAttempts=0;
    DefaultMediaSourceFactory mediaSourceFactory=new DefaultMediaSourceFactory(this);
    if(activePlaybackIsLive) mediaSourceFactory.setLiveTargetOffsetMs(5000);
    exoPlayer=new ExoPlayer.Builder(this).setMediaSourceFactory(mediaSourceFactory).build();playerView.setPlayer(exoPlayer);
    exoPlayer.addListener(new Player.Listener(){
      @Override public void onPlaybackStateChanged(int state){
        if(activePlaybackIsLive) Log.i(LIVE_TAG,"state="+state+" playWhenReady="+(exoPlayer!=null && exoPlayer.getPlayWhenReady()));
        if(state==Player.STATE_READY){liveRecoveryAttempts=0;cancelLiveRecovery();}
      }
      @Override public void onPlayWhenReadyChanged(boolean playWhenReady,int reason){
        if(!activePlaybackIsLive)return;
        long now=SystemClock.elapsedRealtime();
        Log.w(LIVE_TAG,"playWhenReady="+playWhenReady+" reason="+reason+" intervalMs="+(lastLiveStateChangeMs==0?0:now-lastLiveStateChangeMs));
        lastLiveStateChangeMs=now;
        // Nunca sobrescreve pausa solicitada pelo usuário. Outros motivos são registrados
        // para diagnóstico; perda de foco de áudio também não deve ser forçada.
      }
      @Override public void onIsPlayingChanged(boolean isPlaying){
        if(activePlaybackIsLive) Log.i(LIVE_TAG,"isPlaying="+isPlaying+" state="+(exoPlayer==null?-1:exoPlayer.getPlaybackState()));
      }
      @Override public void onPlayerError(androidx.media3.common.PlaybackException e){
        if(activePlaybackIsLive) Log.e(LIVE_TAG,"erro de transmissão code="+e.errorCode+" name="+e.getErrorCodeName(),e);
        if(!activePlaybackIsLive || exoPlayer==null || !exoPlayer.getPlayWhenReady()){
          runOnUiThread(()->Toast.makeText(MainActivity.this,"Não foi possível reproduzir este conteúdo. Tente novamente.",Toast.LENGTH_LONG).show());
          return;
        }
        scheduleLiveRecovery(e.errorCode);
      }
    });
    MediaItem.Builder mediaItemBuilder=new MediaItem.Builder().setUri(Uri.parse(ch.url));
    if(activePlaybackIsLive){
      mediaItemBuilder.setLiveConfiguration(new MediaItem.LiveConfiguration.Builder()
          .setTargetOffsetMs(5000).setMinOffsetMs(3000).setMaxOffsetMs(12000)
          .setMinPlaybackSpeed(0.98f).setMaxPlaybackSpeed(1.02f).build());
    }
    exoPlayer.setMediaItem(mediaItemBuilder.build());exoPlayer.prepare();exoPlayer.play();
  }
  private void cancelLiveRecovery(){
    if(pendingLiveRecovery!=null){liveRecoveryHandler.removeCallbacks(pendingLiveRecovery);pendingLiveRecovery=null;}
  }
  private void scheduleLiveRecovery(int errorCode){
    if(!activePlaybackIsLive || exoPlayer==null || !exoPlayer.getPlayWhenReady() || closingPlayer)return;
    cancelLiveRecovery();
    if(liveRecoveryAttempts>=4){Toast.makeText(this,"Sinal instável. Não foi possível reconectar automaticamente.",Toast.LENGTH_SHORT).show();return;}
    final int attempt=++liveRecoveryAttempts;
    long delayMs=Math.min(5000L,1000L*attempt);
    pendingLiveRecovery=()->{
      pendingLiveRecovery=null;
      if(!activePlaybackIsLive || exoPlayer==null || closingPlayer || !exoPlayer.getPlayWhenReady())return;
      try{
        if(errorCode==androidx.media3.common.PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW){
          exoPlayer.seekToDefaultPosition();
        }else{
          exoPlayer.prepare();
        }
        exoPlayer.play();
      }catch(Exception ignored){scheduleLiveRecovery(errorCode);}
    };
    liveRecoveryHandler.postDelayed(pendingLiveRecovery,delayMs);
  }
  private void togglePlayerControls(){if(playerControlsVisible)hidePlayerControls();else showPlayerControls();}
  private void showPlayerControls(){playerControlsVisible=true;if(playerHeaderControls!=null)playerHeaderControls.setVisibility(View.VISIBLE);if(playerBottomControls!=null)playerBottomControls.setVisibility(View.VISIBLE);scheduleHidePlayerControls();}
  private void hidePlayerControls(){playerControlsVisible=false;if(playerHeaderControls!=null)playerHeaderControls.setVisibility(View.GONE);if(playerBottomControls!=null)playerBottomControls.setVisibility(View.GONE);}
  private void scheduleHidePlayerControls(){if(hidePlayerControlsTask!=null)playerControlsHandler.removeCallbacks(hidePlayerControlsTask);hidePlayerControlsTask=()->hidePlayerControls();playerControlsHandler.postDelayed(hidePlayerControlsTask,3000);}
  private void applyPlayerScale(){if(playerView!=null){playerView.setResizeMode(playerResizeMode);View surface=playerView.getVideoSurfaceView();if(surface!=null){surface.setScaleX(playerZoom);surface.setScaleY(playerZoom);}}}
  private void setPlayerZoom(float zoom){playerZoom=zoom;playerResizeMode=AspectRatioFrameLayout.RESIZE_MODE_ZOOM;applyPlayerScale();}
  private void releasePlayer(){
    cancelLiveRecovery();activePlaybackIsLive=false;liveRecoveryAttempts=0;
    if(hidePlayerControlsTask!=null){playerControlsHandler.removeCallbacks(hidePlayerControlsTask);hidePlayerControlsTask=null;}
    playerControlsVisible=false;playerHeaderControls=null;playerBottomControls=null;
    // Desvincula a superfície antes de liberar o decoder para evitar frame/superfície órfã.
    if(playerView!=null){try{playerView.setKeepContentOnPlayerReset(false);playerView.setPlayer(null);}catch(Exception ignored){}playerView=null;}
    if(exoPlayer!=null){ExoPlayer old=exoPlayer;exoPlayer=null;try{old.stop();old.clearMediaItems();old.release();}catch(Exception ignored){}}
  }
  private void closePlayerAndReturn(){
    if(closingPlayer || (exoPlayer==null && playerView==null))return;
    closingPlayer=true;
    final boolean returnHome=playerFromVod;playerFromVod=false;
    // Primeiro encerra completamente o player; depois restaura janela/orientação e troca a tela.
    releasePlayer();
    getWindow().getDecorView().clearAnimation();
    getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    landscapePlayer=false;
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    if(returnHome)home();else showChannels();
    // Libera a trava somente após a próxima passagem do loop principal.
    mainHandler.post(()->closingPlayer=false);
  }



  private static class VodItem { String name,url,logo,group; VodItem(String n,String u,String l,String g){name=n;url=u;logo=l;group=g;} }
  // Uma única playlist M3U do repositório indicado pelo usuário.
  private static final String VOD_M3U="https://raw.githubusercontent.com/Ramys/Iptv-Brasil-2026/master/Filmes-Series.m3u8";
  private static final int VOD_PAGE_SIZE=80;
  private static final int VOD_MAX_PER_CATEGORY=6000;
  private static final ArrayList<VodItem> vodMovies=new ArrayList<>(), vodSeries=new ArrayList<>();
  private static volatile boolean vodLoaded=false, vodLoading=false;
  private static String vodError="";
  private void showVod(String kind){
    final boolean movie="movies".equals(kind);
    LinearLayout page=new LinearLayout(this);page.setOrientation(1);page.setPadding(dp(16),dp(14),dp(16),dp(18));page.setBackgroundColor(BG);
    LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
    TextView title=txt(movie?"CLNPLAY+  |  FILMES":"CLNPLAY+  |  SÉRIES",21,RED,true);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
    Button back=navButton("VOLTAR");header.addView(back);back.setOnClickListener(v->home());page.addView(header);
    TextView info=txt("Catálogo da playlist Filmes-Series • Capas e informações pela API TMDB",12,Color.LTGRAY,false);info.setPadding(0,dp(8),0,dp(12));page.addView(info);
    EditText filter=new EditText(this);filter.setSingleLine(true);filter.setTextColor(Color.WHITE);filter.setHintTextColor(Color.GRAY);filter.setHint("Buscar título...");filter.setPadding(dp(12),0,dp(12),0);filter.setBackground(bg(PANEL,10));page.addView(filter,new LinearLayout.LayoutParams(-1,dp(48)));
    ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(1);scroll.addView(list);LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,0,1);slp.topMargin=dp(10);page.addView(scroll,slp);setContentView(page);
    final int[] shown={0}; final String[] currentQuery={""}; final Runnable[] render={null};
    render[0]=()->{list.removeAllViews();ArrayList<VodItem> source=movie?vodMovies:vodSeries;String q=currentQuery[0].toLowerCase(Locale.ROOT);int matched=0,added=0;for(VodItem item:source){if(!q.isEmpty()&&!item.name.toLowerCase(Locale.ROOT).contains(q)&&!item.group.toLowerCase(Locale.ROOT).contains(q))continue;matched++;if(matched<=shown[0]||added>=VOD_PAGE_SIZE)continue;addVodItem(list,item,movie);added++;}if(matched==0){list.addView(txt(vodLoading?"Baixando e lendo a playlist...":(vodError.isEmpty()?"Nenhum título encontrado.":vodError),13,Color.LTGRAY,false));}else{TextView total=txt(added+" de "+matched+" títulos exibidos",11,Color.GRAY,false);total.setPadding(0,dp(10),0,dp(8));list.addView(total);if(shown[0]+added<matched){final int pageAdded=added;Button more=navButton("CARREGAR MAIS");list.addView(more,new LinearLayout.LayoutParams(-1,dp(46)));more.setOnClickListener(v->{shown[0]+=pageAdded;render[0].run();});}}};
    filter.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){currentQuery[0]=s.toString();shown[0]=0;if(pendingVodSearch!=null)vodSearchHandler.removeCallbacks(pendingVodSearch);pendingVodSearch=()->{if(vodLoaded&&list.isAttachedToWindow())render[0].run();};vodSearchHandler.postDelayed(pendingVodSearch,250);}public void afterTextChanged(android.text.Editable e){}});
    shown[0]=0;list.addView(txt("Carregando playlist de filmes e séries...",14,Color.LTGRAY,false));
    if(vodLoaded){render[0].run();return;} if(!vodLoading)loadCombinedVod(()->{if(!isFinishing())runOnUiThread(()->render[0].run());});
  }

  private void loadCombinedVod(Runnable completion){
    vodLoading=true;pool.execute(()->{HttpURLConnection c=null;String name=null,logo="",group="Outros";int parsed=0;HashSet<String> seenVod=new HashSet<>();
      try{URL url=new URL(VOD_M3U);c=(HttpURLConnection)url.openConnection();c.setConnectTimeout(30000);c.setReadTimeout(60000);c.setInstanceFollowRedirects(true);c.setRequestProperty("User-Agent","CLNPLAY+ Android");c.setRequestProperty("Accept-Encoding","identity");int code=c.getResponseCode();if(code<200||code>=300)throw new IOException("HTTP "+code);
        try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"),65536)){String line;while((line=r.readLine())!=null){line=line.trim();if(line.isEmpty())continue;if(line.startsWith("#EXTINF:")){int comma=line.lastIndexOf(',');name=comma>=0?line.substring(comma+1).trim():"Título";Matcher lm=VOD_LOGO_PATTERN.matcher(line);logo=lm.find()?lm.group(1):"";Matcher gm=VOD_GROUP_PATTERN.matcher(line);group=gm.find()?gm.group(1):"Outros";}else if(!line.startsWith("#")&&name!=null&&(line.startsWith("http://")||line.startsWith("https://"))){String key=line.trim().toLowerCase(Locale.ROOT);if(seenVod.add(key)){VodItem item=new VodItem(name,line,logo,group);if(isSeriesEntry(name,group)){if(vodSeries.size()<VOD_MAX_PER_CATEGORY)vodSeries.add(item);}else{if(vodMovies.size()<VOD_MAX_PER_CATEGORY)vodMovies.add(item);}parsed++;}name=null;logo="";group="Outros";}}
        }
        vodLoaded=true;vodError=parsed==0?"A playlist foi aberta, mas não foram encontrados itens M3U válidos.":"";
      }catch(Exception ex){vodError="Falha ao carregar a playlist ("+ex.getClass().getSimpleName()+"). Confira a conexão e tente novamente.";}
      finally{if(c!=null)c.disconnect();vodLoading=false;if(completion!=null)completion.run();}
    });
  }
  private boolean isSeriesEntry(String name,String group){
    String n=name.toLowerCase(Locale.ROOT),g=group.toLowerCase(Locale.ROOT);
    boolean episode=n.matches(".*\\bs[0-9]{1,2}e[0-9]{1,2}\\b.*")||n.matches(".*\\b[0-9]{1,2}x[0-9]{1,2}\\b.*")||n.contains("temporada")||n.contains("episódio")||n.contains("episode");
    boolean seriesGroup=(g.contains("série")||g.contains("series")||g.contains("temporada")||g.contains("season"))&&!g.contains("filme");
    return episode||seriesGroup;
  }
  private void filterVod(LinearLayout list,String query){String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);for(int i=0;i<list.getChildCount();i++){View v=list.getChildAt(i);Object tag=v.getTag();if(tag instanceof String)v.setVisibility(((String)tag).toLowerCase(Locale.ROOT).contains(q)?View.VISIBLE:View.GONE);}}
  private void addVodItem(LinearLayout list,VodItem item,boolean movie){LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(9),dp(8),dp(9),dp(8));card.setBackground(bg(PANEL,10));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(112));cp.bottomMargin=dp(8);list.addView(card,cp);card.setTag(item.name);ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);poster.setBackground(bg(Color.rgb(40,40,46),7));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(68),dp(96));pp.rightMargin=dp(12);card.addView(poster,pp);LinearLayout details=new LinearLayout(this);details.setOrientation(1);card.addView(details,new LinearLayout.LayoutParams(0,-2,1));TextView name=txt(item.name,14,Color.WHITE,true);name.setMaxLines(3);details.addView(name);TextView group=txt(item.group,11,Color.GRAY,false);group.setPadding(0,dp(5),0,0);details.addView(group);
    loadTmdbPoster(item,movie,poster);
    card.setOnClickListener(v->playVod(item));}
  private void loadTmdbPoster(VodItem item,boolean movie,ImageView target){
    if(TextUtils.isEmpty(TOKEN))return;
    String cacheKey="tmdb:"+(movie?"m:":"s:")+item.name.toLowerCase(Locale.ROOT);Bitmap cached=imageCache.get(cacheKey);if(cached!=null){target.setImageBitmap(cached);return;}target.setTag(cacheKey);
    pool.execute(()->{HttpURLConnection c=null,pc=null;try{String type=movie?"movie":"tv";String clean=item.name.replaceAll("\\(.*?\\)","").trim();String api="https://api.themoviedb.org/3/search/"+type+"?query="+URLEncoder.encode(clean,"UTF-8")+"&language=pt-BR&page=1";c=(HttpURLConnection)new URL(api).openConnection();c.setRequestProperty("Authorization","Bearer "+TOKEN);c.setConnectTimeout(10000);c.setReadTimeout(10000);int status=c.getResponseCode();if(status<200||status>=300)return;JSONObject data=new JSONObject(readText(c.getInputStream()));JSONArray results=data.optJSONArray("results");JSONObject first=results!=null&&results.length()>0?results.optJSONObject(0):null;String path=first==null?"":first.optString("poster_path","");if(!path.isEmpty()){pc=(HttpURLConnection)new URL("https://image.tmdb.org/t/p/w342"+path).openConnection();pc.setConnectTimeout(10000);pc.setReadTimeout(10000);try(InputStream in=pc.getInputStream()){BitmapFactory.Options opt=new BitmapFactory.Options();opt.inPreferredConfig=Bitmap.Config.RGB_565;opt.inSampleSize=2;Bitmap bm=BitmapFactory.decodeStream(in,null,opt);if(bm!=null){imageCache.put(cacheKey,bm);runOnUiThread(()->{if(cacheKey.equals(target.getTag())&&target.getParent()!=null)target.setImageBitmap(bm);});}}}}catch(Exception ignored){}finally{if(pc!=null)pc.disconnect();if(c!=null)c.disconnect();}});
  }

  private void playVod(VodItem item){playerFromVod=true;Toast.makeText(this,"Preparando: "+item.name,Toast.LENGTH_SHORT).show();playChannel(new Channel(item.name,item.url,item.group,item.logo));}

  private void togglePlayerOrientation(){
    landscapePlayer=!landscapePlayer;
    if(landscapePlayer){setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);}
    else restorePlayerOrientation();
  }
  private void restorePlayerOrientation(){landscapePlayer=false;setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);getWindow().getDecorView().setSystemUiVisibility(0);}

  private void section(String title,String type,String category){LinearLayout block=new LinearLayout(this);block.setOrientation(1);TextView h=txt(title,17,Color.WHITE,true);h.setPadding(0,dp(22),0,dp(10));block.addView(h);HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);row.setOrientation(0);hs.addView(row);block.addView(hs);root.addView(block);fetch(type,category,null,row);}
  // A busca principal consulta a playlist reproduzível, não apenas os resultados de capas do TMDB.
  private void loadSearch(String q){
    final String initialQuery=q==null?"":q.trim();
    LinearLayout page=new LinearLayout(this);page.setOrientation(1);page.setPadding(dp(16),dp(14),dp(16),dp(18));page.setBackgroundColor(BG);
    LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
    TextView title=txt("CLNPLAY+  |  BUSCAR NO CATÁLOGO",18,RED,true);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
    Button back=navButton("VOLTAR");header.addView(back);back.setOnClickListener(v->home());page.addView(header);
    EditText input=new EditText(this);input.setSingleLine(true);input.setTextColor(Color.WHITE);input.setHintTextColor(Color.GRAY);input.setHint("Buscar filme ou série...");input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);input.setPadding(dp(12),0,dp(12),0);input.setBackground(bg(PANEL,10));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(48));ip.topMargin=dp(12);page.addView(input,ip);
    TextView status=txt("Pesquisando na lista de títulos disponíveis para assistir...",12,Color.LTGRAY,false);status.setPadding(0,dp(10),0,dp(8));page.addView(status);
    ScrollView scroll=new ScrollView(this);LinearLayout results=new LinearLayout(this);results.setOrientation(1);scroll.addView(results);page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(page);
    final int[] shown={0};final String[] query={initialQuery};final Runnable[] render={null};
    render[0]=()->{results.removeAllViews();String term=query[0].toLowerCase(Locale.ROOT);int total=0,added=0;ArrayList<VodItem> matches=new ArrayList<>();ArrayList<Boolean> types=new ArrayList<>();
      for(VodItem item:vodMovies){if(item.name.toLowerCase(Locale.ROOT).contains(term)||item.group.toLowerCase(Locale.ROOT).contains(term)){matches.add(item);types.add(true);}}
      for(VodItem item:vodSeries){if(item.name.toLowerCase(Locale.ROOT).contains(term)||item.group.toLowerCase(Locale.ROOT).contains(term)){matches.add(item);types.add(false);}}
      total=matches.size();for(int i=shown[0];i<total&&added<VOD_PAGE_SIZE;i++){addVodItem(results,matches.get(i),types.get(i));added++;}
      status.setText(total==0?"Nenhum filme ou episódio correspondente foi encontrado na playlist.":total+" resultado(s) encontrado(s) na playlist • toque para reproduzir");
      if(total>shown[0]+added){Button more=navButton("CARREGAR MAIS RESULTADOS");results.addView(more,new LinearLayout.LayoutParams(-1,dp(46)));int next=added;more.setOnClickListener(v->{shown[0]+=next;render[0].run();});}
    };
    input.setText(initialQuery);input.setSelection(input.getText().length());
    input.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){query[0]=s.toString().trim();shown[0]=0;if(vodLoaded)render[0].run();else status.setText("Aguardando o carregamento da playlist...");}public void afterTextChanged(android.text.Editable e){}});
    input.setOnEditorActionListener((v,a,e)->{query[0]=input.getText().toString().trim();shown[0]=0;if(vodLoaded)render[0].run();return true;});
    results.addView(txt("Carregando catálogo...",13,Color.LTGRAY,false));
    if(vodLoaded){render[0].run();}else if(!vodLoading){loadCombinedVod(()->runOnUiThread(()->{if(!isFinishing())render[0].run();}));}else{
      // A playlist já está sendo baixada pela tela inicial; aguarda sem iniciar um segundo download.
      waitForVodAndRender(render[0]);
    }
  }
  private void waitForVodAndRender(Runnable render){mainHandler.postDelayed(()->{if(isFinishing())return;if(vodLoaded)render.run();else if(vodLoading)waitForVodAndRender(render);else if(!vodError.isEmpty())render.run();},500);}
  private void fetch(String type,String category,String query,LinearLayout target){if(TextUtils.isEmpty(TOKEN)){target.addView(txt("Configure a credencial TMDB no GitHub Actions.",12,Color.GRAY,false));return;}pool.execute(()->{try{String path=query==null?"/3/"+type+"/"+category+"?language=pt-BR&page=1":"/3/search/multi?query="+URLEncoder.encode(query,"UTF-8")+"&language=pt-BR&page=1";HttpURLConnection c=(HttpURLConnection)new URL("https://api.themoviedb.org"+path).openConnection();c.setRequestProperty("Authorization","Bearer "+TOKEN);c.setRequestProperty("accept","application/json");c.setConnectTimeout(15000);c.setReadTimeout(15000);int code=c.getResponseCode();InputStream in=code<400?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int count;while((count=in.read(buffer))!=-1)out.write(buffer,0,count);in.close();if(code>=400)throw new Exception("HTTP "+code);JSONArray arr=new JSONObject(out.toString("UTF-8")).optJSONArray("results");runOnUiThread(()->{if(arr==null||arr.length()==0){target.addView(txt("Nenhum título encontrado.",12,Color.GRAY,false));return;}for(int i=0;i<Math.min(arr.length(),20);i++)addItem(target,arr.optJSONObject(i),"multi".equals(type));});}catch(Exception ex){runOnUiThread(()->target.addView(txt("Não foi possível carregar. Verifique a conexão e o token TMDB.",12,Color.LTGRAY,false)));}});}
  private void addItem(LinearLayout row,JSONObject item,boolean vertical){String name=item.optString("title",item.optString("name","Título"));String date=item.optString("release_date",item.optString("first_air_date",""));String poster=item.optString("poster_path","");String overview=item.optString("overview","Sem sinopse disponível.");LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(5),dp(5),dp(5),dp(5));card.setBackground(bg(PANEL,12));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(vertical?-1:dp(132),vertical?-2:dp(250));cp.setMargins(0,0,dp(10),dp(10));row.addView(card,cp);ImageView image=new ImageView(this);image.setBackground(bg(Color.rgb(40,40,46),8));image.setScaleType(ImageView.ScaleType.CENTER_CROP);card.addView(image,new LinearLayout.LayoutParams(vertical?dp(100):dp(122),dp(175)));if(!poster.isEmpty())pool.execute(()->{try{URL u=new URL("https://image.tmdb.org/t/p/w342"+poster);Bitmap bm=BitmapFactory.decodeStream(u.openStream());runOnUiThread(()->image.setImageBitmap(bm));}catch(Exception ignored){}});TextView t=txt(name,13,Color.WHITE,true);t.setMaxLines(2);t.setEllipsize(TextUtils.TruncateAt.END);t.setPadding(0,dp(7),0,0);card.addView(t);card.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle(name+(date.isEmpty()?"":" • "+date.substring(0,4))).setMessage(overview).setPositiveButton("Fechar",null).show());}
  private String readText(InputStream in)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();return out.toString("UTF-8");}
  private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;} private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
  @Override public void onBackPressed(){if(exoPlayer!=null||playerView!=null){closePlayerAndReturn();}else home();}
  @Override protected void onDestroy(){super.onDestroy();releasePlayer();}
}
