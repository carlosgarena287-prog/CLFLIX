package com.clflix.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.content.pm.ActivityInfo;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import android.text.TextUtils;
import android.media.MediaPlayer;
import android.net.Uri;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class MainActivity extends Activity {
  private final int BG=Color.rgb(9,9,12), PANEL=Color.rgb(25,25,31), RED=Color.rgb(238,48,72);
  private LinearLayout root; private static final ExecutorService pool=Executors.newFixedThreadPool(4);
  private static final String TOKEN=BuildConfig.TMDB_BEARER_TOKEN;
  private static final String PLAYLIST_URL="https://iptv-org.github.io/iptv/countries/br.m3u";
  private final ArrayList<Channel> channels=new ArrayList<>();
  private VideoView videoView;
  private boolean channelsLoaded=false; private boolean landscapePlayer=false;
  static class Channel { String name,url,group,logo; Channel(String n,String u,String g,String l){name=n;url=u;group=g;logo=l;} }

  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);home();}

  private void home(){
    ScrollView sv=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(16),dp(16),dp(16),dp(30));root.setBackgroundColor(BG);sv.addView(root);
    LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);TextView logo=txt("C▶  CLNPLAY+",27,RED,true);bar.addView(logo,new LinearLayout.LayoutParams(0,-2,1));TextView tag=txt("FILMES  •  SÉRIES  •  AO VIVO",10,Color.LTGRAY,true);bar.addView(tag);root.addView(bar);
    LinearLayout nav=new LinearLayout(this);nav.setOrientation(0);nav.setPadding(0,dp(14),0,dp(4));
    Button homeBtn=navButton("INÍCIO");nav.addView(homeBtn,new LinearLayout.LayoutParams(0,dp(42),1));
    Button liveBtn=navButton("TV AO VIVO");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(42),1);lp.leftMargin=dp(8);nav.addView(liveBtn,lp);liveBtn.setOnClickListener(v->showChannels());
    Button moviesBtn=navButton("FILMES");LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,dp(42),1);mp.leftMargin=dp(8);nav.addView(moviesBtn,mp);moviesBtn.setOnClickListener(v->showVod("movies"));
    Button seriesBtn=navButton("SÉRIES");LinearLayout.LayoutParams spnav=new LinearLayout.LayoutParams(0,dp(42),1);spnav.leftMargin=dp(8);nav.addView(seriesBtn,spnav);seriesBtn.setOnClickListener(v->showVod("series"));root.addView(nav);
    EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(Color.WHITE);search.setHintTextColor(Color.GRAY);search.setHint("Buscar filmes e séries...");search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);search.setPadding(dp(14),0,dp(14),0);search.setBackground(bg(PANEL,13));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(50));sp.topMargin=dp(14);root.addView(search,sp);
    search.setOnEditorActionListener((v,a,e)->{String q=search.getText().toString().trim();if(!q.isEmpty())loadSearch(q);return true;});
    TextView hero=txt("DESCUBRA SEU PRÓXIMO\nFILME FAVORITO",24,Color.WHITE,true);hero.setPadding(dp(16),dp(24),dp(16),dp(24));hero.setBackground(bg(Color.rgb(67,13,25),16));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(18);root.addView(hero,hp);
    if(TextUtils.isEmpty(TOKEN)){TextView warn=txt("A API do TMDB ainda não foi configurada. Adicione TMDB_BEARER_TOKEN nos Secrets do GitHub Actions e gere o APK novamente.",13,Color.YELLOW,false);root.addView(warn);}
    section("FILMES POPULARES","movie","popular");section("SÉRIES POPULARES","tv","popular");section("FILMES MAIS BEM AVALIADOS","movie","top_rated");
    TextView credit=txt("Este produto usa a API do TMDB, mas não é endossado ou certificado pelo TMDB.",10,Color.GRAY,false);credit.setPadding(0,dp(26),0,0);root.addView(credit);
    setContentView(sv);
  }

  private Button navButton(String label){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setAllCaps(false);b.setBackground(bg(PANEL,10));return b;}

  private void showChannels(){
    LinearLayout page=new LinearLayout(this);page.setOrientation(1);page.setPadding(dp(16),dp(14),dp(16),dp(18));page.setBackgroundColor(BG);
    LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);TextView title=txt("CLNPLAY+  |  TV AO VIVO",21,RED,true);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));Button back=navButton("VOLTAR");header.addView(back);back.setOnClickListener(v->home());page.addView(header);
    TextView info=txt("Canais públicos disponíveis na playlist IPTV-org",12,Color.LTGRAY,false);info.setPadding(0,dp(8),0,dp(12));page.addView(info);
    EditText filter=new EditText(this);filter.setSingleLine(true);filter.setTextColor(Color.WHITE);filter.setHintTextColor(Color.GRAY);filter.setHint("Buscar canal...");filter.setPadding(dp(12),0,dp(12),0);filter.setBackground(bg(PANEL,10));page.addView(filter,new LinearLayout.LayoutParams(-1,dp(48)));
    ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(1);scroll.addView(list);LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,0,1);slp.topMargin=dp(10);page.addView(scroll,slp);setContentView(page);
    filter.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){renderChannels(list,s.toString());}public void afterTextChanged(android.text.Editable e){}});
    if(channelsLoaded)renderChannels(list,"");else {list.addView(txt("Carregando lista de canais...",14,Color.LTGRAY,false));loadPlaylist(list);}
  }

  private void loadPlaylist(LinearLayout list){pool.execute(()->{ArrayList<Channel> found=new ArrayList<>();HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(PLAYLIST_URL).openConnection();c.setConnectTimeout(20000);c.setReadTimeout(30000);c.setInstanceFollowRedirects(true);c.setRequestProperty("User-Agent","CLNPLAY+ Android");int status=c.getResponseCode();if(status<200||status>=300)throw new IOException("HTTP "+status);try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"))){String line,name=null,group="Outros",logo="";while((line=r.readLine())!=null){line=line.trim();if(line.startsWith("#EXTINF:")){int comma=line.lastIndexOf(',');name=comma>=0?line.substring(comma+1).trim():"Canal";Matcher gm=Pattern.compile("group-title=\"([^\"]*)\"").matcher(line);group=gm.find()?gm.group(1):"Outros";Matcher lm=Pattern.compile("tvg-logo=\"([^\"]*)\"").matcher(line);logo=lm.find()?lm.group(1):"";}else if(!line.isEmpty()&&!line.startsWith("#")&&name!=null){if(line.startsWith("https://")||line.startsWith("http://")){found.add(new Channel(name,line,group,logo));}name=null;}}}
      // Destaca as principais emissoras brasileiras no começo da lista.
      for(Channel ch:found){if(channelPriority(ch.name)<100)ch.group="PRINCIPAIS DO BRASIL";}
      Collections.sort(found,(a,b)->{int pa=channelPriority(a.name),pb=channelPriority(b.name);if(pa!=pb)return Integer.compare(pa,pb);int g=a.group.compareToIgnoreCase(b.group);if(g!=0)return g;return a.name.compareToIgnoreCase(b.name);});
      channels.clear();channels.addAll(found);channelsLoaded=true;runOnUiThread(()->renderChannels(list,""));
    }catch(Exception ex){runOnUiThread(()->{list.removeAllViews();list.addView(txt("Não foi possível carregar a playlist. Verifique sua conexão e tente novamente.",14,Color.LTGRAY,false));Button retry=navButton("TENTAR NOVAMENTE");list.addView(retry);retry.setOnClickListener(v->{channelsLoaded=false;loadPlaylist(list);});});}finally{if(c!=null)c.disconnect();}});}

  private int channelPriority(String name){
    String n=name.toLowerCase(Locale.ROOT);
    if(n.matches(".*\\b(globo|tv globo|globo sp|globo rj)\\b.*"))return 0;
    if(n.contains("sbt"))return 1;
    if(n.contains("record"))return 2;
    if(n.contains("band"))return 3;
    if(n.contains("rede tv")||n.contains("redetv"))return 4;
    if(n.contains("tv brasil"))return 5;
    if(n.contains("tv cultura")||n.equals("cultura"))return 6;
    if(n.contains("rede vida"))return 7;
    if(n.contains("tv senado"))return 8;
    if(n.contains("tv câmara")||n.contains("tv camara"))return 9;
    if(n.contains("canal gov"))return 10;
    return 100;
  }

  private void renderChannels(LinearLayout list,String query){list.removeAllViews();if(!channelsLoaded){list.addView(txt("Carregando canais...",13,Color.LTGRAY,false));return;}String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);int count=0;String lastGroup="";for(Channel ch:channels){if(!ch.name.toLowerCase(Locale.ROOT).contains(q)&&!ch.group.toLowerCase(Locale.ROOT).contains(q))continue;if(!ch.group.equals(lastGroup)){TextView heading=txt(ch.group.isEmpty()?"OUTROS":ch.group.toUpperCase(Locale.ROOT),14,RED,true);heading.setPadding(0,dp(16),0,dp(7));list.addView(heading);lastGroup=ch.group;}LinearLayout item=new LinearLayout(this);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(dp(10),dp(8),dp(10),dp(8));item.setBackground(bg(PANEL,10));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(66));p.bottomMargin=dp(7);list.addView(item,p);ImageView badge=new ImageView(this);badge.setScaleType(ImageView.ScaleType.FIT_CENTER);badge.setBackground(bg(Color.WHITE,7));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(48),dp(48));bp.rightMargin=dp(12);item.addView(badge,bp);if(!TextUtils.isEmpty(ch.logo))pool.execute(()->{try{HttpURLConnection lc=(HttpURLConnection)new URL(ch.logo).openConnection();lc.setConnectTimeout(7000);lc.setReadTimeout(7000);Bitmap bm=BitmapFactory.decodeStream(lc.getInputStream());lc.disconnect();if(bm!=null)runOnUiThread(()->badge.setImageBitmap(bm));}catch(Exception ignored){}});else badge.setImageDrawable(bg(RED,7));TextView channelName=txt(ch.name,15,Color.WHITE,true);channelName.setMaxLines(2);channelName.setEllipsize(TextUtils.TruncateAt.END);item.addView(channelName,new LinearLayout.LayoutParams(0,-2,1));TextView play=txt("▶",19,RED,true);item.addView(play);item.setOnClickListener(v->playChannel(ch));count++;}if(count==0)list.addView(txt("Nenhum canal encontrado.",13,Color.GRAY,false));else {TextView total=txt(count+" canais encontrados",11,Color.GRAY,false);total.setPadding(0,dp(12),0,0);list.addView(total);}}

  private void playChannel(Channel ch){
    // Mantém a Activity viva durante a mudança de orientação e abre o player em paisagem.
    landscapePlayer=true;
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    LinearLayout page=new LinearLayout(this);page.setOrientation(1);page.setPadding(dp(12),dp(14),dp(12),dp(14));page.setBackgroundColor(Color.BLACK);
    LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);Button back=navButton("‹ CANAIS");header.addView(back);TextView title=txt(ch.name,16,Color.WHITE,true);title.setPadding(dp(10),0,0,0);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));Button rotate=navButton("⛶  GIRAR TELA");header.addView(rotate);rotate.setOnClickListener(v->togglePlayerOrientation());page.addView(header);back.setOnClickListener(v->{restorePlayerOrientation();if(videoView!=null){videoView.stopPlayback();videoView=null;}showChannels();});
    videoView=new VideoView(this);LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,0,1);vp.gravity=Gravity.CENTER;page.addView(videoView,vp);TextView note=txt("Toque em GIRAR TELA para assistir na horizontal. A disponibilidade da transmissão depende da emissora e da fonte.",10,Color.GRAY,false);note.setPadding(dp(4),dp(10),dp(4),dp(4));page.addView(note);setContentView(page);
    MediaController controller=new MediaController(this);controller.setAnchorView(videoView);videoView.setMediaController(controller);videoView.setVideoURI(Uri.parse(ch.url));videoView.setOnPreparedListener(mp->{mp.setOnVideoSizeChangedListener((m,w,h)->controller.setAnchorView(videoView));videoView.start();});videoView.setOnErrorListener((mp,what,extra)->{Toast.makeText(this,"Não foi possível reproduzir este canal neste dispositivo.",Toast.LENGTH_LONG).show();return true;});
  }



  private static class VodItem { String name,url,logo,group; VodItem(String n,String u,String l,String g){name=n;url=u;logo=l;group=g;} }
  // Uma única playlist M3U do repositório indicado pelo usuário.
  private static final String VOD_M3U="https://raw.githubusercontent.com/Ramys/Iptv-Brasil-2026/master/Filmes-Series.m3u8";
  private static final int VOD_PAGE_SIZE=80;
  private static final int VOD_MAX_PER_CATEGORY=30000;
  private static final ArrayList<VodItem> vodMovies=new ArrayList<>(), vodSeries=new ArrayList<>();
  private static volatile boolean vodLoaded=false, vodLoading=false;
  private static String vodError="";
  private void showVod(String kind){
    final boolean movie="movies".equals(kind);
    LinearLayout page=new LinearLayout(this);page.setOrientation(1);page.setPadding(dp(16),dp(14),dp(16),dp(18));page.setBackgroundColor(BG);
    LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
    TextView title=txt(movie?"CLNPLAY+  |  FILMES":"CLNPLAY+  |  SÉRIES",21,RED,true);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
    Button back=navButton("VOLTAR");header.addView(back);back.setOnClickListener(v->home());page.addView(header);
    TextView info=txt("Catálogo da playlist Filmes-Series • Capas e informações pela API TMDB",12,Color.LTGRAY,false);info.setPadding(0,dp(8),0,dp(12));page.addView(info);
    EditText filter=new EditText(this);filter.setSingleLine(true);filter.setTextColor(Color.WHITE);filter.setHintTextColor(Color.GRAY);filter.setHint("Buscar título...");filter.setPadding(dp(12),0,dp(12),0);filter.setBackground(bg(PANEL,10));page.addView(filter,new LinearLayout.LayoutParams(-1,dp(48)));
    ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(1);scroll.addView(list);LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,0,1);slp.topMargin=dp(10);page.addView(scroll,slp);setContentView(page);
    final int[] shown={0}; final String[] currentQuery={""}; final Runnable[] render={null};
    render[0]=()->{list.removeAllViews();ArrayList<VodItem> source=movie?vodMovies:vodSeries;String q=currentQuery[0].toLowerCase(Locale.ROOT);int matched=0,added=0;for(VodItem item:source){if(!q.isEmpty()&&!item.name.toLowerCase(Locale.ROOT).contains(q)&&!item.group.toLowerCase(Locale.ROOT).contains(q))continue;matched++;if(matched<=shown[0]||added>=VOD_PAGE_SIZE)continue;addVodItem(list,item,movie);added++;}if(matched==0){list.addView(txt(vodLoading?"Baixando e lendo a playlist...":(vodError.isEmpty()?"Nenhum título encontrado.":vodError),13,Color.LTGRAY,false));}else{TextView total=txt(added+" de "+matched+" títulos exibidos",11,Color.GRAY,false);total.setPadding(0,dp(10),0,dp(8));list.addView(total);if(shown[0]+added<matched){final int pageAdded=added;Button more=navButton("CARREGAR MAIS");list.addView(more,new LinearLayout.LayoutParams(-1,dp(46)));more.setOnClickListener(v->{shown[0]+=pageAdded;render[0].run();});}}};
    filter.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){currentQuery[0]=s.toString();shown[0]=0;if(vodLoaded)render[0].run();}public void afterTextChanged(android.text.Editable e){}});
    shown[0]=0;list.addView(txt("Carregando playlist de filmes e séries...",14,Color.LTGRAY,false));
    if(vodLoaded){render[0].run();return;} if(!vodLoading)loadCombinedVod(()->{if(!isFinishing())runOnUiThread(()->render[0].run());});
  }

  private void loadCombinedVod(Runnable completion){
    vodLoading=true;pool.execute(()->{HttpURLConnection c=null;String name=null,logo="",group="Outros";int parsed=0;
      try{URL url=new URL(VOD_M3U);c=(HttpURLConnection)url.openConnection();c.setConnectTimeout(30000);c.setReadTimeout(60000);c.setInstanceFollowRedirects(true);c.setRequestProperty("User-Agent","CLNPLAY+ Android");c.setRequestProperty("Accept-Encoding","identity");int code=c.getResponseCode();if(code<200||code>=300)throw new IOException("HTTP "+code);
        try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"),65536)){String line;while((line=r.readLine())!=null){line=line.trim();if(line.isEmpty())continue;if(line.startsWith("#EXTINF:")){int comma=line.lastIndexOf(',');name=comma>=0?line.substring(comma+1).trim():"Título";Matcher lm=Pattern.compile("tvg-logo=\"([^\"]*)\"").matcher(line);logo=lm.find()?lm.group(1):"";Matcher gm=Pattern.compile("group-title=\"([^\"]*)\"").matcher(line);group=gm.find()?gm.group(1):"Outros";}else if(!line.startsWith("#")&&name!=null&&(line.startsWith("http://")||line.startsWith("https://"))){VodItem item=new VodItem(name,line,logo,group);if(isSeriesEntry(name,group)){if(vodSeries.size()<VOD_MAX_PER_CATEGORY)vodSeries.add(item);}else{if(vodMovies.size()<VOD_MAX_PER_CATEGORY)vodMovies.add(item);}parsed++;name=null;logo="";group="Outros";}}
        }
        vodLoaded=true;vodError=parsed==0?"A playlist foi aberta, mas não foram encontrados itens M3U válidos.":"";
      }catch(Exception ex){vodError="Falha ao carregar a playlist ("+ex.getClass().getSimpleName()+"). Confira a conexão e tente novamente.";}
      finally{if(c!=null)c.disconnect();vodLoading=false;if(completion!=null)completion.run();}
    });
  }
  private boolean isSeriesEntry(String name,String group){
    String n=name.toLowerCase(Locale.ROOT),g=group.toLowerCase(Locale.ROOT);
    boolean episode=n.matches(".*\\bs[0-9]{1,2}e[0-9]{1,2}\\b.*")||n.matches(".*\\b[0-9]{1,2}x[0-9]{1,2}\\b.*")||n.contains("temporada")||n.contains("episódio")||n.contains("episode");
    boolean seriesGroup=(g.contains("série")||g.contains("series")||g.contains("temporada")||g.contains("season"))&&!g.contains("filme");
    return episode||seriesGroup;
  }
  private void filterVod(LinearLayout list,String query){String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);for(int i=0;i<list.getChildCount();i++){View v=list.getChildAt(i);Object tag=v.getTag();if(tag instanceof String)v.setVisibility(((String)tag).toLowerCase(Locale.ROOT).contains(q)?View.VISIBLE:View.GONE);}}
  private void addVodItem(LinearLayout list,VodItem item,boolean movie){LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(9),dp(8),dp(9),dp(8));card.setBackground(bg(PANEL,10));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(112));cp.bottomMargin=dp(8);list.addView(card,cp);card.setTag(item.name);ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);poster.setBackground(bg(Color.rgb(40,40,46),7));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(68),dp(96));pp.rightMargin=dp(12);card.addView(poster,pp);LinearLayout details=new LinearLayout(this);details.setOrientation(1);card.addView(details,new LinearLayout.LayoutParams(0,-2,1));TextView name=txt(item.name,14,Color.WHITE,true);name.setMaxLines(3);details.addView(name);TextView group=txt(item.group,11,Color.GRAY,false);group.setPadding(0,dp(5),0,0);details.addView(group);
    if(!TextUtils.isEmpty(TOKEN))pool.execute(()->{HttpURLConnection c=null;try{String type=movie?"movie":"tv";String clean=item.name.replaceAll("\\(.*?\\)","").trim();String api="https://api.themoviedb.org/3/search/"+type+"?query="+URLEncoder.encode(clean,"UTF-8")+"&language=pt-BR&page=1";c=(HttpURLConnection)new URL(api).openConnection();c.setRequestProperty("Authorization","Bearer "+TOKEN);c.setConnectTimeout(10000);c.setReadTimeout(10000);int status=c.getResponseCode();if(status<200||status>=300)return;JSONObject data=new JSONObject(readText(c.getInputStream()));JSONArray results=data.optJSONArray("results");JSONObject first=results!=null&&results.length()>0?results.optJSONObject(0):null;String path=first==null?"":first.optString("poster_path","");if(!path.isEmpty()){HttpURLConnection pc=(HttpURLConnection)new URL("https://image.tmdb.org/t/p/w342"+path).openConnection();pc.setConnectTimeout(10000);pc.setReadTimeout(10000);Bitmap bm=BitmapFactory.decodeStream(pc.getInputStream());pc.disconnect();if(bm!=null)runOnUiThread(()->{if(poster.getParent()!=null)poster.setImageBitmap(bm);});}}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}});
    card.setOnClickListener(v->playVod(item));}
  private void playVod(VodItem item){playChannel(new Channel(item.name,item.url,item.group,item.logo));}

  private void togglePlayerOrientation(){
    landscapePlayer=!landscapePlayer;
    if(landscapePlayer){setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);}
    else restorePlayerOrientation();
  }
  private void restorePlayerOrientation(){landscapePlayer=false;setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);getWindow().getDecorView().setSystemUiVisibility(0);}

  private void section(String title,String type,String category){LinearLayout block=new LinearLayout(this);block.setOrientation(1);TextView h=txt(title,17,Color.WHITE,true);h.setPadding(0,dp(22),0,dp(10));block.addView(h);HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);row.setOrientation(0);hs.addView(row);block.addView(hs);root.addView(block);fetch(type,category,null,row);}
  private void loadSearch(String q){root.removeViews(4,Math.max(0,root.getChildCount()-4));TextView h=txt("RESULTADOS: "+q.toUpperCase(),18,Color.WHITE,true);h.setPadding(0,dp(20),0,dp(10));root.addView(h);LinearLayout row=new LinearLayout(this);row.setOrientation(1);root.addView(row);fetch("multi","search",q,row);}
  private void fetch(String type,String category,String query,LinearLayout target){if(TextUtils.isEmpty(TOKEN)){target.addView(txt("Configure a credencial TMDB no GitHub Actions.",12,Color.GRAY,false));return;}pool.execute(()->{try{String path=query==null?"/3/"+type+"/"+category+"?language=pt-BR&page=1":"/3/search/multi?query="+URLEncoder.encode(query,"UTF-8")+"&language=pt-BR&page=1";HttpURLConnection c=(HttpURLConnection)new URL("https://api.themoviedb.org"+path).openConnection();c.setRequestProperty("Authorization","Bearer "+TOKEN);c.setRequestProperty("accept","application/json");c.setConnectTimeout(15000);c.setReadTimeout(15000);int code=c.getResponseCode();InputStream in=code<400?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int count;while((count=in.read(buffer))!=-1)out.write(buffer,0,count);in.close();if(code>=400)throw new Exception("HTTP "+code);JSONArray arr=new JSONObject(out.toString("UTF-8")).optJSONArray("results");runOnUiThread(()->{if(arr==null||arr.length()==0){target.addView(txt("Nenhum título encontrado.",12,Color.GRAY,false));return;}for(int i=0;i<Math.min(arr.length(),20);i++)addItem(target,arr.optJSONObject(i),"multi".equals(type));});}catch(Exception ex){runOnUiThread(()->target.addView(txt("Não foi possível carregar. Verifique a conexão e o token TMDB.",12,Color.LTGRAY,false)));}});}
  private void addItem(LinearLayout row,JSONObject item,boolean vertical){String name=item.optString("title",item.optString("name","Título"));String date=item.optString("release_date",item.optString("first_air_date",""));String poster=item.optString("poster_path","");String overview=item.optString("overview","Sem sinopse disponível.");LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(5),dp(5),dp(5),dp(5));card.setBackground(bg(PANEL,12));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(vertical?-1:dp(132),vertical?-2:dp(250));cp.setMargins(0,0,dp(10),dp(10));row.addView(card,cp);ImageView image=new ImageView(this);image.setBackground(bg(Color.rgb(40,40,46),8));image.setScaleType(ImageView.ScaleType.CENTER_CROP);card.addView(image,new LinearLayout.LayoutParams(vertical?dp(100):dp(122),dp(175)));if(!poster.isEmpty())pool.execute(()->{try{URL u=new URL("https://image.tmdb.org/t/p/w342"+poster);Bitmap bm=BitmapFactory.decodeStream(u.openStream());runOnUiThread(()->image.setImageBitmap(bm));}catch(Exception ignored){}});TextView t=txt(name,13,Color.WHITE,true);t.setMaxLines(2);t.setEllipsize(TextUtils.TruncateAt.END);t.setPadding(0,dp(7),0,0);card.addView(t);card.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle(name+(date.isEmpty()?"":" • "+date.substring(0,4))).setMessage(overview).setPositiveButton("Fechar",null).show());}
  private String readText(InputStream in)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();return out.toString("UTF-8");}
  private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;} private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
  @Override public void onBackPressed(){if(videoView!=null){restorePlayerOrientation();videoView.stopPlayback();videoView=null;showChannels();}else home();}
  @Override protected void onDestroy(){super.onDestroy();if(videoView!=null){videoView.stopPlayback();videoView=null;}}
}
