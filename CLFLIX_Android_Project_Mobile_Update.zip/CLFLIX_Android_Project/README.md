# CLFLIX Android

Projeto Android simples para gerar um APK de depuração pelo GitHub Actions.

## O que esta versão melhora
- Identidade visual CLFLIX com cores escuras e detalhes vermelhos.
- Ícone próprio do aplicativo.
- Cabeçalho com marca CLFLIX e botões Início, Voltar e Recarregar.
- O conteúdo web e a navegação HTTP/HTTPS permanecem dentro do aplicativo, em vez de abrir o navegador externo.
- Aviso de carregamento e mensagens básicas de erro.
- Safe Browsing ativado quando disponível; acesso a arquivos locais desativado.

## Importante
O catálogo e o player continuam sendo carregados a partir de `https://vidbox.wtf/providers`. Esta versão melhora a experiência visual e mantém navegação web dentro do app; ela não transforma o catálogo em dados nativos nem garante que todos os players de terceiros funcionem em tela cheia. A integração direta exigiria uma API ou outro método de integração disponibilizado/autorizado pelo serviço.

## Compilar
O workflow de GitHub Actions compila `app:assembleDebug` e publica o APK como artefato `CLFLIX-debug-apk`.

## Atualização 1.1 — reprodução em tela cheia

Esta versão mantém o catálogo atual (`https://vidbox.wtf/providers`) e melhora a integração da WebView com vídeos HTML5: quando o player da página solicita tela cheia, o CLFLIX oculta a barra e a navegação do sistema e mostra o vídeo em tela cheia. O botão Voltar retorna ao app e à navegação anterior.

### Limite desta atualização

Esta atualização **não integra a API do MegaFlix** nem troca a fonte do catálogo. O APK analisado consulta um endpoint remoto e espera uma resposta e uma ponte JavaScript próprias (`MegaFlix`); não há documentação pública confirmada que permita implementar essa integração de forma compatível apenas com os endereços vistos no APK. A reprodução em tela cheia depende do player da página atual e não cria faixas de áudio/legendas que a fonte não ofereça.

Para uma integração com outro serviço, use uma API/documentação autorizada ou um endpoint que você controle.
