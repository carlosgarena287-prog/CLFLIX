# CLNPLAY+ — Professional Beta

Baseado na versão de transição do player. Mantém as funcionalidades existentes e o workflow `.github/workflows/main.yml` original.

Melhorias nesta versão:
- Lista de canais em páginas de 100 itens para reduzir criação simultânea de Views e uso de memória.
- Busca de canais com debounce de 280 ms.
- Cache LRU em memória para logos e posters (RGB_565 para reduzir consumo de RAM).
- Busca do catálogo com debounce de 250 ms.
- Pool de tarefas de rede reduzido para 3 threads para evitar excesso de concorrência.
- Encerramento do ExoPlayer com desvinculação da PlayerView antes de liberar o decoder.
- Voltar do player pelo botão ou botão físico usa o mesmo fluxo de encerramento protegido.

Atenção: ZIP validado estruturalmente; compilação Android e teste em aparelho precisam ser confirmados pelo GitHub Actions e no dispositivo.
