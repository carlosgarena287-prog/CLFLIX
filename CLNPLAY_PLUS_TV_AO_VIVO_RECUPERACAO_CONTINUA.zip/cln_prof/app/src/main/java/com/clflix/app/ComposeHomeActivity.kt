package com.clflix.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class ComposeHomeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 9, 12)
        window.navigationBarColor = android.graphics.Color.rgb(9, 9, 12)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Color(0xFF09090C), surface = Color(0xFF19191F),
                primary = Color(0xFFEE3048), onPrimary = Color.White,
                onBackground = Color.White, onSurface = Color.White
            )) {
                HomeScreen(onOpen = {
                    startActivity(Intent(this, MainActivity::class.java))
                })
            }
        }
    }
}

@Composable
private fun HomeScreen(onOpen: () -> Unit) {
    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF09090C)) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("C▶", color = Color(0xFFEE3048), fontSize = 58.sp, fontWeight = FontWeight.Black)
            Text("CLNPLAY+", color = Color.White, fontSize = 31.sp, fontWeight = FontWeight.ExtraBold)
            Text("SEU ENTRETENIMENTO EM UM SÓ LUGAR", color = Color.LightGray,
                fontSize = 10.sp, letterSpacing = 1.5.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(38.dp))
            FeatureLine("TV AO VIVO", "Canais disponíveis na playlist")
            FeatureLine("FILMES E SÉRIES", "Catálogo carregado das listas configuradas")
            FeatureLine("BUSCA", "Pesquise títulos disponíveis para reprodução")
            FeatureLine("PLAYER", "Continue usando o player integrado existente")
            Spacer(Modifier.height(32.dp))
            Button(
                onClick = onOpen,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEE3048))
            ) {
                Text("ENTRAR NO CLNPLAY+", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            Text("A interface Compose foi adicionada sem remover os recursos existentes.",
                color = Color.Gray, fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 22.dp))
        }
    }
}

@Composable
private fun FeatureLine(title: String, description: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp)
            .background(Color(0xFF19191F), RoundedCornerShape(12.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(description, color = Color.LightGray, fontSize = 11.sp)
        }
    }
}
