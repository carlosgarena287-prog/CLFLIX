# CLFLIX Mobile — base inicial

Projeto Android nativo em Java, com identidade visual preta/vermelha, tela de abertura animada sem porcentagem, navegação inicial e atalho para as configurações de DNS privado do Android.

## Estado desta versão

- Splash animada com letras CLFLIX pulsando e pontos em movimento.
- Tela inicial mobile própria.
- Seções iniciais para filmes, séries, minha lista e histórico.
- Atalho para configurar manualmente o AdGuard DNS Family (`family.adguard-dns.com`).
- Workflow GitHub Actions para gerar APK debug.

## Importante

Esta versão é uma base inicial de interface. Ainda não possui catálogo remoto, login, sincronização ou player. A busca online precisa de uma fonte de metadados com credenciais/API apropriadas. O aplicativo não incorpora páginas de terceiros que possam exibir publicidade adulta ou conteúdo sem autorização.

## Gerar APK

Envie o conteúdo desta pasta para a raiz do repositório GitHub. Abra Actions, selecione `Build CLFLIX Mobile APK` e execute `Run workflow`. O APK aparecerá como artefato `CLFLIX-Mobile-debug-apk`.
