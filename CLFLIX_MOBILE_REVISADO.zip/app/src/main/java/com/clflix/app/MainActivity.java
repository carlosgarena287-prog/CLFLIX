package com.clflix.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.content.pm.ActivityInfo;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceError;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ProgressBar;
import android.animation.ValueAnimator;
import android.view.animation.DecelerateInterpolator;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private static final String START_URL = "https://www.pobreflixtv.sale/";
    private static final int BG = Color.rgb(7, 8, 11);
    private static final int PANEL = Color.rgb(17, 19, 24);
    private static final int RED = Color.rgb(239, 25, 49);
    private WebView webView;
    private Button backButton;
    private LinearLayout rootLayout;
    private LinearLayout headerLayout;
    private TextView footerView;
    private FrameLayout contentFrame;
    private FrameLayout loadingOverlay;
    private ProgressBar loadingProgress;
    private TextView loadingPercent;
    private TextView loadingLogo;
    private TextView loadingMessage;
    private View fullscreenView;
    private WebChromeClient.CustomViewCallback fullscreenCallback;
    private int previousOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
    private int previousSystemUiVisibility;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        buildLayout();
        configureWebView();
        if (savedInstanceState == null) webView.loadUrl(START_URL);
        else {
            android.webkit.WebBackForwardList ignored = null;
            if (webView.restoreState(savedInstanceState) == null) webView.loadUrl(START_URL);
        }
    }

    private void buildLayout() {
        LinearLayout root = new LinearLayout(this);
        rootLayout = root;
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        headerLayout = header;
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(15), dp(10), dp(10), dp(10));
        header.setBackgroundColor(PANEL);

        TextView mark = new TextView(this);
        mark.setText("▶");
        mark.setTextColor(RED);
        mark.setTextSize(27);
        mark.setTypeface(Typeface.DEFAULT_BOLD);
        mark.setGravity(Gravity.CENTER);
        header.addView(mark, new LinearLayout.LayoutParams(dp(34), dp(40)));

        TextView logo = new TextView(this);
        logo.setText("CLFLIX");
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(23);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setLetterSpacing(0.02f);
        android.text.SpannableString word = new android.text.SpannableString("CLFLIX");
        word.setSpan(new android.text.style.ForegroundColorSpan(RED), 2, 6, 0);
        logo.setText(word);
        header.addView(logo, new LinearLayout.LayoutParams(0, -2, 1));

        backButton = makeButton("‹", "Voltar", false);
        backButton.setOnClickListener(v -> {
            if (webView != null && webView.canGoBack()) webView.goBack();
            else Toast.makeText(this, "Você já está na página inicial", Toast.LENGTH_SHORT).show();
        });
        header.addView(backButton, buttonParams());

        Button home = makeButton("⌂", "Início", false);
        home.setOnClickListener(v -> {
            if (webView != null) webView.loadUrl(START_URL);
        });
        header.addView(home, buttonParams());

        Button reload = makeButton("↻", "Recarregar", true);
        reload.setOnClickListener(v -> { if (webView != null) webView.reload(); });
        header.addView(reload, buttonParams());
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout content = new FrameLayout(this);
        contentFrame = content;
        webView = new WebView(this);
        webView.setBackgroundColor(BG);
        content.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        buildLoadingOverlay(content);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView footer = new TextView(this);
        footerView = footer;
        footer.setText("CLFLIX  •  FILMES  •  SÉRIES  •  ANIMES");
        footer.setTextColor(Color.rgb(130, 132, 142));
        footer.setTextSize(10);
        footer.setLetterSpacing(0.08f);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(dp(8), dp(8), dp(8), dp(8));
        footer.setBackgroundColor(PANEL);
        root.addView(footer, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private void buildLoadingOverlay(FrameLayout parent) {
        loadingOverlay = new FrameLayout(this);
        loadingOverlay.setBackground(new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(5, 6, 10), Color.rgb(20, 8, 14), Color.rgb(5, 6, 10)}));

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);
        center.setPadding(dp(34), dp(28), dp(34), dp(28));

        TextView symbol = new TextView(this);
        symbol.setText("▶");
        symbol.setTextColor(RED);
        symbol.setTextSize(30);
        symbol.setGravity(Gravity.CENTER);
        center.addView(symbol, new LinearLayout.LayoutParams(-1, dp(42)));

        TextView logo = new TextView(this);
        loadingLogo = logo;
        android.text.SpannableString word = new android.text.SpannableString("CLFLIX");
        word.setSpan(new android.text.style.ForegroundColorSpan(RED), 2, 6, 0);
        logo.setText(word);
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(38);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setLetterSpacing(0.12f);
        logo.setGravity(Gravity.CENTER);
        center.addView(logo, new LinearLayout.LayoutParams(-1, dp(58)));

        TextView tagline = new TextView(this);
        tagline.setText("SEU ENTRETENIMENTO COMEÇA AQUI");
        tagline.setTextColor(Color.rgb(155, 157, 166));
        tagline.setTextSize(10);
        tagline.setLetterSpacing(0.13f);
        tagline.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(5);
        center.addView(tagline, tp);

        loadingProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loadingProgress.setMax(100);
        loadingProgress.setProgress(0);
        loadingProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(RED));
        loadingProgress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(48, 32, 39)));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(220), dp(4));
        pp.topMargin = dp(28);
        center.addView(loadingProgress, pp);

        loadingPercent = new TextView(this);
        loadingPercent.setText("0%");
        loadingPercent.setTextColor(Color.rgb(205, 205, 212));
        loadingPercent.setTextSize(11);
        loadingPercent.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams pct = new LinearLayout.LayoutParams(-1, -2);
        pct.topMargin = dp(10);
        center.addView(loadingPercent, pct);

        loadingMessage = new TextView(this);
        loadingMessage.setText("Preparando sua experiência...");
        loadingMessage.setTextColor(Color.rgb(130, 132, 142));
        loadingMessage.setTextSize(12);
        loadingMessage.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
        mp.topMargin = dp(8);
        center.addView(loadingMessage, mp);

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        loadingOverlay.addView(center, cp);
        parent.addView(loadingOverlay, new FrameLayout.LayoutParams(-1, -1));

        ValueAnimator pulse = ValueAnimator.ofFloat(0.72f, 1.0f);
        pulse.setDuration(950);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.setInterpolator(new DecelerateInterpolator());
        pulse.addUpdateListener(a -> {
            float v = (float) a.getAnimatedValue();
            logo.setAlpha(v);
            logo.setScaleX(0.98f + (v * 0.02f));
            logo.setScaleY(0.98f + (v * 0.02f));
        });
        pulse.start();
    }

    private void updateLoading(int progress, String message) {
        if (loadingOverlay == null) return;
        loadingOverlay.setVisibility(View.VISIBLE);
        loadingProgress.setProgress(Math.max(0, Math.min(100, progress)));
        loadingPercent.setText(Math.max(0, Math.min(100, progress)) + "%");
        loadingMessage.setText(message);
    }

    private Button makeButton(String text, String description, boolean accent) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(23);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(0, 0, 0, 0);
        b.setTextColor(accent ? Color.WHITE : Color.LTGRAY);
        b.setContentDescription(description);
        b.setBackground(roundDrawable(accent ? RED : Color.rgb(34, 36, 43), dp(12), accent ? RED : Color.rgb(50, 52, 60)));
        return b;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(42), dp(42));
        p.setMargins(dp(3), 0, 0, 0);
        return p;
    }

    private GradientDrawable roundDrawable(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(dp(1), stroke);
        return d;
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        if (android.os.Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                if (loadingOverlay != null && loadingOverlay.getVisibility() == View.VISIBLE)
                    updateLoading(progress, progress < 35 ? "Conectando com segurança..." : progress < 80 ? "Carregando seu catálogo..." : "Finalizando...");
            }
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (fullscreenView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                fullscreenView = view;
                fullscreenCallback = callback;
                previousOrientation = getRequestedOrientation();
                previousSystemUiVisibility = getWindow().getDecorView().getSystemUiVisibility();

                if (webView != null) webView.setVisibility(View.GONE);
                if (headerLayout != null) headerLayout.setVisibility(View.GONE);
                if (footerView != null) footerView.setVisibility(View.GONE);

                FrameLayout decor = (FrameLayout) getWindow().getDecorView();
                decor.addView(view, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            }

            @Override public void onHideCustomView() {
                hideFullscreenVideo();
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                // Keep web navigation inside CLFLIX instead of launching the external browser.
                if ("https".equals(scheme) || "http".equals(scheme)) return false;
                // Block non-web schemes so a page cannot unexpectedly launch another app.
                return true;
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                updateLoading(0, "Conectando com segurança...");
                if (backButton != null) backButton.setEnabled(view.canGoBack());
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (loadingOverlay != null) loadingOverlay.setVisibility(View.GONE);
                if (backButton != null) backButton.setEnabled(view.canGoBack());
                // Hide only a Discord invitation/promo link. Security and Cloudflare checks remain untouched.
                String hideDiscordInvite = "(function(){try{document.querySelectorAll('a[href*=\"discord.gg\"],a[href*=\"discord.com/invite\"]').forEach(function(a){var p=a;for(var i=0;i<4&&p&&p!==document.body;i++,p=p.parentElement){if(p.innerText&&p.innerText.length<700){p.style.setProperty('display','none','important');break;}}});}catch(e){}})();";
                view.evaluateJavascript(hideDiscordInvite, null);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    updateLoading(0, "Não foi possível carregar. Verifique sua conexão e toque em ↻ para tentar novamente.");
                }
            }
        });
    }

    private void hideFullscreenVideo() {
        if (fullscreenView == null) return;
        FrameLayout decor = (FrameLayout) getWindow().getDecorView();
        decor.removeView(fullscreenView);
        fullscreenView = null;
        if (webView != null) webView.setVisibility(View.VISIBLE);
        if (headerLayout != null) headerLayout.setVisibility(View.VISIBLE);
        if (footerView != null) footerView.setVisibility(View.VISIBLE);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(previousSystemUiVisibility);
        setRequestedOrientation(previousOrientation);
        if (fullscreenCallback != null) {
            fullscreenCallback.onCustomViewHidden();
            fullscreenCallback = null;
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onBackPressed() {
        if (fullscreenView != null) { hideFullscreenVideo(); return; }
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }
    @Override protected void onDestroy() {
        if (fullscreenView != null) hideFullscreenVideo();
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
