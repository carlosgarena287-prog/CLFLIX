# CLFLIX Android

Projeto Android para compilar um APK de depuração pelo GitHub Actions.

## Melhorias desta versão
- Tela de carregamento premium com marca CLFLIX animada, barra de progresso e mensagens por etapa.
- Oculta convites promocionais que apontem diretamente para links de convite do Discord, quando esses links aparecem na página.
- Mantém a identidade visual escura/vermelha, os botões Voltar, Início e Recarregar e a navegação web dentro do app.
- Mantém suporte ao modo de vídeo em tela cheia quando o player do site solicita o modo fullscreen.
- Mantém Safe Browsing e bloqueio de conteúdo misto.

## Limitações importantes
O catálogo e o player continuam vindo de `https://www.pobreflixtv.sale/`. Esta versão ainda não é uma interface nativa independente. Para isso, o serviço precisa disponibilizar uma API/feed autorizado com catálogo, imagens, metadados e endereços de reprodução.

A verificação de segurança do Cloudflare não é removida nem contornada. Se o serviço exigir essa verificação, ela continuará aparecendo.

A remoção do convite do Discord funciona apenas quando a página apresenta um link reconhecível para `discord.gg` ou `discord.com/invite`; mudanças no site podem exigir ajuste.

## Compilar
Envie o conteúdo deste ZIP para a raiz do repositório GitHub. O workflow em `.github/workflows/build-apk.yml` compila o APK e publica o artefato `CLFLIX-debug-apk`.
