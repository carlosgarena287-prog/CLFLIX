# CLNPLAY+ 3.4

Projeto Android com interface Jetpack Compose e reprodução integrada Media3/ExoPlayer.

- TV ao vivo: lista M3U configurável + lista do usuário embutida (`app/src/main/assets/lista_usuario.m3u`) + lista extra opcional
- Filmes e séries em seções separadas, cada uma com pesquisa, paginação (TV 50 por vez; filmes e séries 10 por vez) e estado de carregamento próprios
- Pesquisa com atraso de 350 ms, procurando no catálogo completo da seção
- Filtro de conteúdo adulto ativado por padrão (configurável no menu LISTAS)
- Filtro de estrangeiros: só oculta canais com país explicitamente diferente de Brasil
- Player com controles que somem após 3 s e voltam ao toque (expandir, tela cheia, play/pause, barra de posição nos filmes)
- Visual estilo streaming: banner de destaque, carrosséis na tela inicial, grade de capas e navegação inferior
- Capas de filmes e séries via API oficial do TMDB (secret `TMDB_BEARER_TOKEN`), carregadas sob demanda e guardadas em cache; logos dos canais vêm do `tvg-logo` da playlist
- Opção "Sem filtros" no menu LISTAS: desliga filtro adulto, filtro de estrangeiros e categorias
- Atalhos oficiais (Band e Globoplay) abrem no navegador

Este produto usa a API do TMDB, mas não é endossado nem certificado pelo TMDB.

O app não hospeda conteúdo. Configure apenas playlists e transmissões que você tenha autorização para acessar.

Build: GitHub Actions (`.github/workflows/main.yml`, não modificado).
