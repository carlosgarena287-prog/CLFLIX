package com.clflix.app

import android.content.Context
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer

private val Bg = Color(0xFF0A0A0F)
private val Panel = Color(0xFF17171F)
private val Accent = Color(0xFFE50935)
private val Muted = Color(0xFF9AA1B2)

class ComposeHomeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8,9,13)
        window.navigationBarColor = android.graphics.Color.rgb(8,9,13)
        setContent { MaterialTheme(colorScheme = darkColorScheme(
            primary=Accent, background=Bg, surface=Panel, onPrimary=Color.White,
            onBackground=Color.White, onSurface=Color.White
        )) { ClnApp() } }
    }
}

data class MediaEntry(
    val title:String, val url:String, val group:String, val logo:String="", val kind:String="TV",
    val country:String="", val tvgId:String="", val source:String="",
    val norm:String="", val adult:Boolean=false,
    val referrer:String="", val userAgent:String=""
)

private const val TV_LIST = "https://iptv-org.github.io/iptv/countries/br.m3u"
private const val GLOBAL_TV_LIST = "https://iptv-org.github.io/iptv/index.m3u"
private const val MOVIE_LIST = "https://raw.githubusercontent.com/Ramys/Iptv-Brasil-2026/master/Filmes-Series.m3u8"
private const val USER_ASSET = "lista_usuario.m3u"

/** Atalhos para as transmissoes oficiais das emissoras (abrem no navegador/app da propria emissora). */
private fun officialWebEntries(): List<MediaEntry> = listOf(
    webEntry("Band (site oficial)", "https://www.band.com.br/ao-vivo/"),
    webEntry("Globo (site oficial - Globoplay)", "https://globoplay.globo.com/")
)

private fun webEntry(title: String, url: String) = MediaEntry(
    title, url, "TV Aberta", "", "WEB", source = "Site oficial", norm = normalize("$title TV Aberta")
)
private const val PAGE_SIZE = 50
private const val VOD_PAGE_SIZE = 10

/** Estado independente de cada secao (TV, Filmes, Series): itens, carregamento, pesquisa e paginacao. */
private class SectionState(val pageSize: Int = PAGE_SIZE) {
    var items by mutableStateOf<List<MediaEntry>>(emptyList())
    var loaded by mutableStateOf(false)
    var loading by mutableStateOf(false)
    var error by mutableStateOf("")
    var query by mutableStateOf("")
    var limit by mutableIntStateOf(pageSize)
    var category by mutableStateOf("")
}

private class CatalogResult(val items: List<MediaEntry>, val warning: String)

@Composable
private fun rememberDebounced(value: String, delayMs: Long = 350L): String {
    var out by remember { mutableStateOf(value) }
    LaunchedEffect(value) { delay(delayMs); out = value }
    return out
}

@Composable
private fun ClnApp() {
    val context= LocalContext.current
    val scope= rememberCoroutineScope()
    val prefs= remember { context.getSharedPreferences("clnplay_settings", Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf("INÍCIO") }
    var selected by remember { mutableStateOf<MediaEntry?>(null) }
    val tvS= remember { SectionState() }
    val moviesS= remember { SectionState(VOD_PAGE_SIZE) }
    val seriesS= remember { SectionState(VOD_PAGE_SIZE) }
    var homeQuery by remember { mutableStateOf("") }
    var tvUrl by remember { mutableStateOf(prefs.getString("tvUrl", TV_LIST) ?: TV_LIST) }
    var extraUrl by remember { mutableStateOf(prefs.getString("extraUrl", "") ?: "") }
    var vodUrl by remember { mutableStateOf(prefs.getString("vodUrl", MOVIE_LIST) ?: MOVIE_LIST) }
    var showSettings by remember { mutableStateOf(false) }
    var adultBlock by remember { mutableStateOf(prefs.getBoolean("adultBlock", true)) }
    var brazilOnly by remember { mutableStateOf(prefs.getBoolean("brazilOnly", true)) }
    var noFilters by remember { mutableStateOf(prefs.getBoolean("noFilters", false)) }
    // "Sem filtros" desliga todos os filtros de uma vez (adulto, estrangeiros e categorias).
    val effAdultBlock = adultBlock && !noFilters
    val effBrazilOnly = brazilOnly && !noFilters

    // Pesquisa independente por secao, com atraso de 350 ms.
    val dqTv= rememberDebounced(tvS.query)
    val dqMovies= rememberDebounced(moviesS.query)
    val dqSeries= rememberDebounced(seriesS.query)
    val dqHome= rememberDebounced(homeQuery)
    // A paginacao volta ao inicio somente quando o filtro daquela secao muda.
    LaunchedEffect(dqTv, tvS.category, effAdultBlock, effBrazilOnly) { tvS.limit=tvS.pageSize }
    LaunchedEffect(dqMovies, effAdultBlock) { moviesS.limit=moviesS.pageSize }
    LaunchedEffect(dqSeries, effAdultBlock) { seriesS.limit=seriesS.pageSize }

    fun loadTv(force: Boolean = false) {
        if (tvS.loading) return
        if (!force && tvS.loaded) return
        tvS.loading = true
        tvS.error = ""
        val mainUrl = tvUrl
        val extra = extraUrl
        val onlyBr = brazilOnly && !noFilters
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { loadTvCatalog(context, mainUrl, extra, onlyBr) }
                tvS.items = result.items
                tvS.loaded = true
                tvS.error = if (result.items.isEmpty()) "A playlist de TV não trouxe canais válidos. ${result.warning}".trim() else result.warning
            } catch (e: Exception) {
                tvS.error = e.message ?: "Não foi possível carregar a TV ao vivo."
            } finally {
                tvS.loading = false
            }
        }
    }

    // Filmes e séries vêm da mesma playlist: baixa uma vez e preenche as duas seções,
    // cada uma com seu próprio estado, pesquisa e paginação.
    fun loadVod(force: Boolean = false) {
        if (moviesS.loading || seriesS.loading) return
        if (!force && moviesS.loaded && seriesS.loaded) return
        moviesS.loading = true; seriesS.loading = true
        moviesS.error = ""; seriesS.error = ""
        val address = vodUrl
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { loadM3u(address, "VOD", "Filmes e séries") }
                moviesS.items = result.filter { it.kind == "FILMES" }
                seriesS.items = result.filter { it.kind == "SÉRIES" }
                moviesS.loaded = true; seriesS.loaded = true
                if (moviesS.items.isEmpty()) moviesS.error = "Nenhum filme encontrado na playlist."
                if (seriesS.items.isEmpty()) seriesS.error = "Nenhuma série encontrada na playlist."
            } catch (e: Exception) {
                val msg = e.message ?: "Não foi possível carregar filmes e séries."
                moviesS.error = msg; seriesS.error = msg
            } finally {
                moviesS.loading = false; seriesS.loading = false
            }
        }
    }

    fun openSection(section: String) {
        tab = section
        when (section) {
            "TV AO VIVO" -> loadTv()
            "FILMES", "SÉRIES" -> loadVod()
        }
    }

    fun openEntry(e: MediaEntry) {
        if (e.kind == "WEB") {
            try {
                context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(e.url)))
            } catch (ex: Exception) {
                tvS.error = "Não foi possível abrir o site oficial neste aparelho."
            }
        } else {
            selected = e
        }
    }

    // A tela inicial já mostra o catálogo: carrega TV, filmes e séries ao abrir o app.
    LaunchedEffect(Unit) { loadTv(); loadVod() }

    val tvFiltered = remember(tvS.items, dqTv, tvS.category, effAdultBlock) { filterEntries(tvS.items, dqTv, tvS.category, effAdultBlock) }
    val moviesFiltered = remember(moviesS.items, dqMovies, effAdultBlock) { filterEntries(moviesS.items, dqMovies, "", effAdultBlock) }
    val seriesFiltered = remember(seriesS.items, dqSeries, effAdultBlock) { filterEntries(seriesS.items, dqSeries, "", effAdultBlock) }
    val tvCategories = remember(tvS.items) {
        tvS.items.flatMap { it.group.split(';') }.map { it.trim() }.filter { it.isNotEmpty() }
            .groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(12).map { it.key }
    }
    val tvRow = remember(tvS.items, effAdultBlock) { filterEntries(tvS.items, "", "", effAdultBlock).take(20) }
    val movieRow = remember(moviesS.items, effAdultBlock) { filterEntries(moviesS.items, "", "", effAdultBlock).take(20) }
    val seriesRow = remember(seriesS.items, effAdultBlock) { filterEntries(seriesS.items, "", "", effAdultBlock).take(20) }
    val hero = remember(moviesS.items, seriesS.items, tvS.items, effAdultBlock) {
        moviesS.items.firstOrNull { !effAdultBlock || !it.adult }
            ?: seriesS.items.firstOrNull { !effAdultBlock || !it.adult }
            ?: tvS.items.firstOrNull { !effAdultBlock || !it.adult }
    }
    val homeResults = remember(tvS.items, moviesS.items, seriesS.items, dqHome, effAdultBlock) {
        if (dqHome.isBlank()) emptyList<MediaEntry>()
        else filterEntries(moviesS.items, dqHome, "", effAdultBlock).take(PAGE_SIZE) +
            filterEntries(seriesS.items, dqHome, "", effAdultBlock).take(PAGE_SIZE) +
            filterEntries(tvS.items, dqHome, "", effAdultBlock).take(PAGE_SIZE)
    }

    if(selected!=null) {
        PlayerScreen(entry=selected!!, onBack={ selected=null })
        return
    }

    val activeQuery = when (tab) {
        "TV AO VIVO" -> tvS.query
        "FILMES" -> moviesS.query
        "SÉRIES" -> seriesS.query
        else -> homeQuery
    }
    fun setActiveQuery(value: String) {
        when (tab) {
            "TV AO VIVO" -> tvS.query = value
            "FILMES" -> moviesS.query = value
            "SÉRIES" -> seriesS.query = value
            else -> homeQuery = value
        }
    }
    val activeError = when (tab) {
        "TV AO VIVO" -> tvS.error
        "FILMES" -> moviesS.error
        "SÉRIES" -> seriesS.error
        else -> ""
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(start=18.dp, end=6.dp, top=14.dp, bottom=4.dp), verticalAlignment=Alignment.CenterVertically) {
            Text("CLN", color=Accent, fontSize=26.sp, fontWeight=FontWeight.Black, letterSpacing=1.sp)
            Text("PLAY+", color=Color.White, fontSize=26.sp, fontWeight=FontWeight.Black, letterSpacing=1.sp)
            Spacer(Modifier.weight(1f))
            TextButton(onClick={
                when (tab) {
                    "TV AO VIVO" -> loadTv(true)
                    "FILMES", "SÉRIES" -> loadVod(true)
                    else -> { loadTv(true); loadVod(true) }
                }
            }) { Text("↻", color=Color.White, fontSize=20.sp) }
            TextButton(onClick={showSettings=true}) { Text("⚙ LISTAS", color=Color.White, fontSize=12.sp, fontWeight=FontWeight.Bold) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=8.dp).background(Panel, RoundedCornerShape(24.dp)).padding(horizontal=16.dp, vertical=10.dp), verticalAlignment=Alignment.CenterVertically) {
            Text("⌕", color=Muted, fontSize=20.sp)
            Spacer(Modifier.width(8.dp))
            BasicTextField(value=activeQuery, onValueChange={ setActiveQuery(it) }, singleLine=true,
                modifier=Modifier.weight(1f), textStyle=androidx.compose.ui.text.TextStyle(color=Color.White,fontSize=14.sp),
                decorationBox={ inner -> if(activeQuery.isEmpty()) Text(
                    when (tab) {
                        "TV AO VIVO" -> "Buscar canais..."
                        "FILMES" -> "Buscar filmes..."
                        "SÉRIES" -> "Buscar séries..."
                        else -> "Buscar canais, filmes ou séries..."
                    }, color=Muted, fontSize=13.sp); inner() })
        }
        when (tab) {
            "TV AO VIVO" -> SectionBody(
                state=tvS, filtered=tvFiltered, categories=if(noFilters) emptyList() else tvCategories, columns=2,
                loadingText="Carregando canais ao vivo…", onLoad={ loadTv() }, onOpen={ openEntry(it) })
            "FILMES" -> SectionBody(
                state=moviesS, filtered=moviesFiltered, categories=emptyList(), columns=3,
                loadingText="Carregando filmes…", onLoad={ loadVod() }, onOpen={ openEntry(it) })
            "SÉRIES" -> SectionBody(
                state=seriesS, filtered=seriesFiltered, categories=emptyList(), columns=3,
                loadingText="Carregando séries…", onLoad={ loadVod() }, onOpen={ openEntry(it) })
            else -> HomeContent(
                searching=dqHome.isNotBlank(), results=homeResults, hero=hero,
                tvRow=tvRow, movieRow=movieRow, seriesRow=seriesRow,
                loading=tvS.loading || moviesS.loading,
                onSeeAll={ openSection(it) }, onOpen={ openEntry(it) },
                onRetry={ loadTv(true); loadVod(true) })
        }
        if(activeError.isNotBlank()) Text(activeError,color=Color(0xFFFF788B),fontSize=11.sp,modifier=Modifier.padding(horizontal=16.dp, vertical=6.dp))
        BottomNav(tab) { name -> if(name=="INÍCIO") tab=name else openSection(name) }
    }

    if(showSettings) AlertDialog(
        onDismissRequest={showSettings=false},
        containerColor=Panel,
        title={Text("Fontes e filtros",color=Color.White)},
        text={
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Text("Playlist M3U da TV",color=Muted,fontSize=11.sp)
                OutlinedTextField(tvUrl,{tvUrl=it},singleLine=true)
                Text("Playlist M3U extra da TV (opcional)",color=Muted,fontSize=11.sp)
                OutlinedTextField(extraUrl,{extraUrl=it},singleLine=true)
                Text("Playlist M3U de filmes e séries",color=Muted,fontSize=11.sp)
                OutlinedTextField(vodUrl,{vodUrl=it},singleLine=true)
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Switch(checked=noFilters, onCheckedChange={
                        noFilters=it
                        prefs.edit().putBoolean("noFilters", it).apply()
                        tvS.category=""
                        tvS.loaded=false; tvS.items=emptyList()
                        loadTv()
                    })
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Sem filtros (mostrar tudo)",color=Color.White,fontSize=13.sp,fontWeight=FontWeight.Bold)
                        Text("Desliga o filtro adulto, o filtro de estrangeiros e as categorias. Carrega também a lista mundial.",color=Muted,fontSize=10.sp)
                    }
                }
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Checkbox(checked=brazilOnly, enabled=!noFilters, onCheckedChange={
                        brazilOnly=it
                        prefs.edit().putBoolean("brazilOnly", it).apply()
                        tvS.loaded=false; tvS.items=emptyList()
                        loadTv()
                    })
                    Text("Ocultar canais explicitamente estrangeiros",color=Color.White,fontSize=12.sp)
                }
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Checkbox(checked=adultBlock, enabled=!noFilters, onCheckedChange={
                        adultBlock=it
                        prefs.edit().putBoolean("adultBlock", it).apply()
                    })
                    Text("Bloquear conteúdo adulto (recomendado)",color=Color.White,fontSize=12.sp)
                }
                Text("TV mostra 50 itens por vez; filmes e séries mostram 10. Use CARREGAR MAIS para avançar. A pesquisa procura em todo o catálogo.",color=Muted,fontSize=10.sp)
                Text(Posters.status(),color=Muted,fontSize=10.sp)
                Text("Este produto usa a API do TMDB, mas não é endossado nem certificado pelo TMDB.",color=Muted,fontSize=10.sp)
            }
        },
        confirmButton={TextButton(onClick={
            showSettings=false
            prefs.edit().putString("tvUrl", tvUrl).putString("extraUrl", extraUrl).putString("vodUrl", vodUrl).apply()
            tvS.loaded=false; tvS.items=emptyList()
            moviesS.loaded=false; moviesS.items=emptyList()
            seriesS.loaded=false; seriesS.items=emptyList()
            loadTv(true)
            loadVod(true)
        }){Text("SALVAR",color=Accent)}},
        dismissButton={TextButton(onClick={showSettings=false}){Text("FECHAR",color=Muted)}}
    )
}

@Composable
private fun BottomNav(tab: String, onSelect: (String) -> Unit) {
    val entries = listOf(
        Triple("INÍCIO", "⌂", "Início"),
        Triple("TV AO VIVO", "◉", "TV"),
        Triple("FILMES", "▶", "Filmes"),
        Triple("SÉRIES", "☰", "Séries")
    )
    Row(Modifier.fillMaxWidth().background(Color(0xFF0F0F15)).padding(top=6.dp, bottom=8.dp)) {
        entries.forEach { (key, icon, label) ->
            val active = tab == key
            Column(Modifier.weight(1f).clickable { onSelect(key) }.padding(vertical=4.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                Text(icon, color=if(active) Accent else Muted, fontSize=20.sp)
                Text(label, color=if(active) Color.White else Muted, fontSize=10.sp, fontWeight=if(active) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}

@Composable
private fun ColumnScope.HomeContent(
    searching: Boolean,
    results: List<MediaEntry>,
    hero: MediaEntry?,
    tvRow: List<MediaEntry>,
    movieRow: List<MediaEntry>,
    seriesRow: List<MediaEntry>,
    loading: Boolean,
    onSeeAll: (String) -> Unit,
    onOpen: (MediaEntry) -> Unit,
    onRetry: () -> Unit
) {
    if (searching) {
        if (results.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment=Alignment.Center) {
                Text("Nenhum resultado nos catálogos carregados.", color=Muted, fontSize=13.sp)
            }
        } else {
            LazyVerticalGrid(columns=GridCells.Fixed(3), modifier=Modifier.weight(1f),
                contentPadding=PaddingValues(start=14.dp,end=14.dp,top=4.dp,bottom=24.dp),
                horizontalArrangement=Arrangement.spacedBy(10.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
                items(results) { entry -> PosterCard(entry, Modifier.fillMaxWidth(), onOpen) }
            }
        }
        return
    }
    if (hero == null && tvRow.isEmpty() && movieRow.isEmpty() && seriesRow.isEmpty()) {
        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment=Alignment.Center) {
            if (loading) {
                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color=Accent)
                    Spacer(Modifier.height(12.dp))
                    Text("Preparando seu catálogo…", color=Muted)
                }
            } else {
                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                    Text("Seu catálogo está esperando.", color=Color.White, fontSize=18.sp, fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick=onRetry, colors=ButtonDefaults.buttonColors(containerColor=Accent)) { Text("CARREGAR CONTEÚDO") }
                }
            }
        }
        return
    }
    LazyColumn(Modifier.weight(1f), contentPadding=PaddingValues(bottom=24.dp)) {
        if (hero != null) item { HeroBanner(hero, onOpen) }
        item { Spacer(Modifier.height(10.dp)) }
        item { HomeRow("TV ao vivo", tvRow, true, { onSeeAll("TV AO VIVO") }, onOpen) }
        item { HomeRow("Filmes", movieRow, false, { onSeeAll("FILMES") }, onOpen) }
        item { HomeRow("Séries", seriesRow, false, { onSeeAll("SÉRIES") }, onOpen) }
        item {
            Text("Capas: este produto usa a API do TMDB, mas não é endossado nem certificado pelo TMDB.",
                color=Muted, fontSize=9.sp, modifier=Modifier.padding(horizontal=18.dp, vertical=16.dp))
        }
    }
}

@Composable
private fun HeroBanner(entry: MediaEntry, onOpen: (MediaEntry) -> Unit) {
    val cover by rememberCover(entry)
    Box(Modifier.fillMaxWidth().height(300.dp).background(Brush.linearGradient(tileColors(entry.title)))) {
        val bmp = cover
        if (bmp != null && entry.kind != "TV") {
            Image(bitmap=bmp.asImageBitmap(), contentDescription=null, contentScale=ContentScale.Crop, modifier=Modifier.fillMaxSize())
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x33000000), Color(0x99000000), Bg))))
        Column(Modifier.align(Alignment.BottomStart).padding(horizontal=20.dp, vertical=18.dp)) {
            Text(if (entry.kind == "TV") "AO VIVO AGORA" else "EM DESTAQUE", color=Accent, fontSize=10.sp, fontWeight=FontWeight.Black, letterSpacing=2.sp)
            Spacer(Modifier.height(4.dp))
            Text(entry.title, color=Color.White, fontSize=26.sp, fontWeight=FontWeight.Black, maxLines=2, overflow=TextOverflow.Ellipsis)
            Spacer(Modifier.height(12.dp))
            Button(onClick={ onOpen(entry) }, colors=ButtonDefaults.buttonColors(containerColor=Color.White, contentColor=Color.Black),
                shape=RoundedCornerShape(8.dp)) {
                Text("▶  ASSISTIR", fontWeight=FontWeight.Black, fontSize=13.sp)
            }
        }
    }
}

@Composable
private fun HomeRow(title: String, list: List<MediaEntry>, wide: Boolean, onSeeAll: () -> Unit, onOpen: (MediaEntry) -> Unit) {
    if (list.isEmpty()) return
    Column(Modifier.padding(bottom=10.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=8.dp), verticalAlignment=Alignment.CenterVertically) {
            Text(title, color=Color.White, fontWeight=FontWeight.Bold, fontSize=17.sp, modifier=Modifier.weight(1f))
            Text("Ver tudo ›", color=Accent, fontSize=12.sp, fontWeight=FontWeight.Bold, modifier=Modifier.clickable { onSeeAll() })
        }
        LazyRow(contentPadding=PaddingValues(horizontal=16.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            items(list) { e -> PosterCard(e, Modifier.width(if (wide) 160.dp else 116.dp), onOpen) }
        }
    }
}

@Composable
private fun PosterCard(entry: MediaEntry, modifier: Modifier = Modifier, onOpen: (MediaEntry) -> Unit) {
    val cover by rememberCover(entry)
    val bmp = cover
    val isWide = entry.kind == "TV" || entry.kind == "WEB"
    val tileBrush = if (isWide && bmp != null) Brush.linearGradient(listOf(Color(0xFFF2F2F6), Color(0xFFD9D9E2)))
        else Brush.linearGradient(tileColors(entry.title))
    Column(modifier.clickable { onOpen(entry) }) {
        Box(Modifier.fillMaxWidth().aspectRatio(if (isWide) 1.6f else 0.68f).clip(RoundedCornerShape(10.dp)).background(tileBrush),
            contentAlignment=Alignment.Center) {
            if (bmp != null) {
                Image(bitmap=bmp.asImageBitmap(), contentDescription=null,
                    contentScale=if (isWide) ContentScale.Fit else ContentScale.Crop,
                    modifier=Modifier.fillMaxSize().padding(if (isWide) 14.dp else 0.dp))
            } else {
                Text(initials(entry.title), color=Color.White.copy(alpha=0.85f), fontSize=if (isWide) 26.sp else 34.sp, fontWeight=FontWeight.Black)
            }
            if (entry.kind == "TV") {
                Box(Modifier.align(Alignment.TopStart).padding(6.dp).background(Accent, RoundedCornerShape(4.dp)).padding(horizontal=5.dp, vertical=2.dp)) {
                    Text("AO VIVO", color=Color.White, fontSize=8.sp, fontWeight=FontWeight.Black)
                }
            } else if (entry.kind == "WEB") {
                Box(Modifier.align(Alignment.TopStart).padding(6.dp).background(Color(0xFF2B6BFF), RoundedCornerShape(4.dp)).padding(horizontal=5.dp, vertical=2.dp)) {
                    Text("SITE OFICIAL", color=Color.White, fontSize=8.sp, fontWeight=FontWeight.Black)
                }
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(entry.title, color=Color.White, fontSize=11.sp, fontWeight=FontWeight.SemiBold, maxLines=2, overflow=TextOverflow.Ellipsis)
    }
}

private fun initials(title: String): String =
    title.split(' ').filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() }

private fun tileColors(title: String): List<Color> {
    val palettes = listOf(
        listOf(Color(0xFF7A1F2B), Color(0xFF2B0E17)), listOf(Color(0xFF1F3A7A), Color(0xFF0E162B)),
        listOf(Color(0xFF2A6B4F), Color(0xFF0D241B)), listOf(Color(0xFF6B2A6B), Color(0xFF220D22)),
        listOf(Color(0xFF7A5A1F), Color(0xFF2B200E)), listOf(Color(0xFF1F6B7A), Color(0xFF0E2429))
    )
    return palettes[(title.hashCode() and 0x7fffffff) % palettes.size]
}

/** Carrega a imagem do item sob demanda: capa do TMDB (filmes/séries) ou logo da playlist (canais). */
@Composable
private fun rememberCover(entry: MediaEntry): State<android.graphics.Bitmap?> {
    val context = LocalContext.current
    return produceState<android.graphics.Bitmap?>(initialValue = null, entry.url) {
        value = try {
            when (entry.kind) {
                "TV" -> if (entry.logo.startsWith("http")) Posters.loadBitmap(entry.logo) else null
                "WEB" -> null
                else -> Posters.tmdbPoster(context, entry)
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }
}

@Composable
private fun ColumnScope.SectionBody(
    state: SectionState,
    filtered: List<MediaEntry>,
    categories: List<String>,
    columns: Int,
    loadingText: String,
    onLoad: () -> Unit,
    onOpen: (MediaEntry) -> Unit
) {
    if (state.loading) {
        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment=Alignment.Center) {
            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                CircularProgressIndicator(color=Accent)
                Spacer(Modifier.height(12.dp))
                Text(loadingText, color=Muted)
            }
        }
    } else if (!state.loaded) {
        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment=Alignment.Center) {
            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                Text("Seu catálogo está esperando.", color=Color.White, fontSize=18.sp, fontWeight=FontWeight.Bold)
                Text("Carregue as playlists para começar.", color=Muted, fontSize=12.sp)
                Spacer(Modifier.height(14.dp))
                Button(onClick=onLoad, colors=ButtonDefaults.buttonColors(containerColor=Accent)) { Text("CARREGAR CONTEÚDO") }
            }
        }
    } else {
        if (categories.isNotEmpty()) {
            LazyRow(Modifier.fillMaxWidth(), contentPadding=PaddingValues(horizontal=16.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                item { CategoryChip("Todas", state.category.isEmpty()) { state.category = "" } }
                items(categories) { name -> CategoryChip(name, state.category == name) { state.category = name } }
            }
            Spacer(Modifier.height(8.dp))
        }
        val visible = filtered.take(state.limit)
        Row(Modifier.fillMaxWidth().padding(horizontal=18.dp, vertical=4.dp), verticalAlignment=Alignment.CenterVertically) {
            Text(if (state.category.isEmpty()) "CATÁLOGO" else state.category.uppercase(), color=Color.White, fontWeight=FontWeight.Bold, fontSize=14.sp)
            Spacer(Modifier.weight(1f))
            Text("${visible.size} de ${filtered.size} itens", color=Muted, fontSize=11.sp)
        }
        if (filtered.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment=Alignment.Center) {
                Text("Nenhum item encontrado.", color=Muted, fontSize=13.sp)
            }
        } else {
            LazyVerticalGrid(columns=GridCells.Fixed(columns), modifier=Modifier.weight(1f),
                contentPadding=PaddingValues(start=14.dp,end=14.dp,top=6.dp,bottom=24.dp),
                horizontalArrangement=Arrangement.spacedBy(10.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
                items(visible) { entry -> PosterCard(entry, Modifier.fillMaxWidth(), onOpen) }
                if (visible.size < filtered.size) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        LoadMoreButton(filtered.size - visible.size, state.pageSize) { state.limit += state.pageSize }
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryChip(label: String, active: Boolean, onClick: () -> Unit) {
    Box(Modifier.background(if (active) Accent else Panel, RoundedCornerShape(20.dp))
        .clickable(onClick = onClick).padding(horizontal=14.dp, vertical=8.dp)) {
        Text(label, color=Color.White, fontSize=11.sp, fontWeight=FontWeight.Bold, maxLines=1)
    }
}

@Composable
private fun LoadMoreButton(remaining: Int, step: Int, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().padding(vertical=6.dp)
        .background(Brush.horizontalGradient(listOf(Accent, Color(0xFFFF5A7A))), RoundedCornerShape(16.dp))
        .clickable(onClick = onClick).padding(vertical=14.dp), contentAlignment=Alignment.Center) {
        Column(horizontalAlignment=Alignment.CenterHorizontally) {
            Text("CARREGAR MAIS", color=Color.White, fontWeight=FontWeight.Black, fontSize=14.sp, letterSpacing=1.sp)
            Text("+${minOf(step, remaining)}  •  restam $remaining", color=Color(0xFFFFD6DE), fontSize=10.sp)
        }
    }
}

/** Capas via API oficial do TMDB (token vem do secret TMDB_BEARER_TOKEN) e logos das playlists. */
private object Posters {
    private val bitmaps = object : android.util.LruCache<String, android.graphics.Bitmap>(48 * 1024 * 1024) {
        override fun sizeOf(key: String, value: android.graphics.Bitmap): Int = value.byteCount
    }
    private val paths = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val gate = Semaphore(4)
    @Volatile private var authFailed = false

    val enabled: Boolean get() = BuildConfig.TMDB_BEARER_TOKEN.isNotBlank() && !authFailed

    fun status(): String = when {
        BuildConfig.TMDB_BEARER_TOKEN.isBlank() -> "Capas TMDB: token não configurado (secret TMDB_BEARER_TOKEN no GitHub)."
        authFailed -> "Capas TMDB: o TMDB recusou o token (erro 401). Confira o TMDB_BEARER_TOKEN."
        else -> "Capas TMDB: ativas."
    }

    suspend fun tmdbPoster(context: Context, entry: MediaEntry): android.graphics.Bitmap? {
        if (!enabled) return null
        val isSeries = entry.kind == "SÉRIES"
        val (title, year) = cleanSearchTitle(entry.title)
        if (title.length < 2) return null
        val key = (if (isSeries) "tv|" else "movie|") + normalize(title) + "|" + (year ?: "")
        var path: String? = paths[key]
        if (path == null) {
            val prefs = context.getSharedPreferences("clnplay_posters", Context.MODE_PRIVATE)
            path = prefs.getString(key, null)
            if (path == null) {
                path = withContext(Dispatchers.IO) {
                    gate.withPermit {
                        var r = fetchPosterPath(title, year, isSeries)
                        if (r == "" && year != null) r = fetchPosterPath(title, null, isSeries)
                        r
                    }
                }
                if (path != null) prefs.edit().putString(key, path).apply()
            }
            if (path != null) paths[key] = path
        }
        val p = path ?: return null
        if (p.isEmpty()) return null
        return loadBitmap("https://image.tmdb.org/t/p/w342$p")
    }

    // Retorna o caminho do poster, "" se o TMDB nao achou nada, ou null em caso de erro (nao guarda em cache).
    private fun fetchPosterPath(title: String, year: String?, isSeries: Boolean): String? {
        return try {
            val kind = if (isSeries) "tv" else "movie"
            val yearParam = if (year == null) "" else if (isSeries) "&first_air_date_year=$year" else "&year=$year"
            val q = java.net.URLEncoder.encode(title, "UTF-8")
            val address = "https://api.themoviedb.org/3/search/$kind?query=$q&language=pt-BR&include_adult=false&page=1$yearParam"
            val conn = (URL(address).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10000; readTimeout = 15000
                setRequestProperty("Authorization", "Bearer ${BuildConfig.TMDB_BEARER_TOKEN}")
                setRequestProperty("Accept", "application/json")
            }
            try {
                val code = conn.responseCode
                if (code == 401) { authFailed = true; return null }
                if (code !in 200..299) return null
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val results = org.json.JSONObject(body).optJSONArray("results")
                if (results == null || results.length() == 0) return ""
                for (i in 0 until minOf(results.length(), 5)) {
                    val p = results.getJSONObject(i).optString("poster_path", "")
                    if (p.isNotEmpty() && p != "null") return p
                }
                ""
            } finally {
                conn.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun loadBitmap(address: String): android.graphics.Bitmap? {
        val cached = bitmaps.get(address)
        if (cached != null) return cached
        return withContext(Dispatchers.IO) {
            gate.withPermit {
                try {
                    val conn = (URL(address).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 10000; readTimeout = 15000
                    }
                    try {
                        if (conn.responseCode !in 200..299) null
                        else {
                            val bmp = conn.inputStream.use { android.graphics.BitmapFactory.decodeStream(it) }
                            if (bmp != null) bitmaps.put(address, bmp)
                            bmp
                        }
                    } finally {
                        conn.disconnect()
                    }
                } catch (e: Exception) {
                    null
                }
            }
        }
    }
}

/** Limpa o titulo (tags, qualidade, SxxExx) para buscar no TMDB. O ano so vale se estiver entre parenteses. */
private fun cleanSearchTitle(raw: String): Pair<String, String?> {
    val year = Regex("""\(((19|20)\d{2})\)""").find(raw)?.groupValues?.getOrNull(1)
    var t = raw
    t = t.replace(Regex("""[\(\[][^\)\]]*[\)\]]"""), " ")
    t = t.replace(Regex("""(?i)\bS\d{1,2}\s?E\d{1,3}\b.*$"""), " ")
    t = t.replace(Regex("""(?i)\b(temporada|season)\b.*$"""), " ")
    t = t.replace(Regex("""(?i)\b(dublado|legendado|dual audio|nacional|4k|uhd|fhd|hd|1080p|720p|web-?dl|bluray)\b"""), " ")
    t = t.replace(Regex("""[|_]+"""), " ").replace(Regex("""\s+"""), " ").trim().trimEnd('-', '–', ':', ' ')
    return Pair(t, year)
}

/** Pesquisa no catalogo completo da secao (nao depende do que ja esta visivel na tela). */
private fun filterEntries(list: List<MediaEntry>, query: String, category: String, blockAdult: Boolean): List<MediaEntry> {
    val terms = normalize(query.trim()).split(' ').filter { it.isNotEmpty() }
    return list.filter { e ->
        (!blockAdult || !e.adult) &&
            (category.isEmpty() || e.group.split(';').any { it.trim() == category }) &&
            terms.all { e.norm.contains(it) }
    }
}

private fun loadTvCatalog(context: Context, tvUrl: String, extraUrl: String, brazilOnly: Boolean): CatalogResult {
    val all = ArrayList<MediaEntry>()
    val warnings = ArrayList<String>()
    fun attempt(label: String, block: () -> List<MediaEntry>) {
        try { all.addAll(block()) } catch (e: Exception) { warnings.add("$label: ${e.message ?: "falha ao carregar"}") }
    }
    attempt("Lista da TV") { loadM3u(tvUrl, "TV", "Lista da TV") }
    if (!brazilOnly) attempt("Lista mundial") { loadM3u(GLOBAL_TV_LIST, "TV", "Lista mundial") }
    attempt("Lista do usuário") { loadAsset(context, USER_ASSET, "TV", "Lista do usuário") }
    all.addAll(officialWebEntries())
    if (extraUrl.isNotBlank()) attempt("Lista extra") { loadM3u(extraUrl.trim(), "TV", "Lista extra") }
    // Remove somente o que tem evidência explícita de ser estrangeiro. Sem informação de país, o canal fica.
    val kept = if (brazilOnly) all.filterNot { isForeign(it) } else all
    val unique = kept.distinctBy { dedupeKey(it) }.sortedBy { it.norm }
    return CatalogResult(unique, warnings.joinToString("  •  "))
}

private fun classify(e:MediaEntry):String {
    val title=normalize(e.title)
    val group=normalize(e.group)
    val url=e.url.lowercase()
    if(Regex("temporada|season|episodio|episode|s[0-9]{1,2}\\s?e[0-9]{1,3}|\\bt[0-9]{1,2}\\s?e[0-9]{1,3}\\b|capitulo").containsMatchIn(title)) return "SÉRIES"
    val groupSeries=Regex("(^|[^a-z])(serie|series)([^a-z]|$)").containsMatchIn(group)
    val groupMovie=Regex("filme|movie|cinema").containsMatchIn(group)
    if(groupSeries && !groupMovie) return "SÉRIES"
    if(groupMovie && !groupSeries) return "FILMES"
    if(Regex("/series?/").containsMatchIn(url)) return "SÉRIES"
    return "FILMES"
}

private fun loadAsset(context: Context, name: String, kind: String, source: String): List<MediaEntry> {
    context.assets.open(name).bufferedReader(Charsets.UTF_8).use { return parseM3u(it, kind, source) }
}

private fun loadM3u(address:String, kind:String, source:String):List<MediaEntry> {
    require(address.startsWith("https://") || address.startsWith("http://")) { "Informe um endereço HTTP ou HTTPS válido." }
    val conn=(URL(address).openConnection() as HttpURLConnection).apply {
        connectTimeout=18000; readTimeout=35000; instanceFollowRedirects=true
        setRequestProperty("User-Agent","CLNPLAY-Android/3.0")
        setRequestProperty("Accept","*/*")
    }
    try {
        if(conn.responseCode !in 200..299) throw Exception("A playlist respondeu HTTP ${conn.responseCode}: $address")
        return conn.inputStream.bufferedReader(Charsets.UTF_8).use { parseM3u(it, kind, source) }
    } finally { conn.disconnect() }
}

private fun parseM3u(reader: BufferedReader, kind:String, source:String):List<MediaEntry> {
    val result=ArrayList<MediaEntry>()
    var title:String?=null; var group=""; var logo=""; var country=""; var tvgId=""
    var referrer=""; var userAgent=""
    var line:String?
    while(reader.readLine().also { line=it }!=null) {
        val value=line!!.trim()
        if(value.startsWith("#EXTINF:",true)) {
            val comma=value.lastIndexOf(',')
            title=if(comma>=0) value.substring(comma+1).trim() else "Sem título"
            group=attr(value,"group-title")
            logo=attr(value,"tvg-logo")
            country=attr(value,"tvg-country")
            tvgId=attr(value,"tvg-id")
        } else if(value.startsWith("#EXTVLCOPT:",true) && title!=null) {
            val opt=value.substringAfter(':')
            val k=opt.substringBefore('=').trim().lowercase()
            val v=opt.substringAfter('=',"").trim()
            if(k=="http-referrer" || k=="http-referer") referrer=v
            else if(k=="http-user-agent") userAgent=v
        } else if(value.isNotEmpty() && !value.startsWith("#") && title!=null) {
            if((value.startsWith("http://")||value.startsWith("https://")) && value.length<8192 && result.size<15000) {
                result.add(buildEntry(title!!.take(180), value, group, logo, kind, country, tvgId, source, referrer, userAgent))
            }
            title=null; group=""; logo=""; country=""; tvgId=""; referrer=""; userAgent=""
        }
    }
    return result.distinctBy { dedupeKey(it) }
}

private fun buildEntry(title:String, url:String, group:String, logo:String, kind:String, country:String, tvgId:String, source:String, referrer:String, userAgent:String):MediaEntry {
    val g=if(kind=="TV") canonicalGroup(group) else group
    val base=MediaEntry(title,url,g,logo,kind,country,tvgId,source)
    val actualKind=if(kind=="TV") "TV" else classify(base)
    return base.copy(kind=actualKind, norm=normalize("$title $g"), adult=isAdultEntry(title,g,url), referrer=referrer, userAgent=userAgent)
}

/** Padroniza as categorias em inglês mais comuns para o português; o restante fica como veio. */
private fun canonicalGroup(raw:String):String {
    if(raw.isBlank()) return ""
    return raw.split(';').map { it.trim() }.filter { it.isNotEmpty() }.joinToString(";") { part ->
        when(normalize(part)) {
            "news" -> "Notícias"
            "sports", "sport" -> "Esportes"
            "kids" -> "Infantil"
            "religious" -> "Religiosos"
            "documentary" -> "Documentários"
            "music" -> "Variedade e Músicas"
            "movies", "series" -> "Filmes e Séries"
            else -> part
        }
    }
}

private fun attr(line:String,key:String):String {
    val match=Regex("""$key="([^"]*)"""",RegexOption.IGNORE_CASE).find(line)
    return match?.groupValues?.getOrNull(1).orEmpty()
}
private fun normalize(s:String)=Normalizer.normalize(s,Normalizer.Form.NFD).replace(Regex("\\p{M}+"),"").lowercase()

private fun dedupeKey(e:MediaEntry):String {
    val clean=normalize(e.title.replace(Regex("""\s*[\(\[][^\)\]]*[\)\]]"""), "")).trim()
    return clean+"|"+e.url.substringBefore('?')
}

private fun isBrazilCode(t:String)=t=="br" || t=="bra" || t=="brazil" || t=="brasil"

/**
 * Só considera estrangeiro quando há evidência explícita: país informado diferente de Brasil
 * (tvg-country) ou sufixo de país diferente de .br no tvg-id. Sem informação, o canal é mantido.
 */
private fun isForeign(e:MediaEntry):Boolean {
    val tokens=normalize(e.country).split(';',',',' ','/').map { it.trim() }.filter { it.isNotEmpty() }
    if(tokens.any { isBrazilCode(it) }) return false
    val group=normalize(e.group)
    if(group.contains("brazil") || group.contains("brasil")) return false
    val idCountry=Regex("""\.([a-z]{2})(@|$)""").find(e.tvgId.lowercase())?.groupValues?.getOrNull(1)
    if(idCountry=="br") return false
    if(tokens.any { it.length==2 }) return true
    if(idCountry!=null) return true
    return false
}

private val adultStrong=Regex("""(^|[^a-z0-9])(xxx|porn|porno|pornografia|hentai|erotic|erotico|erotica|playboy|18\+|\+18|18plus|sexy)([^a-z0-9]|$)""")
private val adultGroup=Regex("""(^|[^a-z0-9])(adult|adults|adulto|adultos|sex|sexo|porn|xxx|erotic|erotico|hentai|18\+|\+18)([^a-z0-9]|$)""")
private val adultUrl=Regex("""(^|[/._-])(xxx|porn|adult)([/._-]|$)""")

/** Termos fortes no título; termos mais amplos só na categoria (evita bloquear "Adult Swim" ou "Sex Education"). */
private fun isAdultEntry(title:String, group:String, url:String):Boolean {
    val t=normalize(title)
    val g=normalize(group)
    return adultStrong.containsMatchIn(t) || adultGroup.containsMatchIn(g) || adultStrong.containsMatchIn(g) ||
        adultUrl.containsMatchIn(url.substringBefore('?').lowercase())
}

private fun fmtTime(ms:Long):String {
    val s=ms/1000
    val h=s/3600; val m=(s%3600)/60; val sec=s%60
    return if(h>0) "%d:%02d:%02d".format(h,m,sec) else "%02d:%02d".format(m,sec)
}

@Composable
private fun PlayerScreen(entry:MediaEntry,onBack:()->Unit) {
    val context=LocalContext.current
    val activity=context as? ComponentActivity
    val owner= LocalLifecycleOwner.current
    var fullscreen by remember { mutableStateOf(true) }
    var controlsVisible by remember { mutableStateOf(true) }
    var touchTick by remember { mutableIntStateOf(0) }
    var resizeIdx by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var isLive by remember { mutableStateOf(true) }
    var errorText by remember(entry.url) { mutableStateOf("") }
    val resizeModes=remember { listOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_ZOOM, AspectRatioFrameLayout.RESIZE_MODE_FILL) }
    val resizeLabels=remember { listOf("AJUSTAR","PREENCHER","ESTICAR") }

    DisposableEffect(activity) {
        val decor=activity?.window?.decorView
        activity?.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        onDispose {
            activity?.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            @Suppress("DEPRECATION")
            decor?.systemUiVisibility=android.view.View.SYSTEM_UI_FLAG_VISIBLE
        }
    }
    // Tela cheia: esconde/mostra as barras do sistema.
    LaunchedEffect(fullscreen) {
        val decor=activity?.window?.decorView
        @Suppress("DEPRECATION")
        decor?.systemUiVisibility = if(fullscreen) (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
            or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION) else android.view.View.SYSTEM_UI_FLAG_VISIBLE
    }
    val exoPlayer= remember(entry.url) {
        val httpFactory=DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)
        if(entry.userAgent.isNotBlank()) httpFactory.setUserAgent(entry.userAgent)
        if(entry.referrer.isNotBlank()) httpFactory.setDefaultRequestProperties(mapOf("Referer" to entry.referrer))
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(context).setDataSourceFactory(httpFactory))
            .build().apply {
            setMediaItem(MediaItem.fromUri(entry.url))
            playWhenReady=true
            prepare()
        }
    }
    DisposableEffect(owner,exoPlayer) {
        val observer=LifecycleEventObserver { _,event ->
            if(event==Lifecycle.Event.ON_PAUSE) exoPlayer.pause()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer); exoPlayer.release() }
    }
    DisposableEffect(exoPlayer) {
        val listener=object: Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                errorText="Canal indisponível (${error.errorCodeName})"
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if(playbackState==Player.STATE_READY) errorText=""
            }
        }
        exoPlayer.addListener(listener)
        onDispose { exoPlayer.removeListener(listener) }
    }
    BackHandlerCompat(onBack)

    // Controles somem sozinhos após 3 segundos; qualquer toque reinicia a contagem.
    LaunchedEffect(controlsVisible, touchTick) {
        if(controlsVisible) { delay(3000); controlsVisible=false }
    }
    // Atualiza posição/estado enquanto os controles estão visíveis.
    LaunchedEffect(exoPlayer, controlsVisible) {
        while(controlsVisible) {
            position=exoPlayer.currentPosition.coerceAtLeast(0L)
            val d=exoPlayer.duration
            duration=if(d==C.TIME_UNSET || d<0L) 0L else d
            playing=exoPlayer.playWhenReady
            isLive=exoPlayer.isCurrentMediaItemLive || d==C.TIME_UNSET || d<=0L
            delay(500)
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory={ ctx ->
            PlayerView(ctx).apply {
                this.player=exoPlayer
                useController=false
                keepScreenOn=true
                resizeMode=AspectRatioFrameLayout.RESIZE_MODE_FIT
                layoutParams=ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)
            }
        }, update={ it.player=exoPlayer; it.resizeMode=resizeModes[resizeIdx] }, modifier=Modifier.fillMaxSize())

        // Camada que recebe o toque na tela: mostra/esconde os controles.
        Box(Modifier.fillMaxSize().pointerInput(Unit) {
            detectTapGestures(onTap={ controlsVisible=!controlsVisible; touchTick++ })
        })

        AnimatedVisibility(visible=controlsVisible, enter=fadeIn(), exit=fadeOut()) {
            Box(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().align(Alignment.TopCenter)
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                    .padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
                    Text("‹  VOLTAR",color=Accent,fontWeight=FontWeight.Bold,modifier=Modifier.clickable { onBack() })
                    Spacer(Modifier.width(14.dp))
                    Text(entry.title,color=Color.White,fontSize=14.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
                }
                Box(Modifier.align(Alignment.Center).size(68.dp).background(Color(0x99000000), RoundedCornerShape(34.dp))
                    .clickable {
                        exoPlayer.playWhenReady=!exoPlayer.playWhenReady
                        playing=exoPlayer.playWhenReady
                        touchTick++
                    }, contentAlignment=Alignment.Center) {
                    Text(if(playing) "❚❚" else "▶", color=Color.White, fontSize=22.sp, fontWeight=FontWeight.Bold)
                }
                Column(Modifier.fillMaxWidth().align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                    .padding(horizontal=16.dp, vertical=12.dp)) {
                    if(!isLive && duration>0L) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Text(fmtTime(position), color=Color.White, fontSize=11.sp)
                            Slider(
                                value=position.toFloat().coerceIn(0f, duration.toFloat()),
                                onValueChange={ v ->
                                    position=v.toLong()
                                    exoPlayer.seekTo(v.toLong())
                                    touchTick++
                                },
                                valueRange=0f..duration.toFloat(),
                                colors=SliderDefaults.colors(thumbColor=Accent, activeTrackColor=Accent),
                                modifier=Modifier.weight(1f).padding(horizontal=8.dp)
                            )
                            Text(fmtTime(duration), color=Color.White, fontSize=11.sp)
                        }
                    } else {
                        Text("● AO VIVO", color=Accent, fontSize=11.sp, fontWeight=FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        PlayerChip("EXPANDIR: ${resizeLabels[resizeIdx]}") { resizeIdx=(resizeIdx+1)%resizeModes.size; touchTick++ }
                        PlayerChip(if(fullscreen) "SAIR DA TELA CHEIA" else "TELA CHEIA") { fullscreen=!fullscreen; touchTick++ }
                        Spacer(Modifier.weight(1f))
                        Text(entry.group.replace(";", "  •  ").ifBlank { entry.kind },color=Muted,fontSize=11.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                    }
                }
            }
        }

        if(errorText.isNotEmpty()) {
            Column(Modifier.align(Alignment.Center).background(Color(0xDD000000), RoundedCornerShape(14.dp)).padding(20.dp),
                horizontalAlignment=Alignment.CenterHorizontally) {
                Text(errorText, color=Color.White, fontSize=14.sp, fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("Pode estar fora do ar ou bloqueado na sua região.", color=Muted, fontSize=11.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    PlayerChip("TENTAR DE NOVO") { errorText=""; exoPlayer.prepare(); exoPlayer.playWhenReady=true }
                    PlayerChip("VOLTAR") { onBack() }
                }
            }
        }
    }
}

@Composable
private fun PlayerChip(label:String, onClick:()->Unit) {
    Box(Modifier.background(Color(0x99000000), RoundedCornerShape(20.dp))
        .clickable(onClick=onClick).padding(horizontal=14.dp, vertical=8.dp)) {
        Text(label, color=Color.White, fontSize=11.sp, fontWeight=FontWeight.Bold)
    }
}

@Composable
private fun BackHandlerCompat(onBack:()->Unit) {
    androidx.activity.compose.BackHandler(onBack=onBack)
}
